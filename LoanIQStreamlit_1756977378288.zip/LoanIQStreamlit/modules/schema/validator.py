"""Data validation module for LoanIQ."""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple, Optional
from datetime import datetime
import json

class SchemaValidator:
    """Validates data against predefined schemas."""
    
    def __init__(self):
        self.loan_schema = {
            'required_columns': [
                'client_id', 'loan_amount', 'interest_rate', 'term_months',
                'monthly_income', 'debt_payments', 'employment_years',
                'credit_history_years', 'previous_defaults'
            ],
            'optional_columns': [
                'loan_id', 'application_date', 'approval_date', 'status',
                'defaulted', 'risk_score'
            ],
            'data_types': {
                'client_id': 'int64',
                'loan_id': 'object',
                'loan_amount': 'float64',
                'interest_rate': 'float64',
                'term_months': 'int64',
                'monthly_income': 'float64',
                'debt_payments': 'float64',
                'employment_years': 'float64',
                'credit_history_years': 'float64',
                'previous_defaults': 'int64',
                'defaulted': 'int64'
            },
            'constraints': {
                'loan_amount': {'min': 1000, 'max': 100000},
                'interest_rate': {'min': 1.0, 'max': 30.0},
                'term_months': {'min': 6, 'max': 360},
                'monthly_income': {'min': 0},
                'debt_payments': {'min': 0},
                'employment_years': {'min': 0, 'max': 50},
                'credit_history_years': {'min': 0, 'max': 50},
                'previous_defaults': {'min': 0, 'max': 20},
                'defaulted': {'min': 0, 'max': 1}
            }
        }
        
        self.validation_errors = []
    
    def validate_dataframe(self, df: pd.DataFrame, schema_type: str = 'loan') -> Tuple[bool, List[str]]:
        """Validate a pandas DataFrame against schema."""
        self.validation_errors = []
        
        if schema_type == 'loan':
            return self._validate_loan_schema(df)
        else:
            self.validation_errors.append(f"Unknown schema type: {schema_type}")
            return False, self.validation_errors
    
    def _validate_loan_schema(self, df: pd.DataFrame) -> Tuple[bool, List[str]]:
        """Validate loan data schema."""
        schema = self.loan_schema
        
        # Check required columns
        missing_cols = set(schema['required_columns']) - set(df.columns)
        if missing_cols:
            self.validation_errors.append(f"Missing required columns: {missing_cols}")
        
        # Check data types
        for col, expected_type in schema['data_types'].items():
            if col in df.columns:
                try:
                    if expected_type == 'int64':
                        pd.to_numeric(df[col], errors='coerce').astype('int64')
                    elif expected_type == 'float64':
                        pd.to_numeric(df[col], errors='coerce')
                    # object type (string) doesn't need conversion
                except Exception as e:
                    self.validation_errors.append(f"Column {col} cannot be converted to {expected_type}: {str(e)}")
        
        # Check constraints
        for col, constraints in schema['constraints'].items():
            if col in df.columns:
                if 'min' in constraints:
                    min_violations = df[df[col] < constraints['min']]
                    if not min_violations.empty:
                        self.validation_errors.append(
                            f"Column {col} has {len(min_violations)} values below minimum {constraints['min']}"
                        )
                
                if 'max' in constraints:
                    max_violations = df[df[col] > constraints['max']]
                    if not max_violations.empty:
                        self.validation_errors.append(
                            f"Column {col} has {len(max_violations)} values above maximum {constraints['max']}"
                        )
        
        # Check for null values in required columns
        for col in schema['required_columns']:
            if col in df.columns:
                null_count = df[col].isnull().sum()
                if null_count > 0:
                    self.validation_errors.append(f"Column {col} has {null_count} null values")
        
        return len(self.validation_errors) == 0, self.validation_errors
    
    def auto_fix_dataframe(self, df: pd.DataFrame, schema_type: str = 'loan') -> pd.DataFrame:
        """Automatically fix common data issues."""
        if schema_type != 'loan':
            return df
        
        df_fixed = df.copy()
        schema = self.loan_schema
        
        # Fix data types
        for col, expected_type in schema['data_types'].items():
            if col in df_fixed.columns:
                try:
                    if expected_type == 'int64':
                        df_fixed[col] = pd.to_numeric(df_fixed[col], errors='coerce').fillna(0).astype('int64')
                    elif expected_type == 'float64':
                        df_fixed[col] = pd.to_numeric(df_fixed[col], errors='coerce').fillna(0.0)
                except Exception:
                    pass
        
        # Apply constraints (clamp values)
        for col, constraints in schema['constraints'].items():
            if col in df_fixed.columns:
                if 'min' in constraints:
                    df_fixed[col] = df_fixed[col].clip(lower=constraints['min'])
                if 'max' in constraints:
                    df_fixed[col] = df_fixed[col].clip(upper=constraints['max'])
        
        return df_fixed
    
    def get_schema_info(self, schema_type: str = 'loan') -> Dict[str, Any]:
        """Get schema information."""
        if schema_type == 'loan':
            return {
                'type': 'loan',
                'required_columns': self.loan_schema['required_columns'],
                'optional_columns': self.loan_schema['optional_columns'],
                'data_types': self.loan_schema['data_types'],
                'constraints': self.loan_schema['constraints'],
                'total_columns': len(self.loan_schema['required_columns']) + len(self.loan_schema['optional_columns'])
            }
        return {}
    
    def generate_sample_data(self, num_rows: int = 5) -> pd.DataFrame:
        """Generate sample data that conforms to schema."""
        np.random.seed(42)
        
        data = {
            'client_id': range(1, num_rows + 1),
            'loan_amount': np.random.uniform(5000, 50000, num_rows).round(2),
            'interest_rate': np.random.uniform(3.5, 18.0, num_rows).round(2),
            'term_months': np.random.choice([12, 24, 36, 48, 60], num_rows),
            'monthly_income': np.random.uniform(3000, 12000, num_rows).round(2),
            'debt_payments': np.random.uniform(200, 2000, num_rows).round(2),
            'employment_years': np.random.uniform(0.5, 15, num_rows).round(1),
            'credit_history_years': np.random.uniform(1, 20, num_rows).round(1),
            'previous_defaults': np.random.choice([0, 0, 0, 1, 2], num_rows),
            'defaulted': np.random.choice([0, 0, 0, 0, 1], num_rows)
        }
        
        return pd.DataFrame(data)

if __name__ == "__main__":
    print("🧪 Testing Schema Validator...")
    
    validator = SchemaValidator()
    
    # Generate sample data
    sample_df = validator.generate_sample_data(10)
    print(f"✅ Generated sample data: {sample_df.shape}")
    
    # Validate sample data
    is_valid, errors = validator.validate_dataframe(sample_df)
    print(f"✅ Sample data validation: {'Passed' if is_valid else 'Failed'}")
    
    if errors:
        for error in errors:
            print(f"   ❌ {error}")
    
    # Test with invalid data
    invalid_df = sample_df.copy()
    invalid_df.loc[0, 'loan_amount'] = -1000  # Invalid amount
    invalid_df.loc[1, 'interest_rate'] = 50   # Too high rate
    
    is_valid, errors = validator.validate_dataframe(invalid_df)
    print(f"✅ Invalid data detection: {'Detected' if not is_valid else 'Missed'}")
    print(f"   Found {len(errors)} validation errors")
    
    # Test auto-fix
    fixed_df = validator.auto_fix_dataframe(invalid_df)
    is_valid, errors = validator.validate_dataframe(fixed_df)
    print(f"✅ Auto-fix functionality: {'Success' if is_valid else 'Failed'}")
    
    # Test schema info
    schema_info = validator.get_schema_info()
    print(f"✅ Schema info: {schema_info['total_columns']} total columns")
    
    print("✅ Schema validator tests passed!")
