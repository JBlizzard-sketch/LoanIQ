"""Schema backup and restore manager for LoanIQ."""
import os
import json
import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional
import shutil
import zipfile

class SchemaBackupManager:
    """Manages schema backups and restoration."""
    
    def __init__(self, backup_dir: str = "schema_backups"):
        self.backup_dir = backup_dir
        self.ensure_backup_directory()
    
    def ensure_backup_directory(self):
        """Ensure backup directory exists."""
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)
    
    def create_backup(self, df: pd.DataFrame, schema_name: str, description: str = "") -> str:
        """Create a backup of current schema and data."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_id = f"{schema_name}_{timestamp}"
        backup_path = os.path.join(self.backup_dir, backup_id)
        
        # Create backup directory
        os.makedirs(backup_path, exist_ok=True)
        
        # Save data
        data_file = os.path.join(backup_path, "data.csv")
        df.to_csv(data_file, index=False)
        
        # Save schema metadata
        metadata = {
            'backup_id': backup_id,
            'schema_name': schema_name,
            'description': description,
            'created_at': datetime.now().isoformat(),
            'row_count': len(df),
            'column_count': len(df.columns),
            'columns': list(df.columns),
            'data_types': df.dtypes.astype(str).to_dict(),
            'file_size_bytes': os.path.getsize(data_file)
        }
        
        metadata_file = os.path.join(backup_path, "metadata.json")
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        # Save column statistics
        stats = self._generate_column_statistics(df)
        stats_file = os.path.join(backup_path, "statistics.json")
        with open(stats_file, 'w') as f:
            json.dump(stats, f, indent=2)
        
        return backup_id
    
    def _generate_column_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Generate detailed column statistics."""
        stats = {}
        
        for col in df.columns:
            col_stats = {
                'data_type': str(df[col].dtype),
                'null_count': int(df[col].isnull().sum()),
                'null_percentage': float((df[col].isnull().sum() / len(df)) * 100),
                'unique_count': int(df[col].nunique())
            }
            
            if df[col].dtype in ['int64', 'float64']:
                col_stats.update({
                    'mean': float(df[col].mean()) if not df[col].isnull().all() else None,
                    'median': float(df[col].median()) if not df[col].isnull().all() else None,
                    'std': float(df[col].std()) if not df[col].isnull().all() else None,
                    'min': float(df[col].min()) if not df[col].isnull().all() else None,
                    'max': float(df[col].max()) if not df[col].isnull().all() else None,
                    'q25': float(df[col].quantile(0.25)) if not df[col].isnull().all() else None,
                    'q75': float(df[col].quantile(0.75)) if not df[col].isnull().all() else None
                })
            else:
                # Categorical statistics
                value_counts = df[col].value_counts()
                col_stats.update({
                    'most_frequent': str(value_counts.index[0]) if len(value_counts) > 0 else None,
                    'most_frequent_count': int(value_counts.iloc[0]) if len(value_counts) > 0 else 0,
                    'top_values': {str(k): int(v) for k, v in value_counts.head(5).items()}
                })
            
            stats[col] = col_stats
        
        return stats
    
    def list_backups(self, schema_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all available backups."""
        backups = []
        
        if not os.path.exists(self.backup_dir):
            return backups
        
        for backup_folder in os.listdir(self.backup_dir):
            backup_path = os.path.join(self.backup_dir, backup_folder)
            if os.path.isdir(backup_path):
                metadata_file = os.path.join(backup_path, "metadata.json")
                
                if os.path.exists(metadata_file):
                    try:
                        with open(metadata_file, 'r') as f:
                            metadata = json.load(f)
                        
                        # Filter by schema name if specified
                        if schema_name is None or metadata.get('schema_name') == schema_name:
                            backups.append(metadata)
                    except Exception as e:
                        print(f"Error reading backup metadata for {backup_folder}: {e}")
        
        # Sort by creation date (newest first)
        backups.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        return backups
    
    def restore_backup(self, backup_id: str) -> Optional[pd.DataFrame]:
        """Restore data from a backup."""
        backup_path = os.path.join(self.backup_dir, backup_id)
        
        if not os.path.exists(backup_path):
            print(f"Backup {backup_id} not found")
            return None
        
        data_file = os.path.join(backup_path, "data.csv")
        
        if not os.path.exists(data_file):
            print(f"Data file not found in backup {backup_id}")
            return None
        
        try:
            df = pd.read_csv(data_file)
            return df
        except Exception as e:
            print(f"Error restoring backup {backup_id}: {e}")
            return None
    
    def get_backup_metadata(self, backup_id: str) -> Optional[Dict[str, Any]]:
        """Get metadata for a specific backup."""
        backup_path = os.path.join(self.backup_dir, backup_id)
        metadata_file = os.path.join(backup_path, "metadata.json")
        
        if not os.path.exists(metadata_file):
            return None
        
        try:
            with open(metadata_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading backup metadata: {e}")
            return None
    
    def get_backup_statistics(self, backup_id: str) -> Optional[Dict[str, Any]]:
        """Get column statistics for a specific backup."""
        backup_path = os.path.join(self.backup_dir, backup_id)
        stats_file = os.path.join(backup_path, "statistics.json")
        
        if not os.path.exists(stats_file):
            return None
        
        try:
            with open(stats_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error reading backup statistics: {e}")
            return None
    
    def delete_backup(self, backup_id: str) -> bool:
        """Delete a backup."""
        backup_path = os.path.join(self.backup_dir, backup_id)
        
        if not os.path.exists(backup_path):
            print(f"Backup {backup_id} not found")
            return False
        
        try:
            shutil.rmtree(backup_path)
            return True
        except Exception as e:
            print(f"Error deleting backup {backup_id}: {e}")
            return False
    
    def export_backup(self, backup_id: str, export_path: str) -> bool:
        """Export backup as a ZIP file."""
        backup_path = os.path.join(self.backup_dir, backup_id)
        
        if not os.path.exists(backup_path):
            print(f"Backup {backup_id} not found")
            return False
        
        try:
            with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(backup_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, backup_path)
                        zipf.write(file_path, arcname)
            
            return True
        except Exception as e:
            print(f"Error exporting backup {backup_id}: {e}")
            return False
    
    def cleanup_old_backups(self, keep_count: int = 10) -> int:
        """Clean up old backups, keeping only the most recent ones."""
        backups = self.list_backups()
        
        if len(backups) <= keep_count:
            return 0
        
        # Delete oldest backups
        deleted_count = 0
        for backup in backups[keep_count:]:
            if self.delete_backup(backup['backup_id']):
                deleted_count += 1
        
        return deleted_count
    
    def get_storage_usage(self) -> Dict[str, Any]:
        """Get storage usage information."""
        if not os.path.exists(self.backup_dir):
            return {'total_size_mb': 0, 'backup_count': 0, 'average_size_mb': 0}
        
        total_size = 0
        backup_count = 0
        
        for backup_folder in os.listdir(self.backup_dir):
            backup_path = os.path.join(self.backup_dir, backup_folder)
            if os.path.isdir(backup_path):
                backup_count += 1
                for root, dirs, files in os.walk(backup_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        total_size += os.path.getsize(file_path)
        
        total_size_mb = total_size / (1024 * 1024)
        average_size_mb = total_size_mb / backup_count if backup_count > 0 else 0
        
        return {
            'total_size_mb': round(total_size_mb, 2),
            'backup_count': backup_count,
            'average_size_mb': round(average_size_mb, 2)
        }

if __name__ == "__main__":
    print("🧪 Testing Schema Backup Manager...")
    
    # Create test data
    test_data = {
        'client_id': range(1, 6),
        'loan_amount': [5000, 10000, 15000, 20000, 25000],
        'interest_rate': [5.5, 7.2, 9.1, 6.8, 8.7],
        'monthly_income': [4000, 5500, 6200, 3800, 4800],
        'defaulted': [0, 0, 1, 0, 1]
    }
    
    df = pd.DataFrame(test_data)
    
    # Test backup creation
    backup_manager = SchemaBackupManager("test_backups")
    backup_id = backup_manager.create_backup(df, "loan_schema", "Test backup")
    print(f"✅ Backup creation: {backup_id}")
    
    # Test backup listing
    backups = backup_manager.list_backups()
    print(f"✅ Backup listing: {len(backups)} backups found")
    
    # Test backup restoration
    restored_df = backup_manager.restore_backup(backup_id)
    restoration_success = restored_df is not None and len(restored_df) == len(df)
    print(f"✅ Backup restoration: {'Success' if restoration_success else 'Failed'}")
    
    # Test metadata retrieval
    metadata = backup_manager.get_backup_metadata(backup_id)
    metadata_success = metadata is not None and 'backup_id' in metadata
    print(f"✅ Metadata retrieval: {'Success' if metadata_success else 'Failed'}")
    
    # Test statistics retrieval
    stats = backup_manager.get_backup_statistics(backup_id)
    stats_success = stats is not None and len(stats) > 0
    print(f"✅ Statistics retrieval: {'Success' if stats_success else 'Failed'}")
    
    # Test storage usage
    usage = backup_manager.get_storage_usage()
    print(f"✅ Storage usage: {usage['backup_count']} backups, {usage['total_size_mb']} MB")
    
    # Cleanup test backup
    cleanup_success = backup_manager.delete_backup(backup_id)
    print(f"✅ Backup cleanup: {'Success' if cleanup_success else 'Failed'}")
    
    print("✅ Schema backup manager tests passed!")
