"""Data preprocessing module for LoanIQ."""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class DataPreprocessor:
    """Handles data preprocessing and feature derivation."""
    
    def __init__(self):
        self.feature_mappings = {}
        self.scalers = {}
        self.encoders = {}
        
    def preprocess_loan_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Main preprocessing pipeline for loan data."""
        df_processed = df.copy()
        
        # Step 1: Basic data cleaning
        df_processed = self._clean_basic_data(df_processed)
        
        # Step 2: Derive target variable if not present
        df_processed = self._derive_target_variable(df_processed)
        
        # Step 3: Handle missing values
        df_processed = self._handle_missing_values(df_processed)
        
        # Step 4: Feature engineering will be done in pipeline module
        
        return df_processed
    
    def _clean_basic_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Basic data cleaning operations."""
        df_clean = df.copy()
        
        # Remove duplicates
        initial_rows = len(df_clean)
        df_clean = df_clean.drop_duplicates()
        duplicates_removed = initial_rows - len(df_clean)
        
        if duplicates_removed > 0:
            print(f"Removed {duplicates_removed} duplicate rows")
        
        # Convert data types
        numeric_columns = [
            'loan_amount', 'interest_rate', 'monthly_income', 
            'debt_payments', 'employment_years', 'credit_history_years'
        ]
        
        for col in numeric_columns:
            if col in df_clean.columns:
                df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
        
        integer_columns = ['term_months', 'previous_defaults', 'client_id']
        for col in integer_columns:
            if col in df_clean.columns:
                df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce').fillna(0).astype('int64')
        
        return df_clean
    
    def _derive_target_variable(self, df: pd.DataFrame) -> pd.DataFrame:
        """Derive the target variable 'defaulted' if not present."""
        df_target = df.copy()
        
        if 'defaulted' not in df_target.columns:
            # Logic to derive defaulted status
            # This is a simplified version - in reality, this would be based on payment history
            
            # Higher risk factors increase probability of default
            risk_factors = []
            
            if 'previous_defaults' in df_target.columns:
                risk_factors.append(df_target['previous_defaults'] > 0)
            
            if 'monthly_income' in df_target.columns and 'debt_payments' in df_target.columns:
                debt_to_income = df_target['debt_payments'] / df_target['monthly_income']
                risk_factors.append(debt_to_income > 0.4)  # High debt-to-income ratio
            
            if 'loan_amount' in df_target.columns and 'monthly_income' in df_target.columns:
                loan_to_income = df_target['loan_amount'] / (df_target['monthly_income'] * 12)
                risk_factors.append(loan_to_income > 3)  # High loan-to-income ratio
            
            if 'employment_years' in df_target.columns:
                risk_factors.append(df_target['employment_years'] < 1)  # Short employment
            
            if 'credit_history_years' in df_target.columns:
                risk_factors.append(df_target['credit_history_years'] < 2)  # Short credit history
            
            # Combine risk factors with some randomness
            np.random.seed(42)  # For reproducibility
            
            if risk_factors:
                risk_score = sum(risk_factors)
                # Base default probability based on number of risk factors
                base_prob = np.minimum(risk_score * 0.15, 0.6)  # Max 60% default probability
                
                # Add some randomness
                random_factor = np.random.uniform(0, 0.3, len(df_target))
                final_prob = np.minimum(base_prob + random_factor, 0.8)
                
                # Generate binary outcome
                df_target['defaulted'] = (np.random.uniform(0, 1, len(df_target)) < final_prob).astype(int)
            else:
                # If no risk factors available, use simple random assignment
                df_target['defaulted'] = np.random.choice([0, 0, 0, 1], len(df_target))
        
        return df_target
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing values with appropriate strategies."""
        df_filled = df.copy()
        
        # Numeric columns - fill with median
        numeric_cols = df_filled.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            if df_filled[col].isnull().sum() > 0:
                median_val = df_filled[col].median()
                df_filled[col].fillna(median_val, inplace=True)
        
        # Categorical columns - fill with mode or 'Unknown'
        categorical_cols = df_filled.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            if df_filled[col].isnull().sum() > 0:
                mode_val = df_filled[col].mode()
                if len(mode_val) > 0:
                    df_filled[col].fillna(mode_val[0], inplace=True)
                else:
                    df_filled[col].fillna('Unknown', inplace=True)
        
        return df_filled
    
    def create_data_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Create comprehensive data summary."""
        summary = {
            'basic_info': {
                'total_rows': len(df),
                'total_columns': len(df.columns),
                'memory_usage_mb': df.memory_usage(deep=True).sum() / (1024 * 1024),
                'duplicate_rows': df.duplicated().sum()
            },
            'missing_data': {
                col: {
                    'count': df[col].isnull().sum(),
                    'percentage': (df[col].isnull().sum() / len(df)) * 100
                }
                for col in df.columns if df[col].isnull().sum() > 0
            },
            'data_types': df.dtypes.to_dict(),
            'numeric_summary': {},
            'categorical_summary': {}
        }
        
        # Numeric columns summary
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            summary['numeric_summary'][col] = {
                'mean': df[col].mean(),
                'median': df[col].median(),
                'std': df[col].std(),
                'min': df[col].min(),
                'max': df[col].max(),
                'q25': df[col].quantile(0.25),
                'q75': df[col].quantile(0.75)
            }
        
        # Categorical columns summary
        categorical_cols = df.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            value_counts = df[col].value_counts()
            summary['categorical_summary'][col] = {
                'unique_values': df[col].nunique(),
                'most_frequent': value_counts.index[0] if len(value_counts) > 0 else None,
                'most_frequent_count': value_counts.iloc[0] if len(value_counts) > 0 else 0,
                'value_counts': value_counts.head(10).to_dict()
            }
        
        return summary
    
    def detect_outliers(self, df: pd.DataFrame, method: str = 'iqr') -> Dict[str, List[int]]:
        """Detect outliers in numeric columns."""
        outliers = {}
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            if method == 'iqr':
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outlier_mask = (df[col] < lower_bound) | (df[col] > upper_bound)
                outliers[col] = df[outlier_mask].index.tolist()
            
            elif method == 'zscore':
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                outlier_mask = z_scores > 3
                outliers[col] = df[outlier_mask].index.tolist()
        
        return outliers
    
    def validate_data_quality(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Comprehensive data quality validation."""
        quality_report = {
            'overall_score': 0,
            'issues': [],
            'recommendations': [],
            'metrics': {}
        }
        
        # Check missing data percentage
        total_cells = len(df) * len(df.columns)
        missing_cells = df.isnull().sum().sum()
        missing_percentage = (missing_cells / total_cells) * 100
        
        quality_report['metrics']['missing_data_percentage'] = missing_percentage
        
        if missing_percentage > 10:
            quality_report['issues'].append(f"High missing data percentage: {missing_percentage:.2f}%")
            quality_report['recommendations'].append("Consider data imputation or collection improvement")
        
        # Check for duplicates
        duplicate_percentage = (df.duplicated().sum() / len(df)) * 100
        quality_report['metrics']['duplicate_percentage'] = duplicate_percentage
        
        if duplicate_percentage > 5:
            quality_report['issues'].append(f"High duplicate percentage: {duplicate_percentage:.2f}%")
            quality_report['recommendations'].append("Remove or investigate duplicate records")
        
        # Check data types consistency
        type_issues = 0
        for col in df.columns:
            if df[col].dtype == 'object':
                try:
                    pd.to_numeric(df[col], errors='raise')
                    type_issues += 1
                except:
                    pass
        
        if type_issues > 0:
            quality_report['issues'].append(f"{type_issues} columns may have incorrect data types")
            quality_report['recommendations'].append("Review and convert data types appropriately")
        
        # Calculate overall score
        score = 100
        score -= min(missing_percentage * 2, 40)  # Penalize missing data
        score -= min(duplicate_percentage * 3, 30)  # Penalize duplicates
        score -= min(type_issues * 5, 20)  # Penalize type issues
        
        quality_report['overall_score'] = max(score, 0)
        
        return quality_report

if __name__ == "__main__":
    print("🧪 Testing Data Preprocessor...")
    
    # Create sample data with issues
    np.random.seed(42)
    sample_data = {
        'client_id': range(1, 11),
        'loan_amount': [5000, 10000, None, 25000, 15000, 8000, 30000, None, 12000, 18000],
        'interest_rate': [5.5, 7.2, 15.0, 9.1, 6.8, 12.5, 8.7, 10.2, 7.8, 9.5],
        'term_months': [24, 36, 48, 60, 24, 36, 48, 24, 36, 60],
        'monthly_income': [4000, 5500, 6200, 3800, 4800, 5200, 7000, 4500, 5800, 6000],
        'debt_payments': [800, 1200, None, 1500, 900, 1100, 1800, 1000, 1300, 1400],
        'employment_years': [2.5, 5.0, 1.0, 8.2, 3.5, 6.0, 0.5, 4.0, 7.5, 2.0],
        'credit_history_years': [3.0, 8.0, 2.5, 12.0, 5.0, 10.0, 1.5, 6.0, 9.0, 4.0],
        'previous_defaults': [0, 1, 0, 2, 0, 1, 3, 0, 1, 0]
    }
    
    df = pd.DataFrame(sample_data)
    preprocessor = DataPreprocessor()
    
    # Test preprocessing
    processed_df = preprocessor.preprocess_loan_data(df)
    print(f"✅ Data preprocessing: {len(processed_df)} rows processed")
    
    # Check if target variable was derived
    has_target = 'defaulted' in processed_df.columns
    print(f"✅ Target derivation: {'Success' if has_target else 'Failed'}")
    
    # Test data summary
    summary = preprocessor.create_data_summary(processed_df)
    print(f"✅ Data summary: {summary['basic_info']['total_columns']} columns analyzed")
    
    # Test outlier detection
    outliers = preprocessor.detect_outliers(processed_df)
    print(f"✅ Outlier detection: {len(outliers)} columns checked")
    
    # Test data quality validation
    quality_report = preprocessor.validate_data_quality(processed_df)
    print(f"✅ Quality validation: Score {quality_report['overall_score']:.1f}/100")
    
    print("✅ Data preprocessor tests passed!")
