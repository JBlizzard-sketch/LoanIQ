"""Synthetic data generator for LoanIQ using Faker."""
import pandas as pd
import numpy as np
from faker import Faker
from typing import Dict, List, Any, Optional
import random
from datetime import datetime, timedelta

class SyntheticDataGenerator:
    """Generates realistic synthetic loan data using Faker."""
    
    def __init__(self, seed: Optional[int] = None):
        self.seed = seed or 42
        self.fake = Faker()
        Faker.seed(self.seed)
        np.random.seed(self.seed)
        random.seed(self.seed)
        
        # Loan distribution parameters (skewed towards smaller amounts)
        self.loan_params = {
            'min_amount': 5000,
            'max_amount': 80000,
            'mean_log': 9.8,  # ln(~18000)
            'std_log': 0.6    # Controls skewness
        }
        
        # Client constraints
        self.max_loans_per_client = 3
        
        # Distribution parameters for different client segments
        self.client_segments = {
            'low_risk': {'weight': 0.4, 'default_rate': 0.05},
            'medium_risk': {'weight': 0.35, 'default_rate': 0.15},
            'high_risk': {'weight': 0.25, 'default_rate': 0.35}
        }
    
    def generate_loan_data(self, num_records: int, existing_clients: Optional[List[int]] = None) -> pd.DataFrame:
        """Generate synthetic loan data with realistic distributions."""
        
        # Generate unique clients first
        num_clients = max(1, num_records // 2)  # Ensure some clients have multiple loans
        clients = self._generate_clients(num_clients, existing_clients)
        
        # Generate loans for clients
        loans = []
        records_generated = 0
        
        while records_generated < num_records:
            # Select random client
            client = random.choice(clients)
            
            # Check if client already has max loans
            client_loans = sum(1 for loan in loans if loan['client_id'] == client['id'])
            if client_loans >= self.max_loans_per_client:
                # Create new client if needed
                new_client = self._generate_single_client(
                    client_id=max([c['id'] for c in clients]) + 1,
                    existing_clients=existing_clients
                )
                clients.append(new_client)
                client = new_client
            
            # Generate loan for this client
            loan = self._generate_loan_for_client(client)
            loans.append(loan)
            records_generated += 1
        
        # Convert to DataFrame
        df = pd.DataFrame(loans)
        
        # Ensure data types are correct
        df = self._fix_data_types(df)
        
        return df
    
    def _generate_clients(self, num_clients: int, existing_clients: Optional[List[int]] = None) -> List[Dict[str, Any]]:
        """Generate client profiles."""
        clients = []
        existing_ids = set(existing_clients or [])
        
        for i in range(num_clients):
            client_id = i + 1
            
            # Avoid ID conflicts with existing clients
            while client_id in existing_ids:
                client_id += 1000
            
            client = self._generate_single_client(client_id, existing_clients)
            clients.append(client)
            existing_ids.add(client_id)
        
        return clients
    
    def _generate_single_client(self, client_id: int, existing_clients: Optional[List[int]] = None) -> Dict[str, Any]:
        """Generate a single client profile."""
        
        # Assign risk segment
        segments = list(self.client_segments.keys())
        weights = [self.client_segments[seg]['weight'] for seg in segments]
        risk_segment = np.random.choice(segments, p=weights)
        
        # Base characteristics vary by risk segment
        if risk_segment == 'low_risk':
            income_range = (5000, 12000)
            employment_range = (3, 20)
            credit_history_range = (5, 25)
            defaults_prob = [0.9, 0.1, 0.0, 0.0]  # Mostly 0-1 defaults
            
        elif risk_segment == 'medium_risk':
            income_range = (3500, 8000)
            employment_range = (1, 15)
            credit_history_range = (2, 15)
            defaults_prob = [0.7, 0.2, 0.1, 0.0]  # 0-2 defaults
            
        else:  # high_risk
            income_range = (2500, 6000)
            employment_range = (0.5, 10)
            credit_history_range = (0.5, 10)
            defaults_prob = [0.3, 0.3, 0.2, 0.2]  # 0-3+ defaults
        
        # Generate client attributes
        monthly_income = np.random.uniform(*income_range)
        employment_years = np.random.uniform(*employment_range)
        credit_history_years = np.random.uniform(*credit_history_range)
        previous_defaults = np.random.choice([0, 1, 2, 3], p=defaults_prob)
        
        # Debt payments based on income and risk
        base_debt_ratio = {'low_risk': 0.2, 'medium_risk': 0.3, 'high_risk': 0.45}[risk_segment]
        debt_variation = np.random.uniform(0.8, 1.3)
        debt_payments = monthly_income * base_debt_ratio * debt_variation
        
        return {
            'id': client_id,
            'risk_segment': risk_segment,
            'monthly_income': monthly_income,
            'employment_years': employment_years,
            'credit_history_years': credit_history_years,
            'previous_defaults': previous_defaults,
            'debt_payments': debt_payments
        }
    
    def _generate_loan_for_client(self, client: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a loan for a specific client."""
        
        # Generate loan amount (log-normal distribution for realistic skew)
        loan_amount = np.random.lognormal(
            mean=self.loan_params['mean_log'],
            sigma=self.loan_params['std_log']
        )
        
        # Clamp to realistic range
        loan_amount = np.clip(loan_amount, 
                             self.loan_params['min_amount'], 
                             self.loan_params['max_amount'])
        
        # Adjust loan amount based on client income
        max_affordable = client['monthly_income'] * 12 * 4  # 4x annual income max
        loan_amount = min(loan_amount, max_affordable)
        
        # Interest rate based on risk segment and random variation
        base_rates = {'low_risk': 6.5, 'medium_risk': 9.0, 'high_risk': 14.0}
        base_rate = base_rates[client['risk_segment']]
        rate_variation = np.random.uniform(-2.0, 3.0)
        interest_rate = np.clip(base_rate + rate_variation, 3.0, 25.0)
        
        # Term length (more risky clients get shorter terms)
        term_options = {
            'low_risk': [24, 36, 48, 60, 72],
            'medium_risk': [24, 36, 48, 60],
            'high_risk': [12, 24, 36, 48]
        }
        term_weights = {
            'low_risk': [0.1, 0.3, 0.3, 0.2, 0.1],
            'medium_risk': [0.2, 0.4, 0.3, 0.1],
            'high_risk': [0.3, 0.4, 0.2, 0.1]
        }
        
        available_terms = term_options[client['risk_segment']]
        term_probs = term_weights[client['risk_segment']]
        term_months = np.random.choice(available_terms, p=term_probs)
        
        # Application and approval dates
        application_date = self.fake.date_between(start_date='-2y', end_date='today')
        approval_date = application_date + timedelta(days=random.randint(1, 14))
        
        # Loan status
        status_options = ['approved', 'active', 'completed', 'defaulted']
        status_weights = [0.1, 0.6, 0.25, 0.05]  # Most loans are active
        
        # Adjust weights based on approval date (older loans more likely to be completed)
        days_since_approval = (datetime.now().date() - approval_date).days
        if days_since_approval > 365:
            status_weights = [0.05, 0.4, 0.5, 0.05]
        
        status = np.random.choice(status_options, p=status_weights)
        
        # Default status (influenced by client risk segment and other factors)
        default_prob = self.client_segments[client['risk_segment']]['default_rate']
        
        # Adjust default probability based on loan characteristics
        if client['debt_payments'] / client['monthly_income'] > 0.4:
            default_prob *= 1.5  # High debt-to-income increases default risk
        
        if loan_amount / (client['monthly_income'] * 12) > 3:
            default_prob *= 1.3  # High loan-to-income increases default risk
        
        if client['employment_years'] < 1:
            default_prob *= 1.4  # Low employment history increases risk
        
        if interest_rate > 15:
            default_prob *= 1.2  # High interest rate increases default risk
        
        # Cap default probability
        default_prob = min(default_prob, 0.6)
        
        defaulted = 1 if (np.random.random() < default_prob or status == 'defaulted') else 0
        
        # Generate loan ID
        loan_id = f"LN{random.randint(100000, 999999)}"
        
        return {
            'loan_id': loan_id,
            'client_id': client['id'],
            'loan_amount': round(loan_amount, 2),
            'interest_rate': round(interest_rate, 2),
            'term_months': term_months,
            'monthly_income': round(client['monthly_income'], 2),
            'debt_payments': round(client['debt_payments'], 2),
            'employment_years': round(client['employment_years'], 1),
            'credit_history_years': round(client['credit_history_years'], 1),
            'previous_defaults': client['previous_defaults'],
            'application_date': application_date,
            'approval_date': approval_date,
            'status': status,
            'defaulted': defaulted
        }
    
    def _fix_data_types(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fix data types to match schema requirements."""
        df_fixed = df.copy()
        
        # Convert date columns
        date_columns = ['application_date', 'approval_date']
        for col in date_columns:
            if col in df_fixed.columns:
                df_fixed[col] = pd.to_datetime(df_fixed[col])
        
        # Ensure integer columns are integers
        int_columns = ['client_id', 'term_months', 'previous_defaults', 'defaulted']
        for col in int_columns:
            if col in df_fixed.columns:
                df_fixed[col] = df_fixed[col].astype('int64')
        
        # Ensure float columns are floats
        float_columns = ['loan_amount', 'interest_rate', 'monthly_income', 
                        'debt_payments', 'employment_years', 'credit_history_years']
        for col in float_columns:
            if col in df_fixed.columns:
                df_fixed[col] = df_fixed[col].astype('float64')
        
        return df_fixed
    
    def generate_client_history_data(self, num_clients: int = 100, loans_per_client: int = 2) -> pd.DataFrame:
        """Generate data with client history for testing aggregate features."""
        clients = self._generate_clients(num_clients)
        loans = []
        
        for client in clients:
            num_loans = min(loans_per_client, self.max_loans_per_client)
            
            for i in range(num_loans):
                loan = self._generate_loan_for_client(client)
                # Adjust dates so they're sequential for the same client
                base_date = datetime.now().date() - timedelta(days=random.randint(30, 730))
                loan['application_date'] = base_date - timedelta(days=i*180)  # 6 months apart
                loan['approval_date'] = loan['application_date'] + timedelta(days=random.randint(1, 14))
                loans.append(loan)
        
        df = pd.DataFrame(loans)
        return self._fix_data_types(df)
    
    def get_generation_statistics(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Get statistics about generated data."""
        stats = {
            'total_records': len(df),
            'unique_clients': df['client_id'].nunique(),
            'avg_loans_per_client': len(df) / df['client_id'].nunique(),
            'default_rate': df['defaulted'].mean() if 'defaulted' in df.columns else 0,
            'loan_amount_stats': {
                'mean': df['loan_amount'].mean(),
                'median': df['loan_amount'].median(),
                'min': df['loan_amount'].min(),
                'max': df['loan_amount'].max(),
                'std': df['loan_amount'].std()
            },
            'income_distribution': df['monthly_income'].describe().to_dict(),
            'interest_rate_range': [df['interest_rate'].min(), df['interest_rate'].max()],
            'term_distribution': df['term_months'].value_counts().to_dict()
        }
        
        return stats

if __name__ == "__main__":
    print("🧪 Testing Synthetic Data Generator...")
    
    # Test basic data generation
    generator = SyntheticDataGenerator(seed=42)
    
    # Generate sample data
    df = generator.generate_loan_data(50)
    print(f"✅ Data generation: {len(df)} records created")
    
    # Test client constraints
    loans_per_client = df['client_id'].value_counts()
    max_loans = loans_per_client.max()
    within_constraint = max_loans <= generator.max_loans_per_client
    print(f"✅ Client constraints: Max {max_loans} loans per client ({'✓' if within_constraint else '✗'})")
    
    # Test loan amount distribution
    loan_amounts = df['loan_amount']
    within_range = (loan_amounts >= generator.loan_params['min_amount']).all() and \
                   (loan_amounts <= generator.loan_params['max_amount']).all()
    print(f"✅ Loan amount range: ${loan_amounts.min():,.0f} - ${loan_amounts.max():,.0f} ({'✓' if within_range else '✗'})")
    
    # Test skewed distribution (more small loans)
    small_loans = (loan_amounts <= 20000).sum()
    large_loans = (loan_amounts > 50000).sum()
    is_skewed = small_loans > large_loans
    print(f"✅ Loan distribution skew: Small loans: {small_loans}, Large loans: {large_loans} ({'✓' if is_skewed else '✗'})")
    
    # Test required columns
    required_cols = ['client_id', 'loan_amount', 'interest_rate', 'term_months',
                    'monthly_income', 'debt_payments', 'employment_years',
                    'credit_history_years', 'previous_defaults', 'defaulted']
    
    has_all_cols = all(col in df.columns for col in required_cols)
    print(f"✅ Required columns: {'All present' if has_all_cols else 'Missing columns'}")
    
    # Test data types
    correct_types = (
        df['client_id'].dtype == 'int64' and
        df['loan_amount'].dtype == 'float64' and
        df['defaulted'].dtype == 'int64'
    )
    print(f"✅ Data types: {'Correct' if correct_types else 'Incorrect'}")
    
    # Test default rate reasonableness
    default_rate = df['defaulted'].mean()
    reasonable_default = 0.05 <= default_rate <= 0.30
    print(f"✅ Default rate: {default_rate:.1%} ({'✓' if reasonable_default else '✗'})")
    
    # Test generation statistics
    stats = generator.get_generation_statistics(df)
    print(f"✅ Statistics: {stats['unique_clients']} unique clients, avg {stats['avg_loans_per_client']:.1f} loans/client")
    
    # Test client history data
    history_df = generator.generate_client_history_data(20, 2)
    print(f"✅ Client history: {len(history_df)} records with history")
    
    print("✅ Synthetic data generator tests passed!")
