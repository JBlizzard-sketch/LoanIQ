"""Synthetic data generation module."""
from .data_generator import SyntheticDataGenerator

__all__ = ['SyntheticDataGenerator']
