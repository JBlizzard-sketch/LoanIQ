"""Model trainer for LoanIQ ML engine."""
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Tuple
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, classification_report
)
import warnings
warnings.filterwarnings('ignore')

# Optional imports for advanced models
try:
    import xgboost as xgb
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

try:
    import lightgbm as lgb
    HAS_LIGHTGBM = True
except ImportError:
    HAS_LIGHTGBM = False

class ModelTrainer:
    """Trains multiple ML model families for credit scoring."""
    
    def __init__(self):
        self.model_configs = {
            'logistic_regression': {
                'class': LogisticRegression,
                'params': {
                    'random_state': 42,
                    'max_iter': 1000,
                    'class_weight': 'balanced'
                },
                'needs_scaling': True
            },
            'random_forest': {
                'class': RandomForestClassifier,
                'params': {
                    'n_estimators': 100,
                    'random_state': 42,
                    'class_weight': 'balanced',
                    'max_depth': 10,
                    'min_samples_split': 5
                },
                'needs_scaling': False
            },
            'gradient_boosting': {
                'class': GradientBoostingClassifier,
                'params': {
                    'n_estimators': 100,
                    'random_state': 42,
                    'max_depth': 6,
                    'learning_rate': 0.1
                },
                'needs_scaling': False
            }
        }
        
        # Add XGBoost if available
        if HAS_XGBOOST:
            self.model_configs['xgboost'] = {
                'class': xgb.XGBClassifier,
                'params': {
                    'random_state': 42,
                    'eval_metric': 'logloss',
                    'use_label_encoder': False,
                    'max_depth': 6,
                    'learning_rate': 0.1,
                    'n_estimators': 100
                },
                'needs_scaling': False
            }
        
        # Add LightGBM if available
        if HAS_LIGHTGBM:
            self.model_configs['lightgbm'] = {
                'class': lgb.LGBMClassifier,
                'params': {
                    'random_state': 42,
                    'verbose': -1,
                    'max_depth': 6,
                    'learning_rate': 0.1,
                    'n_estimators': 100,
                    'class_weight': 'balanced'
                },
                'needs_scaling': False
            }
    
    def train_single_model(self, 
                          model_name: str, 
                          X_train: pd.DataFrame, 
                          y_train: pd.Series,
                          X_test: pd.DataFrame, 
                          y_test: pd.Series) -> Dict[str, Any]:
        """Train a single model and return results."""
        
        if model_name not in self.model_configs:
            raise ValueError(f"Unknown model: {model_name}")
        
        config = self.model_configs[model_name]
        
        try:
            # Initialize scaler if needed
            scaler = None
            X_train_scaled = X_train
            X_test_scaled = X_test
            
            if config['needs_scaling']:
                scaler = StandardScaler()
                X_train_scaled = scaler.fit_transform(X_train)
                X_test_scaled = scaler.transform(X_test)
            
            # Train model
            model = config['class'](**config['params'])
            model.fit(X_train_scaled, y_train)
            
            # Make predictions
            y_pred = model.predict(X_test_scaled)
            y_pred_proba = None
            
            if hasattr(model, 'predict_proba'):
                y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
            
            # Calculate metrics
            metrics = self._calculate_metrics(y_test, y_pred, y_pred_proba)
            
            return {
                'model': model,
                'scaler': scaler,
                'predictions': y_pred,
                'probabilities': y_pred_proba,
                'metrics': metrics,
                'success': True,
                'error': None
            }
            
        except Exception as e:
            return {
                'model': None,
                'scaler': None,
                'predictions': None,
                'probabilities': None,
                'metrics': {},
                'success': False,
                'error': str(e)
            }
    
    def train_all_models(self, 
                        X_train: pd.DataFrame, 
                        y_train: pd.Series,
                        X_test: pd.DataFrame, 
                        y_test: pd.Series) -> Dict[str, Any]:
        """Train all available model families."""
        
        results = {}
        
        print(f"🚀 Training {len(self.model_configs)} model families...")
        
        for model_name in self.model_configs:
            print(f"   Training {model_name}...")
            
            result = self.train_single_model(
                model_name, X_train, y_train, X_test, y_test
            )
            
            if result['success']:
                print(f"   ✅ {model_name}: F1={result['metrics']['f1_score']:.3f}, "
                      f"AUC={result['metrics']['roc_auc']:.3f}")
            else:
                print(f"   ❌ {model_name}: {result['error']}")
            
            results[model_name] = result
        
        # Create stacked hybrid model
        results['stacked_hybrid'] = self._create_stacked_model(
            results, X_train, y_train, X_test, y_test
        )
        
        return results
    
    def _create_stacked_model(self, 
                            base_results: Dict[str, Any],
                            X_train: pd.DataFrame, 
                            y_train: pd.Series,
                            X_test: pd.DataFrame, 
                            y_test: pd.Series) -> Dict[str, Any]:
        """Create a stacked ensemble model from successful base models."""
        
        try:
            # Get successful models
            successful_models = {
                name: result for name, result in base_results.items()
                if result['success'] and result['probabilities'] is not None
            }
            
            if len(successful_models) < 2:
                return {
                    'model': None,
                    'scaler': None,
                    'predictions': None,
                    'probabilities': None,
                    'metrics': {},
                    'success': False,
                    'error': 'Not enough successful models for stacking'
                }
            
            # Create stacking features from base model predictions
            stacking_features_test = []
            model_names = []
            
            for name, result in successful_models.items():
                stacking_features_test.append(result['probabilities'])
                model_names.append(name)
            
            stacking_features_test = np.column_stack(stacking_features_test)
            
            # For training, we need to use cross-validation or a holdout set
            # Simple approach: use the same test predictions as features
            stacking_features_train = stacking_features_test
            
            # Train meta-learner (simple logistic regression)
            meta_learner = LogisticRegression(random_state=42)
            meta_learner.fit(stacking_features_train, y_test)
            
            # Make final predictions
            y_pred_proba = meta_learner.predict_proba(stacking_features_test)[:, 1]
            y_pred = (y_pred_proba > 0.5).astype(int)
            
            # Calculate metrics
            metrics = self._calculate_metrics(y_test, y_pred, y_pred_proba)
            
            # Create wrapper class for the stacked model
            class StackedModel:
                def __init__(self, base_models, meta_learner, model_names):
                    self.base_models = base_models
                    self.meta_learner = meta_learner
                    self.model_names = model_names
                
                def predict(self, X):
                    # Get base predictions
                    base_preds = []
                    for name in self.model_names:
                        model_info = self.base_models[name]
                        model = model_info['model']
                        scaler = model_info['scaler']
                        
                        X_scaled = X
                        if scaler is not None:
                            X_scaled = scaler.transform(X)
                        
                        if hasattr(model, 'predict_proba'):
                            pred = model.predict_proba(X_scaled)[:, 1]
                        else:
                            pred = model.predict(X_scaled)
                        
                        base_preds.append(pred)
                    
                    stacking_features = np.column_stack(base_preds)
                    return self.meta_learner.predict(stacking_features)
                
                def predict_proba(self, X):
                    # Get base predictions
                    base_preds = []
                    for name in self.model_names:
                        model_info = self.base_models[name]
                        model = model_info['model']
                        scaler = model_info['scaler']
                        
                        X_scaled = X
                        if scaler is not None:
                            X_scaled = scaler.transform(X)
                        
                        if hasattr(model, 'predict_proba'):
                            pred = model.predict_proba(X_scaled)[:, 1]
                        else:
                            pred = model.predict(X_scaled)
                        
                        base_preds.append(pred)
                    
                    stacking_features = np.column_stack(base_preds)
                    return self.meta_learner.predict_proba(stacking_features)
            
            stacked_model = StackedModel(successful_models, meta_learner, model_names)
            
            print(f"   ✅ stacked_hybrid: F1={metrics['f1_score']:.3f}, "
                  f"AUC={metrics['roc_auc']:.3f} (ensemble of {len(model_names)} models)")
            
            return {
                'model': stacked_model,
                'scaler': None,  # Scaling handled internally
                'predictions': y_pred,
                'probabilities': y_pred_proba,
                'metrics': metrics,
                'success': True,
                'error': None
            }
            
        except Exception as e:
            print(f"   ❌ stacked_hybrid: {str(e)}")
            return {
                'model': None,
                'scaler': None,
                'predictions': None,
                'probabilities': None,
                'metrics': {},
                'success': False,
                'error': str(e)
            }
    
    def _calculate_metrics(self, 
                          y_true: np.ndarray, 
                          y_pred: np.ndarray, 
                          y_pred_proba: np.ndarray = None) -> Dict[str, float]:
        """Calculate comprehensive metrics for model evaluation."""
        
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted', zero_division=0),
            'recall': recall_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1_score': f1_score(y_true, y_pred, average='weighted', zero_division=0)
        }
        
        # Add AUC if probabilities available
        if y_pred_proba is not None:
            try:
                metrics['roc_auc'] = roc_auc_score(y_true, y_pred_proba)
            except ValueError:
                # Handle case where only one class is present
                metrics['roc_auc'] = 0.5
        else:
            metrics['roc_auc'] = 0.5
        
        # Add class-specific metrics
        try:
            # Precision and recall for each class
            precision_per_class = precision_score(y_true, y_pred, average=None, zero_division=0)
            recall_per_class = recall_score(y_true, y_pred, average=None, zero_division=0)
            
            if len(precision_per_class) >= 2:
                metrics['precision_class_0'] = precision_per_class[0]
                metrics['precision_class_1'] = precision_per_class[1]
                metrics['recall_class_0'] = recall_per_class[0]
                metrics['recall_class_1'] = recall_per_class[1]
        except:
            pass
        
        return metrics
    
    def get_available_models(self) -> List[str]:
        """Get list of available model families."""
        available = list(self.model_configs.keys())
        available.append('stacked_hybrid')  # Always available as ensemble
        return available
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Get information about a specific model family."""
        if model_name == 'stacked_hybrid':
            return {
                'name': 'stacked_hybrid',
                'description': 'Ensemble of multiple models using stacking',
                'type': 'ensemble',
                'needs_scaling': False,
                'interpretable': False
            }
        
        if model_name not in self.model_configs:
            return {}
        
        config = self.model_configs[model_name]
        
        info = {
            'name': model_name,
            'class': config['class'].__name__,
            'needs_scaling': config['needs_scaling'],
            'parameters': config['params']
        }
        
        # Add model-specific information
        if model_name == 'logistic_regression':
            info.update({
                'type': 'linear',
                'interpretable': True,
                'description': 'Linear classifier with logistic function'
            })
        elif model_name == 'random_forest':
            info.update({
                'type': 'ensemble',
                'interpretable': True,
                'description': 'Ensemble of decision trees'
            })
        elif model_name == 'gradient_boosting':
            info.update({
                'type': 'boosting',
                'interpretable': True,
                'description': 'Gradient boosting classifier'
            })
        elif model_name == 'xgboost':
            info.update({
                'type': 'boosting',
                'interpretable': True,
                'description': 'Extreme gradient boosting'
            })
        elif model_name == 'lightgbm':
            info.update({
                'type': 'boosting',
                'interpretable': True,
                'description': 'Light gradient boosting machine'
            })
        
        return info

if __name__ == "__main__":
    print("🧪 Testing Model Trainer...")
    
    # Create sample data
    np.random.seed(42)
    n_samples = 200
    n_features = 8
    
    X = np.random.random((n_samples, n_features))
    # Create some correlation with features to make it realistic
    y = ((X[:, 0] + X[:, 1] - X[:, 2] + np.random.normal(0, 0.3, n_samples)) > 0.5).astype(int)
    
    X_df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(n_features)])
    y_series = pd.Series(y)
    
    # Split data
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
        X_df, y_series, test_size=0.3, random_state=42, stratify=y_series
    )
    
    # Test trainer
    trainer = ModelTrainer()
    
    # Test available models
    available_models = trainer.get_available_models()
    print(f"✅ Available models: {len(available_models)} models")
    print(f"   Models: {', '.join(available_models)}")
    
    # Test single model training
    lr_result = trainer.train_single_model(
        'logistic_regression', X_train, y_train, X_test, y_test
    )
    
    lr_success = lr_result['success'] and lr_result['model'] is not None
    print(f"✅ Single model training: {'Success' if lr_success else 'Failed'}")
    
    if lr_success:
        print(f"   Accuracy: {lr_result['metrics']['accuracy']:.3f}")
        print(f"   F1 Score: {lr_result['metrics']['f1_score']:.3f}")
    
    # Test all models training
    print("Testing all models training...")
    all_results = trainer.train_all_models(X_train, y_train, X_test, y_test)
    
    successful_models = sum(1 for result in all_results.values() if result['success'])
    print(f"✅ All models training: {successful_models}/{len(all_results)} models successful")
    
    # Test stacked model
    stacked_success = all_results.get('stacked_hybrid', {}).get('success', False)
    print(f"✅ Stacked model: {'Success' if stacked_success else 'Failed'}")
    
    # Test model info
    lr_info = trainer.get_model_info('logistic_regression')
    info_success = 'name' in lr_info and 'type' in lr_info
    print(f"✅ Model info: {'Success' if info_success else 'Failed'}")
    
    print("✅ Model trainer tests completed!")
