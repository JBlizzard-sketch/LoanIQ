"""ML Engine for LoanIQ credit scoring system."""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import joblib
import os
import json
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score, accuracy_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
import warnings
warnings.filterwarnings('ignore')

from .model_manager import ModelManager
from .trainer import ModelTrainer

class MLEngine:
    """Main ML engine that coordinates training, prediction, and model management."""
    
    def __init__(self, model_dir: str = "models"):
        self.model_dir = model_dir
        self.model_manager = ModelManager(model_dir)
        self.trainer = ModelTrainer()
        
        # Auto-retrain settings
        self.retrain_threshold = 500
        self.retrain_days = 7
        self.last_retrain_date = None
        
        # Current deployed model
        self.current_model = None
        self.current_scaler = None
        self.feature_columns = None
        
        self._ensure_model_directory()
        self._load_current_model()
    
    def _ensure_model_directory(self):
        """Ensure model directory exists."""
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)
    
    def train_models(self, df: pd.DataFrame, target_column: str = 'defaulted') -> Dict[str, Any]:
        """Train all model families and return results."""
        print("🤖 Starting ML training pipeline...")
        
        # Validate input data
        if target_column not in df.columns:
            raise ValueError(f"Target column '{target_column}' not found in data")
        
        if df.empty:
            raise ValueError("Training data is empty")
        
        # Prepare data
        X, y = self._prepare_training_data(df, target_column)
        
        if X.empty or len(y) == 0:
            raise ValueError("No valid training data after preprocessing")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Train all models
        training_results = self.trainer.train_all_models(X_train, y_train, X_test, y_test)
        
        # Save all trained models
        for model_name, result in training_results.items():
            model_info = {
                'model': result['model'],
                'scaler': result['scaler'],
                'feature_columns': list(X.columns),
                'metrics': result['metrics'],
                'training_date': datetime.now().isoformat(),
                'training_samples': len(X_train),
                'model_family': model_name
            }
            
            version = self.model_manager.save_model(model_info, model_name)
            print(f"✅ Saved {model_name} as version {version}")
        
        # Deploy best model
        best_model_name = self._select_best_model(training_results)
        self._deploy_model(best_model_name)
        
        # Update retrain tracking
        self.last_retrain_date = datetime.now()
        
        summary = {
            'total_models_trained': len(training_results),
            'best_model': best_model_name,
            'training_samples': len(X_train),
            'test_samples': len(X_test),
            'feature_count': len(X.columns),
            'models_performance': {
                name: result['metrics'] for name, result in training_results.items()
            }
        }
        
        print(f"🎯 Training completed! Best model: {best_model_name}")
        return summary
    
    def _prepare_training_data(self, df: pd.DataFrame, target_column: str) -> Tuple[pd.DataFrame, pd.Series]:
        """Prepare data for training."""
        df_clean = df.copy()
        
        # Remove rows with missing target
        df_clean = df_clean.dropna(subset=[target_column])
        
        # Separate features and target
        y = df_clean[target_column]
        X = df_clean.drop(columns=[target_column])
        
        # Handle categorical columns
        categorical_columns = X.select_dtypes(include=['object', 'category']).columns
        for col in categorical_columns:
            # Simple label encoding for now
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col].astype(str))
        
        # Handle missing values
        X = X.fillna(X.mean())
        
        # Remove non-numeric columns that couldn't be encoded
        X = X.select_dtypes(include=[np.number])
        
        return X, y
    
    def _select_best_model(self, training_results: Dict[str, Any]) -> str:
        """Select the best model based on performance metrics."""
        best_model = None
        best_score = -1
        
        for model_name, result in training_results.items():
            # Use F1 score as primary metric, with AUC as tiebreaker
            metrics = result['metrics']
            
            # Calculate composite score
            f1_score = metrics.get('f1_score', 0)
            auc_score = metrics.get('roc_auc', 0)
            composite_score = 0.7 * f1_score + 0.3 * auc_score
            
            if composite_score > best_score:
                best_score = composite_score
                best_model = model_name
        
        return best_model or list(training_results.keys())[0]
    
    def _deploy_model(self, model_name: str):
        """Deploy a model as the current active model."""
        latest_version = self.model_manager.get_latest_version(model_name)
        
        if latest_version is None:
            print(f"❌ No model found for {model_name}")
            return False
        
        model_info = self.model_manager.load_model(model_name, latest_version)
        
        if model_info is None:
            print(f"❌ Failed to load model {model_name} v{latest_version}")
            return False
        
        self.current_model = model_info['model']
        self.current_scaler = model_info['scaler']
        self.feature_columns = model_info['feature_columns']
        
        # Mark as deployed
        self.model_manager.set_deployed_model(model_name, latest_version)
        
        print(f"🚀 Deployed {model_name} v{latest_version} as active model")
        return True
    
    def _load_current_model(self):
        """Load the currently deployed model."""
        deployed_info = self.model_manager.get_deployed_model()
        
        if deployed_info:
            model_name, version = deployed_info
            model_info = self.model_manager.load_model(model_name, version)
            
            if model_info:
                self.current_model = model_info['model']
                self.current_scaler = model_info['scaler']
                self.feature_columns = model_info['feature_columns']
                print(f"📦 Loaded deployed model: {model_name} v{version}")
    
    def predict(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Make predictions using the current deployed model."""
        if self.current_model is None:
            return {
                'error': 'No model deployed',
                'predictions': None,
                'probabilities': None
            }
        
        try:
            # Prepare prediction data
            X_pred = self._prepare_prediction_data(df)
            
            if X_pred.empty:
                return {
                    'error': 'No valid data for prediction',
                    'predictions': None,
                    'probabilities': None
                }
            
            # Scale features
            if self.current_scaler:
                X_pred_scaled = self.current_scaler.transform(X_pred)
            else:
                X_pred_scaled = X_pred
            
            # Make predictions
            predictions = self.current_model.predict(X_pred_scaled)
            
            # Get probabilities if available
            probabilities = None
            if hasattr(self.current_model, 'predict_proba'):
                probabilities = self.current_model.predict_proba(X_pred_scaled)
                # Get probability of default (class 1)
                probabilities = probabilities[:, 1] if probabilities.shape[1] > 1 else probabilities[:, 0]
            
            return {
                'error': None,
                'predictions': predictions.tolist(),
                'probabilities': probabilities.tolist() if probabilities is not None else None,
                'feature_count': len(X_pred.columns)
            }
            
        except Exception as e:
            return {
                'error': str(e),
                'predictions': None,
                'probabilities': None
            }
    
    def _prepare_prediction_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare data for prediction."""
        df_pred = df.copy()
        
        # Handle categorical columns (same as training)
        categorical_columns = df_pred.select_dtypes(include=['object', 'category']).columns
        for col in categorical_columns:
            le = LabelEncoder()
            df_pred[col] = le.fit_transform(df_pred[col].astype(str))
        
        # Handle missing values
        df_pred = df_pred.fillna(df_pred.mean())
        
        # Select only numeric columns
        df_pred = df_pred.select_dtypes(include=[np.number])
        
        # Ensure we have the same features as training
        if self.feature_columns:
            # Add missing columns with zeros
            for col in self.feature_columns:
                if col not in df_pred.columns:
                    df_pred[col] = 0
            
            # Select only training columns in the same order
            df_pred = df_pred[self.feature_columns]
        
        return df_pred
    
    def check_retrain_needed(self, current_data_count: int) -> bool:
        """Check if model retraining is needed."""
        # Check data threshold
        if current_data_count >= self.retrain_threshold:
            print(f"📊 Retrain needed: Data threshold reached ({current_data_count} >= {self.retrain_threshold})")
            return True
        
        # Check time threshold
        if self.last_retrain_date:
            days_since_retrain = (datetime.now() - self.last_retrain_date).days
            if days_since_retrain >= self.retrain_days:
                print(f"⏰ Retrain needed: Time threshold reached ({days_since_retrain} >= {self.retrain_days} days)")
                return True
        
        return False
    
    def auto_retrain(self, df: pd.DataFrame, target_column: str = 'defaulted') -> Optional[Dict[str, Any]]:
        """Automatically retrain models if needed."""
        if not self.check_retrain_needed(len(df)):
            return None
        
        print("🔄 Starting auto-retrain...")
        return self.train_models(df, target_column)
    
    def get_model_status(self) -> Dict[str, Any]:
        """Get current model status and information."""
        deployed_info = self.model_manager.get_deployed_model()
        all_models = self.model_manager.list_all_models()
        
        status = {
            'deployed_model': {
                'name': deployed_info[0] if deployed_info else None,
                'version': deployed_info[1] if deployed_info else None,
                'is_loaded': self.current_model is not None
            },
            'total_models': len(all_models),
            'available_models': all_models,
            'last_retrain_date': self.last_retrain_date.isoformat() if self.last_retrain_date else None,
            'retrain_threshold': self.retrain_threshold,
            'retrain_days': self.retrain_days
        }
        
        return status
    
    def run_model_stress_test(self, test_data: pd.DataFrame) -> Dict[str, Any]:
        """Run stress tests on the current model."""
        if self.current_model is None:
            return {'error': 'No model deployed'}
        
        try:
            # Generate prediction results
            pred_results = self.predict(test_data)
            
            if pred_results['error']:
                return {'error': pred_results['error']}
            
            predictions = pred_results['predictions']
            probabilities = pred_results['probabilities']
            
            # Calculate stress test metrics
            stress_results = {
                'total_predictions': len(predictions),
                'default_predictions': sum(predictions),
                'default_rate': sum(predictions) / len(predictions),
                'confidence_stats': {
                    'mean_probability': np.mean(probabilities) if probabilities else None,
                    'std_probability': np.std(probabilities) if probabilities else None,
                    'min_probability': min(probabilities) if probabilities else None,
                    'max_probability': max(probabilities) if probabilities else None
                },
                'prediction_distribution': {
                    'no_default': predictions.count(0),
                    'default': predictions.count(1)
                }
            }
            
            # Performance benchmarks
            if 'defaulted' in test_data.columns:
                actual = test_data['defaulted'].values
                stress_results['performance_metrics'] = {
                    'accuracy': accuracy_score(actual, predictions),
                    'roc_auc': roc_auc_score(actual, probabilities) if probabilities else None
                }
            
            return stress_results
            
        except Exception as e:
            return {'error': f'Stress test failed: {str(e)}'}

if __name__ == "__main__":
    print("🧪 Testing ML Engine...")
    
    # Create sample training data
    np.random.seed(42)
    sample_data = {
        'loan_amount': np.random.uniform(5000, 50000, 100),
        'interest_rate': np.random.uniform(5, 15, 100),
        'monthly_income': np.random.uniform(3000, 10000, 100),
        'debt_to_income': np.random.uniform(0.1, 0.6, 100),
        'employment_years': np.random.uniform(0, 15, 100),
        'defaulted': np.random.choice([0, 0, 0, 1], 100)  # 25% default rate
    }
    
    df = pd.DataFrame(sample_data)
    
    # Test ML engine
    engine = MLEngine("test_models")
    
    # Test training
    print("Testing model training...")
    try:
        results = engine.train_models(df)
        print(f"✅ Model training: {results['total_models_trained']} models trained")
        print(f"   Best model: {results['best_model']}")
    except Exception as e:
        print(f"❌ Model training failed: {e}")
        results = None
    
    # Test prediction
    print("Testing predictions...")
    if results:
        pred_data = df.head(10).drop(columns=['defaulted'])
        pred_results = engine.predict(pred_data)
        
        if pred_results['error'] is None:
            print(f"✅ Predictions: {len(pred_results['predictions'])} predictions made")
            default_rate = sum(pred_results['predictions']) / len(pred_results['predictions'])
            print(f"   Predicted default rate: {default_rate:.1%}")
        else:
            print(f"❌ Prediction failed: {pred_results['error']}")
    
    # Test model status
    status = engine.get_model_status()
    print(f"✅ Model status: {status['total_models']} models available")
    print(f"   Deployed: {status['deployed_model']['name']} v{status['deployed_model']['version']}")
    
    # Test retrain check
    needs_retrain = engine.check_retrain_needed(600)  # Above threshold
    print(f"✅ Retrain check: {'Needed' if needs_retrain else 'Not needed'}")
    
    # Test stress test
    if results:
        stress_results = engine.run_model_stress_test(df.head(20))
        if 'error' not in stress_results:
            print(f"✅ Stress test: {stress_results['total_predictions']} predictions tested")
        else:
            print(f"❌ Stress test failed: {stress_results['error']}")
    
    print("✅ ML Engine tests completed!")
