"""Model management system for LoanIQ ML engine."""
import os
import json
import joblib
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import shutil

class ModelManager:
    """Manages ML model versions, storage, and deployment."""
    
    def __init__(self, model_dir: str = "models"):
        self.model_dir = model_dir
        self.metadata_file = os.path.join(model_dir, "model_metadata.json")
        self.deployed_file = os.path.join(model_dir, "deployed_model.json")
        
        self._ensure_directories()
        self._load_metadata()
    
    def _ensure_directories(self):
        """Ensure all necessary directories exist."""
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)
    
    def _load_metadata(self):
        """Load model metadata from file."""
        if os.path.exists(self.metadata_file):
            try:
                with open(self.metadata_file, 'r') as f:
                    self.metadata = json.load(f)
            except Exception:
                self.metadata = {}
        else:
            self.metadata = {}
    
    def _save_metadata(self):
        """Save model metadata to file."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            print(f"Error saving metadata: {e}")
    
    def save_model(self, model_info: Dict[str, Any], model_name: str) -> str:
        """Save a model and return its version."""
        # Generate version
        version = self._generate_version(model_name)
        
        # Create model directory
        model_path = os.path.join(self.model_dir, model_name, version)
        os.makedirs(model_path, exist_ok=True)
        
        # Save model components
        try:
            # Save the actual model
            model_file = os.path.join(model_path, "model.joblib")
            joblib.dump(model_info['model'], model_file)
            
            # Save scaler if present
            if model_info.get('scaler'):
                scaler_file = os.path.join(model_path, "scaler.joblib")
                joblib.dump(model_info['scaler'], scaler_file)
            
            # Save metadata
            metadata = {
                'model_family': model_info.get('model_family', model_name),
                'feature_columns': model_info.get('feature_columns', []),
                'metrics': model_info.get('metrics', {}),
                'training_date': model_info.get('training_date', datetime.now().isoformat()),
                'training_samples': model_info.get('training_samples', 0),
                'version': version,
                'model_file': model_file,
                'scaler_file': scaler_file if model_info.get('scaler') else None
            }
            
            metadata_file = os.path.join(model_path, "metadata.json")
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            # Update global metadata
            if model_name not in self.metadata:
                self.metadata[model_name] = {'versions': {}}
            
            self.metadata[model_name]['versions'][version] = {
                'created_at': datetime.now().isoformat(),
                'metrics': model_info.get('metrics', {}),
                'path': model_path,
                'training_samples': model_info.get('training_samples', 0)
            }
            
            self.metadata[model_name]['latest_version'] = version
            self._save_metadata()
            
            return version
            
        except Exception as e:
            print(f"Error saving model {model_name}: {e}")
            # Cleanup on failure
            if os.path.exists(model_path):
                shutil.rmtree(model_path)
            raise
    
    def load_model(self, model_name: str, version: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Load a specific model version."""
        if model_name not in self.metadata:
            return None
        
        if version is None:
            version = self.metadata[model_name].get('latest_version')
        
        if not version or version not in self.metadata[model_name]['versions']:
            return None
        
        model_path = self.metadata[model_name]['versions'][version]['path']
        
        try:
            # Load model
            model_file = os.path.join(model_path, "model.joblib")
            if not os.path.exists(model_file):
                return None
            
            model = joblib.load(model_file)
            
            # Load scaler if exists
            scaler_file = os.path.join(model_path, "scaler.joblib")
            scaler = None
            if os.path.exists(scaler_file):
                scaler = joblib.load(scaler_file)
            
            # Load metadata
            metadata_file = os.path.join(model_path, "metadata.json")
            metadata = {}
            if os.path.exists(metadata_file):
                with open(metadata_file, 'r') as f:
                    metadata = json.load(f)
            
            return {
                'model': model,
                'scaler': scaler,
                'feature_columns': metadata.get('feature_columns', []),
                'metrics': metadata.get('metrics', {}),
                'version': version,
                'training_date': metadata.get('training_date'),
                'model_family': metadata.get('model_family', model_name)
            }
            
        except Exception as e:
            print(f"Error loading model {model_name} v{version}: {e}")
            return None
    
    def _generate_version(self, model_name: str) -> str:
        """Generate a new version for a model."""
        if model_name not in self.metadata:
            return "v1.0.0"
        
        versions = list(self.metadata[model_name]['versions'].keys())
        if not versions:
            return "v1.0.0"
        
        # Simple versioning: increment patch version
        latest = self.metadata[model_name].get('latest_version', 'v1.0.0')
        
        try:
            # Parse version (e.g., "v1.2.3")
            version_parts = latest[1:].split('.')
            major, minor, patch = map(int, version_parts)
            
            # Increment patch version
            patch += 1
            return f"v{major}.{minor}.{patch}"
            
        except Exception:
            # Fallback: use timestamp-based version
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            return f"v{timestamp}"
    
    def list_model_versions(self, model_name: str) -> List[Dict[str, Any]]:
        """List all versions of a specific model."""
        if model_name not in self.metadata:
            return []
        
        versions = []
        for version, info in self.metadata[model_name]['versions'].items():
            version_info = {
                'version': version,
                'created_at': info['created_at'],
                'metrics': info.get('metrics', {}),
                'training_samples': info.get('training_samples', 0),
                'is_latest': version == self.metadata[model_name].get('latest_version')
            }
            versions.append(version_info)
        
        # Sort by creation date (newest first)
        versions.sort(key=lambda x: x['created_at'], reverse=True)
        return versions
    
    def list_all_models(self) -> List[str]:
        """List all available model families."""
        return list(self.metadata.keys())
    
    def get_latest_version(self, model_name: str) -> Optional[str]:
        """Get the latest version of a model."""
        if model_name not in self.metadata:
            return None
        return self.metadata[model_name].get('latest_version')
    
    def delete_model_version(self, model_name: str, version: str) -> bool:
        """Delete a specific model version."""
        if (model_name not in self.metadata or 
            version not in self.metadata[model_name]['versions']):
            return False
        
        try:
            # Remove files
            model_path = self.metadata[model_name]['versions'][version]['path']
            if os.path.exists(model_path):
                shutil.rmtree(model_path)
            
            # Update metadata
            del self.metadata[model_name]['versions'][version]
            
            # Update latest version if necessary
            if self.metadata[model_name].get('latest_version') == version:
                remaining_versions = list(self.metadata[model_name]['versions'].keys())
                if remaining_versions:
                    # Set the most recent remaining version as latest
                    latest_info = max(
                        self.metadata[model_name]['versions'].items(),
                        key=lambda x: x[1]['created_at']
                    )
                    self.metadata[model_name]['latest_version'] = latest_info[0]
                else:
                    # No versions left
                    del self.metadata[model_name]
            
            self._save_metadata()
            return True
            
        except Exception as e:
            print(f"Error deleting model version {model_name} v{version}: {e}")
            return False
    
    def set_deployed_model(self, model_name: str, version: str):
        """Mark a model version as deployed."""
        deployed_info = {
            'model_name': model_name,
            'version': version,
            'deployed_at': datetime.now().isoformat()
        }
        
        try:
            with open(self.deployed_file, 'w') as f:
                json.dump(deployed_info, f, indent=2)
        except Exception as e:
            print(f"Error setting deployed model: {e}")
    
    def get_deployed_model(self) -> Optional[Tuple[str, str]]:
        """Get the currently deployed model."""
        if not os.path.exists(self.deployed_file):
            return None
        
        try:
            with open(self.deployed_file, 'r') as f:
                deployed_info = json.load(f)
            
            model_name = deployed_info['model_name']
            version = deployed_info['version']
            
            # Verify the model still exists
            if (model_name in self.metadata and 
                version in self.metadata[model_name]['versions']):
                return (model_name, version)
            else:
                # Deployed model no longer exists
                os.remove(self.deployed_file)
                return None
                
        except Exception:
            return None
    
    def get_model_metrics(self, model_name: str, version: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get metrics for a specific model version."""
        if model_name not in self.metadata:
            return None
        
        if version is None:
            version = self.metadata[model_name].get('latest_version')
        
        if not version or version not in self.metadata[model_name]['versions']:
            return None
        
        return self.metadata[model_name]['versions'][version].get('metrics', {})
    
    def cleanup_old_versions(self, model_name: str, keep_count: int = 5) -> int:
        """Keep only the most recent versions of a model."""
        if model_name not in self.metadata:
            return 0
        
        versions = self.list_model_versions(model_name)
        
        if len(versions) <= keep_count:
            return 0
        
        # Delete oldest versions
        deleted_count = 0
        for version_info in versions[keep_count:]:
            if self.delete_model_version(model_name, version_info['version']):
                deleted_count += 1
        
        return deleted_count
    
    def get_storage_usage(self) -> Dict[str, Any]:
        """Get storage usage information."""
        total_size = 0
        model_count = 0
        
        if os.path.exists(self.model_dir):
            for root, dirs, files in os.walk(self.model_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    total_size += os.path.getsize(file_path)
            
            model_count = len(self.metadata)
        
        total_size_mb = total_size / (1024 * 1024)
        
        return {
            'total_size_mb': round(total_size_mb, 2),
            'model_families': model_count,
            'total_versions': sum(len(model_info['versions']) 
                                for model_info in self.metadata.values())
        }

if __name__ == "__main__":
    print("🧪 Testing Model Manager...")
    
    import numpy as np
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    
    # Create test model
    X = np.random.random((100, 5))
    y = np.random.randint(0, 2, 100)
    
    model = LogisticRegression()
    model.fit(X, y)
    
    scaler = StandardScaler()
    scaler.fit(X)
    
    # Test model manager
    manager = ModelManager("test_models")
    
    # Test saving model
    model_info = {
        'model': model,
        'scaler': scaler,
        'feature_columns': ['feature_1', 'feature_2', 'feature_3', 'feature_4', 'feature_5'],
        'metrics': {'accuracy': 0.85, 'f1_score': 0.82},
        'training_samples': 100,
        'model_family': 'logistic_regression'
    }
    
    version = manager.save_model(model_info, 'test_model')
    print(f"✅ Model saved: version {version}")
    
    # Test loading model
    loaded_model = manager.load_model('test_model', version)
    load_success = loaded_model is not None and 'model' in loaded_model
    print(f"✅ Model loading: {'Success' if load_success else 'Failed'}")
    
    # Test version listing
    versions = manager.list_model_versions('test_model')
    print(f"✅ Version listing: {len(versions)} versions found")
    
    # Test deployment
    manager.set_deployed_model('test_model', version)
    deployed = manager.get_deployed_model()
    deployment_success = deployed is not None and deployed[0] == 'test_model'
    print(f"✅ Model deployment: {'Success' if deployment_success else 'Failed'}")
    
    # Test metrics retrieval
    metrics = manager.get_model_metrics('test_model', version)
    metrics_success = metrics is not None and 'accuracy' in metrics
    print(f"✅ Metrics retrieval: {'Success' if metrics_success else 'Failed'}")
    
    # Test storage usage
    usage = manager.get_storage_usage()
    print(f"✅ Storage usage: {usage['model_families']} families, {usage['total_size_mb']} MB")
    
    # Cleanup
    manager.delete_model_version('test_model', version)
    print("✅ Model manager tests completed!")
