"""Authentication manager for LoanIQ application."""
import hashlib
import sqlite3
from datetime import datetime, timedelta
from enum import Enum
from dataclasses import dataclass
from typing import Optional, List, Dict, Any
import secrets
import os

class UserRole(Enum):
    """User roles enum."""
    CLIENT = "client"
    ADMIN = "admin"

@dataclass
class User:
    """User data class."""
    id: int
    username: str
    email: str
    role: UserRole
    created_at: datetime
    last_login: Optional[datetime] = None
    is_active: bool = True

class AuthManager:
    """Handles authentication and user management."""
    
    def __init__(self, db_path: str = "loaniq_auth.db"):
        self.db_path = db_path
        self.session_timeout = timedelta(hours=24)
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        self._init_database()
    
    def _init_database(self):
        """Initialize the authentication database."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'client',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP,
                    is_active BOOLEAN DEFAULT 1
                )
            """)
            
            # Create sessions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expires_at TIMESTAMP NOT NULL,
                    is_active BOOLEAN DEFAULT 1,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            """)
            
            conn.commit()
    
    def _hash_password(self, password: str) -> str:
        """Hash a password using SHA-256 with salt."""
        salt = os.urandom(32)
        pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
        return salt.hex() + pwd_hash.hex()
    
    def _verify_password(self, stored_password: str, provided_password: str) -> bool:
        """Verify a password against its hash."""
        try:
            salt = bytes.fromhex(stored_password[:64])
            stored_hash = stored_password[64:]
            pwd_hash = hashlib.pbkdf2_hmac('sha256', provided_password.encode('utf-8'), salt, 100000)
            return pwd_hash.hex() == stored_hash
        except Exception:
            return False
    
    def register_user(self, username: str, email: str, password: str, role: UserRole = UserRole.CLIENT) -> Optional[User]:
        """Register a new user."""
        try:
            password_hash = self._hash_password(password)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO users (username, email, password_hash, role)
                    VALUES (?, ?, ?, ?)
                """, (username, email, password_hash, role.value))
                
                user_id = cursor.lastrowid
                conn.commit()
                
                return User(
                    id=user_id,
                    username=username,
                    email=email,
                    role=role,
                    created_at=datetime.now()
                )
        except sqlite3.IntegrityError:
            return None  # User already exists
    
    def authenticate(self, username: str, password: str) -> Optional[str]:
        """Authenticate user and return session token."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, password_hash, role FROM users 
                WHERE username = ? AND is_active = 1
            """, (username,))
            
            result = cursor.fetchone()
            if not result:
                return None
            
            user_id, stored_password, role = result
            
            if not self._verify_password(stored_password, password):
                return None
            
            # Update last login
            cursor.execute("""
                UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
            """, (user_id,))
            
            # Create session
            session_id = secrets.token_urlsafe(32)
            expires_at = datetime.now() + self.session_timeout
            
            cursor.execute("""
                INSERT INTO sessions (session_id, user_id, expires_at)
                VALUES (?, ?, ?)
            """, (session_id, user_id, expires_at))
            
            conn.commit()
            
            # Store in memory for quick access
            self.active_sessions[session_id] = {
                'user_id': user_id,
                'expires_at': expires_at
            }
            
            return session_id
    
    def get_user_by_session(self, session_id: str) -> Optional[User]:
        """Get user by session ID."""
        # Check memory first
        if session_id in self.active_sessions:
            session_data = self.active_sessions[session_id]
            if datetime.now() > session_data['expires_at']:
                del self.active_sessions[session_id]
                return None
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT u.id, u.username, u.email, u.role, u.created_at, u.last_login
                FROM users u
                JOIN sessions s ON u.id = s.user_id
                WHERE s.session_id = ? AND s.is_active = 1 AND s.expires_at > CURRENT_TIMESTAMP
            """, (session_id,))
            
            result = cursor.fetchone()
            if not result:
                return None
            
            user_id, username, email, role, created_at, last_login = result
            
            return User(
                id=user_id,
                username=username,
                email=email,
                role=UserRole(role),
                created_at=datetime.fromisoformat(created_at),
                last_login=datetime.fromisoformat(last_login) if last_login else None
            )
    
    def logout(self, session_id: str) -> bool:
        """Logout user by invalidating session."""
        try:
            # Remove from memory
            if session_id in self.active_sessions:
                del self.active_sessions[session_id]
            
            # Deactivate in database
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE sessions SET is_active = 0 WHERE session_id = ?
                """, (session_id,))
                conn.commit()
            
            return True
        except Exception:
            return False
    
    def is_admin(self, session_id: str) -> bool:
        """Check if user is admin."""
        user = self.get_user_by_session(session_id)
        return user is not None and user.role == UserRole.ADMIN
    
    def get_all_users(self) -> List[User]:
        """Get all users (admin only)."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, username, email, role, created_at, last_login, is_active
                FROM users ORDER BY created_at DESC
            """)
            
            users = []
            for row in cursor.fetchall():
                user_id, username, email, role, created_at, last_login, is_active = row
                users.append(User(
                    id=user_id,
                    username=username,
                    email=email,
                    role=UserRole(role),
                    created_at=datetime.fromisoformat(created_at),
                    last_login=datetime.fromisoformat(last_login) if last_login else None,
                    is_active=bool(is_active)
                ))
            
            return users
    
    def cleanup_expired_sessions(self):
        """Clean up expired sessions."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE sessions SET is_active = 0 
                WHERE expires_at < CURRENT_TIMESTAMP AND is_active = 1
            """)
            conn.commit()
        
        # Clean memory
        expired_sessions = []
        for session_id, data in self.active_sessions.items():
            if datetime.now() > data['expires_at']:
                expired_sessions.append(session_id)
        
        for session_id in expired_sessions:
            del self.active_sessions[session_id]

if __name__ == "__main__":
    # Test authentication system
    print("🧪 Testing Authentication Module...")
    
    # Initialize auth manager
    auth = AuthManager(":memory:")
    
    # Test user registration
    user = auth.register_user("testuser", "test@example.com", "password123", UserRole.CLIENT)
    print(f"✅ User registration: {user.username if user else 'Failed'}")
    
    # Test admin registration
    admin = auth.register_user("admin", "admin@example.com", "admin123", UserRole.ADMIN)
    print(f"✅ Admin registration: {admin.username if admin else 'Failed'}")
    
    # Test authentication
    session_id = auth.authenticate("testuser", "password123")
    print(f"✅ User authentication: {'Success' if session_id else 'Failed'}")
    
    # Test session validation
    authenticated_user = auth.get_user_by_session(session_id)
    print(f"✅ Session validation: {authenticated_user.username if authenticated_user else 'Failed'}")
    
    # Test admin check
    admin_session = auth.authenticate("admin", "admin123")
    is_admin = auth.is_admin(admin_session)
    print(f"✅ Admin check: {'Yes' if is_admin else 'No'}")
    
    # Test logout
    logout_success = auth.logout(session_id)
    print(f"✅ Logout: {'Success' if logout_success else 'Failed'}")
    
    print("✅ Authentication module tests passed!")
