"""Admin workflows and tools for LoanIQ."""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import json
import os

from ..synth.data_generator import SyntheticDataGenerator
from ..ml.engine import MLEngine
from ..schema.backup_manager import SchemaBackupManager
from ..schema.validator import SchemaValidator
from ..schema.preprocessor import DataPreprocessor

class AdminWorkflows:
    """Comprehensive admin workflows for LoanIQ management."""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
        # Initialize components
        self.data_generator = SyntheticDataGenerator()
        self.ml_engine = MLEngine()
        self.backup_manager = SchemaBackupManager()
        self.validator = SchemaValidator()
        self.preprocessor = DataPreprocessor()
        
        # Admin operation history
        self.operation_history = []
    
    def generate_synthetic_data(self, 
                              num_records: int = 100,
                              existing_clients: Optional[List[int]] = None,
                              with_history: bool = False) -> Dict[str, Any]:
        """Generate synthetic loan data."""
        try:
            start_time = datetime.now()
            
            if with_history:
                df = self.data_generator.generate_client_history_data(
                    num_clients=num_records // 2,
                    loans_per_client=2
                )
            else:
                df = self.data_generator.generate_loan_data(
                    num_records=num_records,
                    existing_clients=existing_clients
                )
            
            # Validate generated data
            is_valid, errors = self.validator.validate_dataframe(df)
            
            # Get generation statistics
            stats = self.data_generator.get_generation_statistics(df)
            
            result = {
                'success': True,
                'data': df,
                'records_generated': len(df),
                'unique_clients': df['client_id'].nunique(),
                'generation_time_seconds': (datetime.now() - start_time).total_seconds(),
                'validation_passed': is_valid,
                'validation_errors': errors,
                'statistics': stats,
                'error': None
            }
            
            # Log operation
            self._log_operation('generate_synthetic_data', {
                'records_generated': len(df),
                'validation_passed': is_valid
            })
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'data': None,
                'error': str(e),
                'records_generated': 0
            }
    
    def retrain_all_models(self, 
                          training_data: pd.DataFrame,
                          force_retrain: bool = False) -> Dict[str, Any]:
        """Retrain all ML models with new data."""
        try:
            start_time = datetime.now()
            
            # Validate training data
            is_valid, errors = self.validator.validate_dataframe(training_data)
            if not is_valid and not force_retrain:
                return {
                    'success': False,
                    'error': f'Invalid training data: {errors}',
                    'validation_errors': errors
                }
            
            # Preprocess data
            processed_data = self.preprocessor.preprocess_loan_data(training_data)
            
            # Check if retrain is needed (unless forced)
            if not force_retrain:
                retrain_needed = self.ml_engine.check_retrain_needed(len(processed_data))
                if not retrain_needed:
                    return {
                        'success': False,
                        'error': 'Retrain not needed based on current thresholds',
                        'retrain_needed': False
                    }
            
            # Perform training
            training_results = self.ml_engine.train_models(processed_data)
            
            training_time = (datetime.now() - start_time).total_seconds()
            
            result = {
                'success': True,
                'training_results': training_results,
                'training_time_seconds': training_time,
                'data_records': len(processed_data),
                'models_trained': training_results['total_models_trained'],
                'best_model': training_results['best_model'],
                'error': None
            }
            
            # Log operation
            self._log_operation('retrain_models', {
                'models_trained': training_results['total_models_trained'],
                'best_model': training_results['best_model'],
                'training_time': training_time
            })
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'training_results': None
            }
    
    def run_comprehensive_stress_test(self, 
                                    test_scenarios: Optional[List[str]] = None) -> Dict[str, Any]:
        """Run comprehensive stress tests on the ML system."""
        try:
            start_time = datetime.now()
            
            stress_results = {
                'overall_status': 'PASS',
                'test_scenarios': {},
                'summary': {},
                'recommendations': []
            }
            
            # Default test scenarios
            if test_scenarios is None:
                test_scenarios = [
                    'normal_load',
                    'high_default_rate',
                    'edge_case_values',
                    'missing_data',
                    'performance_load'
                ]
            
            for scenario in test_scenarios:
                print(f"Running stress test: {scenario}")
                scenario_result = self._run_stress_scenario(scenario)
                stress_results['test_scenarios'][scenario] = scenario_result
                
                if not scenario_result.get('passed', False):
                    stress_results['overall_status'] = 'FAIL'
            
            # Generate summary
            total_tests = len(test_scenarios)
            passed_tests = sum(1 for result in stress_results['test_scenarios'].values() 
                             if result.get('passed', False))
            
            stress_results['summary'] = {
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'failed_tests': total_tests - passed_tests,
                'pass_rate': passed_tests / total_tests,
                'test_duration_seconds': (datetime.now() - start_time).total_seconds()
            }
            
            # Generate recommendations
            if stress_results['overall_status'] == 'FAIL':
                stress_results['recommendations'].append(
                    "Some stress tests failed. Review individual test results."
                )
            
            # Log operation
            self._log_operation('stress_test', {
                'overall_status': stress_results['overall_status'],
                'pass_rate': stress_results['summary']['pass_rate']
            })
            
            return stress_results
            
        except Exception as e:
            return {
                'overall_status': 'ERROR',
                'error': str(e),
                'test_scenarios': {},
                'summary': {}
            }
    
    def _run_stress_scenario(self, scenario: str) -> Dict[str, Any]:
        """Run a specific stress test scenario."""
        try:
            if scenario == 'normal_load':
                # Test with normal synthetic data
                test_data = self.data_generator.generate_loan_data(100)
                test_data = self.preprocessor.preprocess_loan_data(test_data)
                
                # Remove target for prediction
                prediction_data = test_data.drop(columns=['defaulted'] if 'defaulted' in test_data.columns else [])
                
                # Run prediction
                pred_results = self.ml_engine.predict(prediction_data)
                
                return {
                    'passed': pred_results['error'] is None,
                    'details': pred_results,
                    'metrics': {
                        'prediction_count': len(pred_results.get('predictions', [])),
                        'error': pred_results['error']
                    }
                }
            
            elif scenario == 'high_default_rate':
                # Test with high-risk synthetic data
                test_data = self.data_generator.generate_loan_data(50)
                
                # Artificially increase default indicators
                test_data['previous_defaults'] = np.random.choice([2, 3, 4], len(test_data))
                test_data['debt_to_income'] = test_data['debt_payments'] / test_data['monthly_income']
                test_data['debt_to_income'] = np.clip(test_data['debt_to_income'], 0.4, 0.8)
                
                test_data = self.preprocessor.preprocess_loan_data(test_data)
                prediction_data = test_data.drop(columns=['defaulted'] if 'defaulted' in test_data.columns else [])
                
                pred_results = self.ml_engine.predict(prediction_data)
                
                # Check if model detects high risk
                if pred_results['predictions']:
                    default_rate = sum(pred_results['predictions']) / len(pred_results['predictions'])
                    passed = default_rate > 0.3  # Expect higher default predictions
                else:
                    passed = False
                
                return {
                    'passed': passed and pred_results['error'] is None,
                    'details': pred_results,
                    'metrics': {
                        'predicted_default_rate': default_rate if pred_results['predictions'] else 0,
                        'expected_high_risk': True
                    }
                }
            
            elif scenario == 'edge_case_values':
                # Test with edge case values
                edge_data = pd.DataFrame({
                    'loan_amount': [1000, 80000, 50000],  # Min, max, normal
                    'interest_rate': [1.0, 25.0, 10.0],   # Min, max, normal
                    'monthly_income': [2000, 15000, 5000], # Low, high, normal
                    'debt_payments': [0, 3000, 1000],      # Min, high, normal
                    'term_months': [6, 360, 48],           # Min, max, normal
                    'employment_years': [0, 30, 5],        # Min, high, normal
                    'credit_history_years': [0, 25, 8],    # Min, high, normal
                    'previous_defaults': [0, 5, 1],        # Min, high, normal
                    'client_id': [1, 2, 3]
                })
                
                edge_data = self.preprocessor.preprocess_loan_data(edge_data)
                prediction_data = edge_data.drop(columns=['defaulted'] if 'defaulted' in edge_data.columns else [])
                
                pred_results = self.ml_engine.predict(prediction_data)
                
                return {
                    'passed': pred_results['error'] is None,
                    'details': pred_results,
                    'metrics': {
                        'edge_cases_handled': pred_results['error'] is None,
                        'predictions_made': len(pred_results.get('predictions', []))
                    }
                }
            
            elif scenario == 'missing_data':
                # Test with missing data
                test_data = self.data_generator.generate_loan_data(20)
                
                # Introduce missing values
                for col in ['employment_years', 'debt_payments']:
                    if col in test_data.columns:
                        mask = np.random.random(len(test_data)) < 0.3
                        test_data.loc[mask, col] = np.nan
                
                test_data = self.preprocessor.preprocess_loan_data(test_data)
                prediction_data = test_data.drop(columns=['defaulted'] if 'defaulted' in test_data.columns else [])
                
                pred_results = self.ml_engine.predict(prediction_data)
                
                return {
                    'passed': pred_results['error'] is None,
                    'details': pred_results,
                    'metrics': {
                        'missing_data_handled': pred_results['error'] is None
                    }
                }
            
            elif scenario == 'performance_load':
                # Test with larger data load
                large_data = self.data_generator.generate_loan_data(500)
                large_data = self.preprocessor.preprocess_loan_data(large_data)
                prediction_data = large_data.drop(columns=['defaulted'] if 'defaulted' in large_data.columns else [])
                
                start_pred_time = datetime.now()
                pred_results = self.ml_engine.predict(prediction_data)
                prediction_time = (datetime.now() - start_pred_time).total_seconds()
                
                # Performance criteria: should handle 500 predictions in under 10 seconds
                performance_passed = prediction_time < 10 and pred_results['error'] is None
                
                return {
                    'passed': performance_passed,
                    'details': pred_results,
                    'metrics': {
                        'prediction_time_seconds': prediction_time,
                        'records_processed': len(prediction_data),
                        'performance_acceptable': performance_passed
                    }
                }
            
            else:
                return {
                    'passed': False,
                    'error': f'Unknown stress test scenario: {scenario}',
                    'details': {},
                    'metrics': {}
                }
                
        except Exception as e:
            return {
                'passed': False,
                'error': str(e),
                'details': {},
                'metrics': {}
            }
    
    def backup_current_schema(self, 
                            current_data: pd.DataFrame,
                            description: str = "") -> Dict[str, Any]:
        """Create a backup of the current schema and data."""
        try:
            backup_id = self.backup_manager.create_backup(
                current_data, 
                "loan_schema", 
                description
            )
            
            result = {
                'success': True,
                'backup_id': backup_id,
                'backup_size': len(current_data),
                'error': None
            }
            
            # Log operation
            self._log_operation('schema_backup', {
                'backup_id': backup_id,
                'records_backed_up': len(current_data)
            })
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'backup_id': None,
                'error': str(e)
            }
    
    def restore_schema_backup(self, backup_id: str) -> Dict[str, Any]:
        """Restore a schema backup."""
        try:
            restored_data = self.backup_manager.restore_backup(backup_id)
            
            if restored_data is None:
                return {
                    'success': False,
                    'error': f'Backup {backup_id} not found or could not be restored',
                    'data': None
                }
            
            result = {
                'success': True,
                'data': restored_data,
                'records_restored': len(restored_data),
                'backup_id': backup_id,
                'error': None
            }
            
            # Log operation
            self._log_operation('schema_restore', {
                'backup_id': backup_id,
                'records_restored': len(restored_data)
            })
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'data': None
            }
    
    def manage_model_versions(self, action: str, **kwargs) -> Dict[str, Any]:
        """Manage ML model versions."""
        try:
            if action == 'list_all':
                models = self.ml_engine.model_manager.list_all_models()
                versions_info = {}
                
                for model_name in models:
                    versions_info[model_name] = self.ml_engine.model_manager.list_model_versions(model_name)
                
                return {
                    'success': True,
                    'models': models,
                    'versions_info': versions_info,
                    'total_models': len(models)
                }
            
            elif action == 'deploy':
                model_name = kwargs.get('model_name')
                version = kwargs.get('version')
                
                if not model_name:
                    return {'success': False, 'error': 'model_name required'}
                
                success = self.ml_engine._deploy_model(model_name)
                
                if success:
                    self._log_operation('model_deploy', {
                        'model_name': model_name,
                        'version': version or 'latest'
                    })
                
                return {
                    'success': success,
                    'model_name': model_name,
                    'version': version,
                    'error': None if success else 'Deployment failed'
                }
            
            elif action == 'delete':
                model_name = kwargs.get('model_name')
                version = kwargs.get('version')
                
                if not model_name or not version:
                    return {'success': False, 'error': 'model_name and version required'}
                
                success = self.ml_engine.model_manager.delete_model_version(model_name, version)
                
                if success:
                    self._log_operation('model_delete', {
                        'model_name': model_name,
                        'version': version
                    })
                
                return {
                    'success': success,
                    'model_name': model_name,
                    'version': version,
                    'error': None if success else 'Deletion failed'
                }
            
            else:
                return {'success': False, 'error': f'Unknown action: {action}'}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def get_system_health_report(self) -> Dict[str, Any]:
        """Generate comprehensive system health report."""
        try:
            # ML system status
            ml_status = self.ml_engine.get_model_status()
            
            # Storage usage
            model_storage = self.ml_engine.model_manager.get_storage_usage()
            backup_storage = self.backup_manager.get_storage_usage()
            
            # Recent operations
            recent_operations = self.operation_history[-10:] if self.operation_history else []
            
            health_report = {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'HEALTHY',
                'components': {
                    'ml_engine': {
                        'status': 'ACTIVE' if ml_status['deployed_model']['is_loaded'] else 'INACTIVE',
                        'deployed_model': ml_status['deployed_model'],
                        'available_models': ml_status['total_models']
                    },
                    'storage': {
                        'models': model_storage,
                        'backups': backup_storage,
                        'total_usage_mb': model_storage['total_size_mb'] + backup_storage['total_size_mb']
                    },
                    'operations': {
                        'recent_count': len(recent_operations),
                        'last_operation': recent_operations[-1] if recent_operations else None
                    }
                },
                'recommendations': []
            }
            
            # Add health recommendations
            if not ml_status['deployed_model']['is_loaded']:
                health_report['overall_status'] = 'WARNING'
                health_report['recommendations'].append('No ML model is currently deployed')
            
            if model_storage['total_size_mb'] > 1000:  # > 1GB
                health_report['recommendations'].append('Model storage usage is high - consider cleanup')
            
            if len(recent_operations) == 0:
                health_report['recommendations'].append('No recent admin operations detected')
            
            return health_report
            
        except Exception as e:
            return {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'ERROR',
                'error': str(e),
                'components': {},
                'recommendations': ['System health check failed']
            }
    
    def _log_operation(self, operation_type: str, details: Dict[str, Any]):
        """Log admin operation for audit trail."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'operation_type': operation_type,
            'details': details
        }
        
        self.operation_history.append(log_entry)
        
        # Keep only last 100 operations
        if len(self.operation_history) > 100:
            self.operation_history = self.operation_history[-100:]
    
    def get_operation_history(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent operation history."""
        return self.operation_history[-limit:] if self.operation_history else []
    
    def cleanup_system(self) -> Dict[str, Any]:
        """Perform system cleanup operations."""
        try:
            cleanup_results = {
                'operations_performed': [],
                'storage_freed_mb': 0,
                'errors': []
            }
            
            # Cleanup old model versions (keep last 3 of each family)
            try:
                models = self.ml_engine.model_manager.list_all_models()
                for model_name in models:
                    deleted_count = self.ml_engine.model_manager.cleanup_old_versions(model_name, keep_count=3)
                    if deleted_count > 0:
                        cleanup_results['operations_performed'].append(
                            f'Deleted {deleted_count} old versions of {model_name}'
                        )
            except Exception as e:
                cleanup_results['errors'].append(f'Model cleanup error: {str(e)}')
            
            # Cleanup old backups (keep last 10)
            try:
                deleted_count = self.backup_manager.cleanup_old_backups(keep_count=10)
                if deleted_count > 0:
                    cleanup_results['operations_performed'].append(
                        f'Deleted {deleted_count} old schema backups'
                    )
            except Exception as e:
                cleanup_results['errors'].append(f'Backup cleanup error: {str(e)}')
            
            # Log cleanup operation
            self._log_operation('system_cleanup', cleanup_results)
            
            return {
                'success': True,
                'cleanup_results': cleanup_results
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'cleanup_results': {}
            }

if __name__ == "__main__":
    print("🧪 Testing Admin Workflows...")
    
    # Initialize admin workflows
    admin = AdminWorkflows()
    
    # Test synthetic data generation
    print("Testing synthetic data generation...")
    syn_result = admin.generate_synthetic_data(num_records=50)
    print(f"✅ Synthetic data: {'Success' if syn_result['success'] else 'Failed'}")
    if syn_result['success']:
        print(f"   Generated {syn_result['records_generated']} records")
    
    # Test schema backup
    if syn_result['success']:
        backup_result = admin.backup_current_schema(
            syn_result['data'], 
            "Test backup"
        )
        print(f"✅ Schema backup: {'Success' if backup_result['success'] else 'Failed'}")
        
        # Test schema restore
        if backup_result['success']:
            restore_result = admin.restore_schema_backup(backup_result['backup_id'])
            print(f"✅ Schema restore: {'Success' if restore_result['success'] else 'Failed'}")
    
    # Test model retraining
    if syn_result['success']:
        print("Testing model retraining...")
        retrain_result = admin.retrain_all_models(syn_result['data'], force_retrain=True)
        print(f"✅ Model retrain: {'Success' if retrain_result['success'] else 'Failed'}")
        
        if retrain_result['success']:
            print(f"   Trained {retrain_result['models_trained']} models")
            print(f"   Best model: {retrain_result['best_model']}")
    
    # Test stress testing
    print("Testing stress tests...")
    stress_result = admin.run_comprehensive_stress_test(['normal_load', 'edge_case_values'])
    print(f"✅ Stress test: {stress_result['overall_status']}")
    print(f"   Pass rate: {stress_result['summary'].get('pass_rate', 0):.1%}")
    
    # Test health report
    health_report = admin.get_system_health_report()
    print(f"✅ Health report: {health_report['overall_status']}")
    print(f"   Components checked: {len(health_report['components'])}")
    
    # Test operation history
    history = admin.get_operation_history()
    print(f"✅ Operation history: {len(history)} operations logged")
    
    print("✅ Admin workflows tests completed!")
