"""Configuration module for LoanIQ application."""
import os
from dataclasses import dataclass
from typing import Dict, Any
import json

@dataclass
class DatabaseConfig:
    """Database configuration settings."""
    host: str = "localhost"
    port: int = 5432
    name: str = "loaniq"
    user: str = "postgres"
    password: str = ""
    
    @classmethod
    def from_env(cls):
        return cls(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "5432")),
            name=os.getenv("DB_NAME", "loaniq"),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASSWORD", "")
        )

@dataclass
class MLConfig:
    """Machine learning configuration settings."""
    model_dir: str = "models"
    retrain_threshold: int = 500
    retrain_days: int = 7
    validation_split: float = 0.2
    test_split: float = 0.2
    random_state: int = 42
    
    # Model families to train
    model_families: list = None
    
    def __post_init__(self):
        if self.model_families is None:
            self.model_families = [
                'logistic_regression',
                'random_forest', 
                'gradient_boosting',
                'xgboost',
                'lightgbm',
                'stacked_hybrid'
            ]

@dataclass
class AppConfig:
    """Main application configuration."""
    app_name: str = "LoanIQ"
    version: str = "1.0.0"
    debug: bool = False
    secret_key: str = ""
    
    # Directories
    data_dir: str = "data"
    upload_dir: str = "data/uploads"
    schema_backup_dir: str = "schema_backups"
    
    # ML settings
    ml: MLConfig = None
    db: DatabaseConfig = None
    
    def __post_init__(self):
        if self.ml is None:
            self.ml = MLConfig()
        if self.db is None:
            self.db = DatabaseConfig.from_env()
        
        # Set secret key from environment
        self.secret_key = os.getenv("SECRET_KEY", "default-secret-key-change-in-production")
        self.debug = os.getenv("DEBUG", "false").lower() == "true"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "app_name": self.app_name,
            "version": self.version,
            "debug": self.debug,
            "data_dir": self.data_dir,
            "upload_dir": self.upload_dir,
            "schema_backup_dir": self.schema_backup_dir,
            "ml": {
                "model_dir": self.ml.model_dir,
                "retrain_threshold": self.ml.retrain_threshold,
                "retrain_days": self.ml.retrain_days,
                "validation_split": self.ml.validation_split,
                "test_split": self.ml.test_split,
                "random_state": self.ml.random_state,
                "model_families": self.ml.model_families
            },
            "db": {
                "host": self.db.host,
                "port": self.db.port,
                "name": self.db.name,
                "user": self.db.user
            }
        }

# Global config instance
config = AppConfig()

def get_config() -> AppConfig:
    """Get the global configuration instance."""
    return config

def update_config(**kwargs) -> None:
    """Update configuration settings."""
    global config
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)

if __name__ == "__main__":
    # Test configuration
    print("🧪 Testing Configuration Module...")
    
    cfg = get_config()
    print(f"✅ App Name: {cfg.app_name}")
    print(f"✅ Version: {cfg.version}")
    print(f"✅ Model Families: {len(cfg.ml.model_families)}")
    print(f"✅ Database Host: {cfg.db.host}")
    
    # Test config updates
    update_config(debug=True)
    print(f"✅ Debug mode updated: {cfg.debug}")
    
    # Test serialization
    config_dict = cfg.to_dict()
    print(f"✅ Config serialization: {len(config_dict)} keys")
    
    print("✅ Configuration module tests passed!")
