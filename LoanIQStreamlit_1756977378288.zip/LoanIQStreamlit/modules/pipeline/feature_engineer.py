"""Feature engineering pipeline for LoanIQ."""
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class FeatureEngineer:
    """Advanced feature engineering for credit scoring."""
    
    def __init__(self):
        self.feature_history = {}
        self.computed_features = []
        
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Main feature engineering pipeline."""
        df_features = df.copy()
        
        # Step 1: Basic ratio features
        df_features = self._create_ratio_features(df_features)
        
        # Step 2: Risk scoring features
        df_features = self._create_risk_features(df_features)
        
        # Step 3: Bucketing features
        df_features = self._create_bucket_features(df_features)
        
        # Step 4: Rolling/aggregate features (if client history available)
        df_features = self._create_aggregate_features(df_features)
        
        # Step 5: Interaction features
        df_features = self._create_interaction_features(df_features)
        
        # Track computed features
        self.computed_features = [col for col in df_features.columns if col not in df.columns]
        
        return df_features
    
    def _create_ratio_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create important financial ratio features."""
        df_ratios = df.copy()
        
        # Loan-to-Income Ratio
        if 'loan_amount' in df_ratios.columns and 'monthly_income' in df_ratios.columns:
            annual_income = df_ratios['monthly_income'] * 12
            df_ratios['loan_to_income'] = df_ratios['loan_amount'] / annual_income
            df_ratios['loan_to_income'] = df_ratios['loan_to_income'].fillna(0)
        
        # Debt-to-Income Ratio
        if 'debt_payments' in df_ratios.columns and 'monthly_income' in df_ratios.columns:
            df_ratios['debt_to_income'] = df_ratios['debt_payments'] / df_ratios['monthly_income']
            df_ratios['debt_to_income'] = df_ratios['debt_to_income'].fillna(0)
        
        # Monthly Payment Ratio (estimate)
        if 'loan_amount' in df_ratios.columns and 'term_months' in df_ratios.columns and 'interest_rate' in df_ratios.columns:
            # Simple monthly payment calculation
            monthly_rate = df_ratios['interest_rate'] / 100 / 12
            n_payments = df_ratios['term_months']
            
            # Handle zero interest rate
            payment_no_interest = df_ratios['loan_amount'] / n_payments
            payment_with_interest = df_ratios['loan_amount'] * (
                monthly_rate * (1 + monthly_rate) ** n_payments
            ) / ((1 + monthly_rate) ** n_payments - 1)
            
            df_ratios['estimated_monthly_payment'] = np.where(
                monthly_rate == 0, 
                payment_no_interest, 
                payment_with_interest
            )
            
            # Payment to income ratio
            if 'monthly_income' in df_ratios.columns:
                df_ratios['payment_to_income'] = df_ratios['estimated_monthly_payment'] / df_ratios['monthly_income']
                df_ratios['payment_to_income'] = df_ratios['payment_to_income'].fillna(0)
        
        # Credit utilization proxy
        if 'debt_payments' in df_ratios.columns and 'loan_amount' in df_ratios.columns:
            # Estimate total credit based on debt payments (simplified)
            estimated_credit = df_ratios['debt_payments'] * 20  # Rough estimate
            df_ratios['credit_utilization_proxy'] = df_ratios['loan_amount'] / (estimated_credit + 1)
        
        return df_ratios
    
    def _create_risk_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create risk assessment features."""
        df_risk = df.copy()
        
        # Basic risk score
        risk_components = []
        
        # Employment stability risk
        if 'employment_years' in df_risk.columns:
            employment_risk = np.where(df_risk['employment_years'] < 1, 3,
                                     np.where(df_risk['employment_years'] < 2, 2,
                                            np.where(df_risk['employment_years'] < 5, 1, 0)))
            risk_components.append(employment_risk)
        
        # Credit history risk
        if 'credit_history_years' in df_risk.columns:
            credit_risk = np.where(df_risk['credit_history_years'] < 2, 3,
                                 np.where(df_risk['credit_history_years'] < 5, 2,
                                        np.where(df_risk['credit_history_years'] < 10, 1, 0)))
            risk_components.append(credit_risk)
        
        # Previous defaults risk
        if 'previous_defaults' in df_risk.columns:
            default_risk = np.minimum(df_risk['previous_defaults'] * 2, 5)
            risk_components.append(default_risk)
        
        # Debt-to-income risk
        if 'debt_to_income' in df_risk.columns:
            dti_risk = np.where(df_risk['debt_to_income'] > 0.5, 4,
                              np.where(df_risk['debt_to_income'] > 0.4, 3,
                                     np.where(df_risk['debt_to_income'] > 0.3, 2,
                                            np.where(df_risk['debt_to_income'] > 0.2, 1, 0))))
            risk_components.append(dti_risk)
        
        # Loan-to-income risk
        if 'loan_to_income' in df_risk.columns:
            lti_risk = np.where(df_risk['loan_to_income'] > 5, 4,
                              np.where(df_risk['loan_to_income'] > 3, 3,
                                     np.where(df_risk['loan_to_income'] > 2, 2,
                                            np.where(df_risk['loan_to_income'] > 1, 1, 0))))
            risk_components.append(lti_risk)
        
        # Combine risk components
        if risk_components:
            df_risk['risk_score'] = sum(risk_components)
        else:
            df_risk['risk_score'] = 0
        
        # Normalize risk score to 0-100 scale
        if df_risk['risk_score'].max() > 0:
            df_risk['risk_score_normalized'] = (df_risk['risk_score'] / df_risk['risk_score'].max()) * 100
        else:
            df_risk['risk_score_normalized'] = 0
        
        return df_risk
    
    def _create_bucket_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create categorical bucket features."""
        df_buckets = df.copy()
        
        # Income buckets
        if 'monthly_income' in df_buckets.columns:
            df_buckets['income_bucket'] = pd.cut(
                df_buckets['monthly_income'],
                bins=[0, 3000, 5000, 7500, 10000, float('inf')],
                labels=['low', 'medium_low', 'medium', 'medium_high', 'high']
            )
        
        # Loan amount buckets
        if 'loan_amount' in df_buckets.columns:
            df_buckets['loan_amount_bucket'] = pd.cut(
                df_buckets['loan_amount'],
                bins=[0, 10000, 25000, 50000, float('inf')],
                labels=['small', 'medium', 'large', 'extra_large']
            )
        
        # Interest rate buckets
        if 'interest_rate' in df_buckets.columns:
            df_buckets['interest_rate_bucket'] = pd.cut(
                df_buckets['interest_rate'],
                bins=[0, 6, 10, 15, float('inf')],
                labels=['low', 'medium', 'high', 'very_high']
            )
        
        # Term buckets
        if 'term_months' in df_buckets.columns:
            df_buckets['term_bucket'] = pd.cut(
                df_buckets['term_months'],
                bins=[0, 24, 48, 72, float('inf')],
                labels=['short', 'medium', 'long', 'very_long']
            )
        
        # Employment experience buckets
        if 'employment_years' in df_buckets.columns:
            df_buckets['employment_bucket'] = pd.cut(
                df_buckets['employment_years'],
                bins=[0, 1, 3, 7, float('inf')],
                labels=['new', 'junior', 'experienced', 'senior']
            )
        
        return df_buckets
    
    def _create_aggregate_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create aggregate features by client."""
        df_agg = df.copy()
        
        if 'client_id' not in df_agg.columns:
            return df_agg
        
        # Rolling default rate by client (if multiple loans per client)
        client_stats = df_agg.groupby('client_id').agg({
            'loan_amount': ['count', 'mean', 'sum'],
            'defaulted': ['sum', 'mean'] if 'defaulted' in df_agg.columns else ['count']
        }).round(2)
        
        # Flatten column names
        client_stats.columns = ['_'.join(col).strip() for col in client_stats.columns]
        
        # Rename for clarity
        rename_dict = {
            'loan_amount_count': 'client_loan_count',
            'loan_amount_mean': 'client_avg_loan_amount',
            'loan_amount_sum': 'client_total_loan_amount'
        }
        
        if 'defaulted' in df_agg.columns:
            rename_dict.update({
                'defaulted_sum': 'client_total_defaults',
                'defaulted_mean': 'client_default_rate'
            })
        
        client_stats = client_stats.rename(columns=rename_dict)
        
        # Merge back to main dataframe
        df_agg = df_agg.merge(client_stats, left_on='client_id', right_index=True, how='left')
        
        # Create client risk category
        if 'client_default_rate' in df_agg.columns:
            df_agg['client_risk_category'] = pd.cut(
                df_agg['client_default_rate'],
                bins=[-0.1, 0, 0.2, 0.5, 1.1],
                labels=['no_risk', 'low_risk', 'medium_risk', 'high_risk']
            )
        
        return df_agg
    
    def _create_interaction_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create interaction features between important variables."""
        df_interactions = df.copy()
        
        # Income and employment interaction
        if 'monthly_income' in df_interactions.columns and 'employment_years' in df_interactions.columns:
            df_interactions['income_employment_interaction'] = (
                df_interactions['monthly_income'] * np.log1p(df_interactions['employment_years'])
            )
        
        # Risk and loan amount interaction
        if 'risk_score' in df_interactions.columns and 'loan_amount' in df_interactions.columns:
            df_interactions['risk_loan_interaction'] = (
                df_interactions['risk_score'] * np.log1p(df_interactions['loan_amount'])
            )
        
        # Interest rate and term interaction
        if 'interest_rate' in df_interactions.columns and 'term_months' in df_interactions.columns:
            df_interactions['rate_term_interaction'] = (
                df_interactions['interest_rate'] * np.sqrt(df_interactions['term_months'])
            )
        
        # Debt and income stability interaction
        if all(col in df_interactions.columns for col in ['debt_to_income', 'employment_years']):
            df_interactions['debt_stability_interaction'] = (
                df_interactions['debt_to_income'] / (np.log1p(df_interactions['employment_years']) + 1)
            )
        
        return df_interactions
    
    def get_feature_importance_ranking(self, df: pd.DataFrame) -> Dict[str, float]:
        """Calculate basic feature importance based on correlation with target."""
        if 'defaulted' not in df.columns:
            return {}
        
        # Calculate correlations with target
        numeric_columns = df.select_dtypes(include=[np.number]).columns
        correlations = {}
        
        for col in numeric_columns:
            if col != 'defaulted':
                try:
                    corr = abs(df[col].corr(df['defaulted']))
                    if not np.isnan(corr):
                        correlations[col] = corr
                except:
                    pass
        
        # Sort by importance
        return dict(sorted(correlations.items(), key=lambda x: x[1], reverse=True))
    
    def create_feature_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Create comprehensive feature summary."""
        summary = {
            'total_features': len(df.columns),
            'original_features': len(df.columns) - len(self.computed_features),
            'engineered_features': len(self.computed_features),
            'feature_categories': {},
            'data_quality': {}
        }
        
        # Categorize features
        ratio_features = [col for col in df.columns if any(x in col for x in ['_to_', 'ratio', 'utilization'])]
        risk_features = [col for col in df.columns if 'risk' in col]
        bucket_features = [col for col in df.columns if 'bucket' in col]
        interaction_features = [col for col in df.columns if 'interaction' in col]
        aggregate_features = [col for col in df.columns if 'client_' in col]
        
        summary['feature_categories'] = {
            'ratio_features': len(ratio_features),
            'risk_features': len(risk_features),
            'bucket_features': len(bucket_features),
            'interaction_features': len(interaction_features),
            'aggregate_features': len(aggregate_features)
        }
        
        # Data quality metrics
        summary['data_quality'] = {
            'missing_values': df.isnull().sum().sum(),
            'infinite_values': np.isinf(df.select_dtypes(include=[np.number])).sum().sum(),
            'duplicate_rows': df.duplicated().sum()
        }
        
        return summary

if __name__ == "__main__":
    print("🧪 Testing Feature Engineer...")
    
    # Create sample loan data
    np.random.seed(42)
    sample_data = {
        'client_id': [1, 2, 3, 1, 2, 4, 5, 3, 6, 7],
        'loan_amount': [10000, 25000, 15000, 8000, 30000, 12000, 18000, 20000, 22000, 16000],
        'interest_rate': [7.5, 9.2, 6.8, 8.1, 10.5, 7.9, 8.7, 9.8, 7.2, 8.4],
        'term_months': [36, 60, 24, 48, 72, 36, 48, 60, 24, 36],
        'monthly_income': [4500, 6200, 3800, 4500, 7000, 4200, 5500, 3800, 5800, 4800],
        'debt_payments': [900, 1500, 800, 1200, 1800, 1000, 1300, 1100, 1400, 1100],
        'employment_years': [3.5, 8.0, 1.5, 5.0, 12.0, 2.5, 6.5, 4.0, 7.5, 3.0],
        'credit_history_years': [5.0, 12.0, 2.0, 8.0, 15.0, 4.0, 9.0, 6.0, 11.0, 5.5],
        'previous_defaults': [0, 1, 2, 0, 0, 1, 0, 1, 0, 0],
        'defaulted': [0, 1, 1, 0, 0, 1, 0, 0, 0, 0]
    }
    
    df = pd.DataFrame(sample_data)
    
    # Test feature engineering
    engineer = FeatureEngineer()
    df_features = engineer.engineer_features(df)
    
    original_cols = len(df.columns)
    new_cols = len(df_features.columns)
    features_added = new_cols - original_cols
    
    print(f"✅ Feature engineering: Added {features_added} features ({original_cols} → {new_cols})")
    
    # Test specific feature creation
    ratio_features_found = any('_to_' in col for col in df_features.columns)
    print(f"✅ Ratio features: {'Created' if ratio_features_found else 'Not found'}")
    
    risk_features_found = any('risk' in col for col in df_features.columns)
    print(f"✅ Risk features: {'Created' if risk_features_found else 'Not found'}")
    
    bucket_features_found = any('bucket' in col for col in df_features.columns)
    print(f"✅ Bucket features: {'Created' if bucket_features_found else 'Not found'}")
    
    # Test feature importance ranking
    importance = engineer.get_feature_importance_ranking(df_features)
    print(f"✅ Feature importance: {len(importance)} features ranked")
    
    if importance:
        top_feature = list(importance.keys())[0]
        print(f"   Top feature: {top_feature} (correlation: {importance[top_feature]:.3f})")
    
    # Test feature summary
    summary = engineer.create_feature_summary(df_features)
    print(f"✅ Feature summary: {summary['engineered_features']} engineered features")
    
    print("✅ Feature engineer tests passed!")
