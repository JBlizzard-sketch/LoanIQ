"""Main Streamlit application for LoanIQ."""
import streamlit as st
import sys
import os

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from modules.auth import AuthManager, UserRole
from modules.config import get_config

# Initialize configuration and auth
config = get_config()
auth_manager = AuthManager()

def initialize_session_state():
    """Initialize session state variables."""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    if 'user' not in st.session_state:
        st.session_state.user = None
    if 'session_id' not in st.session_state:
        st.session_state.session_id = None

def login_page():
    """Display login page."""
    st.title("🏦 LoanIQ - Login")
    st.write("Welcome to LoanIQ Credit Scoring System")
    
    # Create tabs for login and register
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        st.subheader("Login to your account")
        
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submit_login = st.form_submit_button("Login")
            
            if submit_login:
                if username and password:
                    session_id = auth_manager.authenticate(username, password)
                    
                    if session_id:
                        user = auth_manager.get_user_by_session(session_id)
                        if user:
                            st.session_state.authenticated = True
                            st.session_state.user = user
                            st.session_state.session_id = session_id
                            st.success(f"Welcome back, {user.username}!")
                            st.rerun()
                        else:
                            st.error("Authentication failed. Please try again.")
                    else:
                        st.error("Invalid username or password.")
                else:
                    st.error("Please enter both username and password.")
    
    with tab2:
        st.subheader("Create new account")
        
        with st.form("register_form"):
            reg_username = st.text_input("Choose Username")
            reg_email = st.text_input("Email Address")
            reg_password = st.text_input("Choose Password", type="password")
            reg_password_confirm = st.text_input("Confirm Password", type="password")
            reg_role = st.selectbox("Account Type", ["Client", "Admin"])
            submit_register = st.form_submit_button("Register")
            
            if submit_register:
                if all([reg_username, reg_email, reg_password, reg_password_confirm]):
                    if reg_password != reg_password_confirm:
                        st.error("Passwords do not match.")
                    elif len(reg_password) < 6:
                        st.error("Password must be at least 6 characters long.")
                    else:
                        user_role = UserRole.ADMIN if reg_role == "Admin" else UserRole.CLIENT
                        user = auth_manager.register_user(
                            reg_username, reg_email, reg_password, user_role
                        )
                        
                        if user:
                            st.success("Account created successfully! Please login.")
                            st.balloons()
                        else:
                            st.error("Registration failed. Username or email may already exist.")
                else:
                    st.error("Please fill in all fields.")

def main_app():
    """Display main application after authentication."""
    user = st.session_state.user
    
    # Sidebar with user info and navigation
    with st.sidebar:
        st.title("🏦 LoanIQ")
        st.write(f"Welcome, **{user.username}**")
        st.write(f"Role: {user.role.value.title()}")
        
        st.divider()
        
        # Logout button
        if st.button("🚪 Logout", use_container_width=True):
            auth_manager.logout(st.session_state.session_id)
            st.session_state.authenticated = False
            st.session_state.user = None
            st.session_state.session_id = None
            st.rerun()
        
        st.divider()
        
        # Navigation info
        st.subheader("📋 Navigation")
        if user.role == UserRole.ADMIN:
            st.write("🛠️ **Admin Sandbox** - Full access to all admin tools")
        st.write("📊 **Client Dashboard** - View predictions and analytics")
        
        st.divider()
        
        # System status
        st.subheader("⚡ System Status")
        st.write("🟢 Authentication: Active")
        st.write("🟢 ML Engine: Ready")
        st.write("🟢 Data Processing: Online")
    
    # Main content area
    st.title("🏦 LoanIQ Credit Scoring System")
    st.write(f"Welcome to LoanIQ, {user.username}! Select a page from the sidebar to get started.")
    
    # Overview cards
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            "Your Access Level",
            user.role.value.title(),
            "Full Access" if user.role == UserRole.ADMIN else "Standard Access"
        )
    
    with col2:
        st.metric(
            "Available Features",
            "All Features" if user.role == UserRole.ADMIN else "Client Features",
            "✅ Ready"
        )
    
    with col3:
        st.metric(
            "Account Status",
            "Active",
            "✅ Verified"
        )
    
    # Feature overview
    st.divider()
    st.subheader("🚀 Available Features")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Client Dashboard")
        st.write("""
        - **Credit Score Predictions** - Get instant credit assessments
        - **Risk Analysis** - Detailed risk factor breakdown
        - **What-If Scenarios** - Explore different loan parameters
        - **Client Lookup** - Search and analyze client data
        - **Data Export** - Download reports and predictions
        """)
        
        if st.button("🎯 Go to Client Dashboard", use_container_width=True):
            st.switch_page("pages/1_📊_Client_Dashboard.py")
    
    with col2:
        if user.role == UserRole.ADMIN:
            st.subheader("🛠️ Admin Sandbox")
            st.write("""
            - **Model Management** - Train, deploy, and version models
            - **Synthetic Data** - Generate realistic test data
            - **Stress Testing** - Comprehensive system testing
            - **Schema Management** - Backup and restore data schemas
            - **System Monitoring** - Health reports and analytics
            """)
            
            if st.button("⚙️ Go to Admin Sandbox", use_container_width=True):
                st.switch_page("pages/2_🛠️_Admin_Sandbox.py")
        else:
            st.subheader("🔒 Admin Access")
            st.write("""
            Admin features are restricted to administrator accounts only.
            
            **Admin capabilities include:**
            - Model training and deployment
            - System configuration
            - Data generation and testing
            - Advanced analytics
            """)
            st.info("Contact your administrator for admin access.")
    
    # Quick stats
    st.divider()
    st.subheader("📈 Quick Statistics")
    
    try:
        # Try to get some basic system stats
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("System Version", config.version)
        
        with col2:
            st.metric("App Name", config.app_name)
        
        with col3:
            st.metric("Debug Mode", "On" if config.debug else "Off")
        
        with col4:
            st.metric("Model Families", len(config.ml.model_families))
    
    except Exception as e:
        st.error(f"Error loading system statistics: {e}")
    
    # Recent activity placeholder
    st.divider()
    st.subheader("🕐 Getting Started")
    
    if user.role == UserRole.ADMIN:
        st.info("""
        **Quick Start for Administrators:**
        1. 🎯 Visit the **Client Dashboard** to test prediction functionality
        2. 🛠️ Use the **Admin Sandbox** to generate synthetic data
        3. ⚙️ Train and deploy ML models for credit scoring
        4. 📊 Monitor system health and performance
        """)
    else:
        st.info("""
        **Quick Start for Clients:**
        1. 📊 Visit the **Client Dashboard** to explore credit scoring features
        2. 🔍 Look up client information and get predictions
        3. 🎮 Try what-if scenarios to see how different parameters affect credit scores
        4. 📥 Export data and reports for your analysis
        """)

def main():
    """Main application entry point."""
    # Page configuration
    st.set_page_config(
        page_title="LoanIQ - Credit Scoring System",
        page_icon="🏦",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    initialize_session_state()
    
    # Check authentication
    if not st.session_state.authenticated:
        # Verify session if session_id exists
        if st.session_state.session_id:
            user = auth_manager.get_user_by_session(st.session_state.session_id)
            if user:
                st.session_state.authenticated = True
                st.session_state.user = user
            else:
                # Session expired
                st.session_state.session_id = None
    
    # Display appropriate page
    if st.session_state.authenticated and st.session_state.user:
        main_app()
    else:
        login_page()

if __name__ == "__main__":
    main()
