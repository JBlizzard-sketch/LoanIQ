"""Admin Sandbox for LoanIQ - Complete administrative interface."""
import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import json

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from modules.auth import AuthManager, UserRole
from modules.admin_tools.admin_workflows import AdminWorkflows
from modules.ml.engine import MLEngine
from modules.schema.backup_manager import SchemaBackupManager
from modules.synth.data_generator import SyntheticDataGenerator

# Page configuration
st.set_page_config(
    page_title="Admin Sandbox - LoanIQ",
    page_icon="🛠️",
    layout="wide"
)

# Authentication and authorization check
if 'authenticated' not in st.session_state or not st.session_state.authenticated:
    st.error("🔒 Please login to access this page.")
    st.stop()

if st.session_state.user.role != UserRole.ADMIN:
    st.error("🚫 Access denied. This page is restricted to administrators only.")
    st.stop()

# Initialize components
@st.cache_resource
def initialize_admin_components():
    return {
        'admin_workflows': AdminWorkflows(),
        'ml_engine': MLEngine(),
        'backup_manager': SchemaBackupManager(),
        'data_generator': SyntheticDataGenerator()
    }

components = initialize_admin_components()

def main():
    """Main admin sandbox function."""
    st.title("🛠️ Admin Sandbox")
    st.write("Complete administrative control panel for LoanIQ system")
    
    # Sidebar navigation
    with st.sidebar:
        st.header("⚙️ Admin Tools")
        
        admin_mode = st.selectbox(
            "Select Admin Function",
            [
                "🎲 Synthetic Data Generator",
                "🤖 Model Management", 
                "🧪 Stress Testing",
                "💾 Schema Management",
                "👤 User Impersonation",
                "📊 System Health",
                "🧹 System Cleanup"
            ]
        )
        
        st.divider()
        
        # Quick system status
        st.subheader("⚡ System Status")
        display_quick_status()
    
    # Route to appropriate admin function
    if admin_mode == "🎲 Synthetic Data Generator":
        synthetic_data_generator()
    elif admin_mode == "🤖 Model Management":
        model_management()
    elif admin_mode == "🧪 Stress Testing":
        stress_testing()
    elif admin_mode == "💾 Schema Management":
        schema_management()
    elif admin_mode == "👤 User Impersonation":
        user_impersonation()
    elif admin_mode == "📊 System Health":
        system_health_monitor()
    elif admin_mode == "🧹 System Cleanup":
        system_cleanup()

def display_quick_status():
    """Display quick system status in sidebar."""
    try:
        # ML Engine status
        model_status = components['ml_engine'].get_model_status()
        if model_status['deployed_model']['is_loaded']:
            st.success("🤖 ML Engine: Active")
            st.write(f"Model: {model_status['deployed_model']['name']}")
        else:
            st.warning("🤖 ML Engine: No model")
        
        # Available models count
        st.write(f"📚 Models: {model_status['total_models']}")
        
        # Storage usage
        storage_info = components['ml_engine'].model_manager.get_storage_usage()
        st.write(f"💽 Storage: {storage_info['total_size_mb']:.1f} MB")
        
    except Exception as e:
        st.error("❌ Status check failed")

def synthetic_data_generator():
    """Synthetic data generation interface."""
    st.header("🎲 Synthetic Data Generator")
    st.write("Generate realistic synthetic loan data for testing and training")
    
    tab1, tab2, tab3 = st.tabs(["Generate Data", "Batch Generation", "Data Analysis"])
    
    with tab1:
        st.subheader("Single Dataset Generation")
        
        col1, col2 = st.columns(2)
        
        with col1:
            num_records = st.number_input(
                "Number of Records",
                min_value=10,
                max_value=10000,
                value=100,
                step=10
            )
            
            with_history = st.checkbox(
                "Generate Client History",
                help="Create multiple loans per client to simulate history"
            )
            
            existing_clients = st.text_input(
                "Existing Client IDs (comma-separated)",
                help="Avoid ID conflicts with existing clients"
            )
        
        with col2:
            st.subheader("Data Distribution Settings")
            
            # Advanced options
            with st.expander("🔧 Advanced Options"):
                custom_seed = st.number_input("Random Seed", value=42)
                risk_bias = st.selectbox(
                    "Risk Distribution Bias",
                    ["Normal", "High Risk", "Low Risk"],
                    help="Bias the generated data toward specific risk profiles"
                )
        
        if st.button("🚀 Generate Synthetic Data", use_container_width=True, type="primary"):
            with st.spinner("Generating synthetic data..."):
                # Parse existing clients
                existing_client_list = None
                if existing_clients.strip():
                    try:
                        existing_client_list = [int(x.strip()) for x in existing_clients.split(",")]
                    except ValueError:
                        st.error("Invalid client ID format. Please use comma-separated numbers.")
                        return
                
                # Generate data
                result = components['admin_workflows'].generate_synthetic_data(
                    num_records=num_records,
                    existing_clients=existing_client_list,
                    with_history=with_history
                )
                
                if result['success']:
                    st.success(f"✅ Generated {result['records_generated']} records successfully!")
                    
                    # Display statistics
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Records Generated", result['records_generated'])
                    
                    with col2:
                        st.metric("Unique Clients", result['unique_clients'])
                    
                    with col3:
                        st.metric("Generation Time", f"{result['generation_time_seconds']:.2f}s")
                    
                    with col4:
                        validation_status = "✅ Valid" if result['validation_passed'] else "❌ Issues"
                        st.metric("Data Validation", validation_status)
                    
                    # Data preview
                    st.subheader("📋 Generated Data Preview")
                    st.dataframe(result['data'].head(20), use_container_width=True)
                    
                    # Statistics
                    if result['statistics']:
                        with st.expander("📊 Data Statistics"):
                            stats = result['statistics']
                            
                            col1, col2 = st.columns(2)
                            
                            with col1:
                                st.write("**Loan Amount Statistics:**")
                                st.write(f"- Mean: ${stats['loan_amount_stats']['mean']:,.2f}")
                                st.write(f"- Median: ${stats['loan_amount_stats']['median']:,.2f}")
                                st.write(f"- Range: ${stats['loan_amount_stats']['min']:,.0f} - ${stats['loan_amount_stats']['max']:,.0f}")
                            
                            with col2:
                                st.write("**Risk Profile:**")
                                st.write(f"- Default Rate: {stats['default_rate']:.1%}")
                                st.write(f"- Avg Loans/Client: {stats['avg_loans_per_client']:.1f}")
                    
                    # Download option
                    st.download_button(
                        "📥 Download Generated Data",
                        result['data'].to_csv(index=False),
                        f"synthetic_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        "text/csv",
                        use_container_width=True
                    )
                    
                    # Store for other operations
                    st.session_state.generated_data = result['data']
                    
                else:
                    st.error(f"❌ Generation failed: {result['error']}")
    
    with tab2:
        st.subheader("Batch Generation")
        st.write("Generate multiple datasets for comprehensive testing")
        
        col1, col2 = st.columns(2)
        
        with col1:
            batch_count = st.number_input("Number of Batches", min_value=1, max_value=10, value=3)
            records_per_batch = st.number_input("Records per Batch", min_value=50, max_value=1000, value=200)
        
        with col2:
            batch_prefix = st.text_input("Batch Name Prefix", value="batch")
            auto_train = st.checkbox("Auto-train models after generation")
        
        if st.button("🔄 Generate Batch Datasets", use_container_width=True):
            with st.spinner(f"Generating {batch_count} batches..."):
                batch_results = []
                
                progress_bar = st.progress(0)
                
                for i in range(batch_count):
                    result = components['admin_workflows'].generate_synthetic_data(
                        num_records=records_per_batch,
                        with_history=True
                    )
                    
                    if result['success']:
                        batch_name = f"{batch_prefix}_{i+1}"
                        batch_results.append({
                            'name': batch_name,
                            'records': result['records_generated'],
                            'clients': result['unique_clients'],
                            'data': result['data']
                        })
                    
                    progress_bar.progress((i + 1) / batch_count)
                
                st.success(f"✅ Generated {len(batch_results)} batches successfully!")
                
                # Display batch summary
                summary_df = pd.DataFrame([
                    {'Batch': b['name'], 'Records': b['records'], 'Clients': b['clients']}
                    for b in batch_results
                ])
                
                st.dataframe(summary_df, use_container_width=True)
                
                # Auto-train option
                if auto_train and batch_results:
                    st.write("🤖 Auto-training models...")
                    combined_data = pd.concat([b['data'] for b in batch_results], ignore_index=True)
                    
                    train_result = components['admin_workflows'].retrain_all_models(
                        combined_data, force_retrain=True
                    )
                    
                    if train_result['success']:
                        st.success(f"✅ Models trained successfully! Best model: {train_result['best_model']}")
                    else:
                        st.error(f"❌ Training failed: {train_result['error']}")
    
    with tab3:
        st.subheader("Data Quality Analysis")
        
        if 'generated_data' in st.session_state:
            data = st.session_state.generated_data
            
            # Data quality metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Total Records", len(data))
                st.metric("Missing Values", data.isnull().sum().sum())
            
            with col2:
                st.metric("Duplicate Records", data.duplicated().sum())
                st.metric("Unique Clients", data['client_id'].nunique())
            
            with col3:
                default_rate = data['defaulted'].mean() if 'defaulted' in data.columns else 0
                st.metric("Default Rate", f"{default_rate:.1%}")
            
            # Distribution visualizations
            if len(data) > 0:
                col1, col2 = st.columns(2)
                
                with col1:
                    # Loan amount distribution
                    fig = px.histogram(
                        data,
                        x='loan_amount',
                        title='Loan Amount Distribution',
                        nbins=20
                    )
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    # Default rate by income bracket
                    if 'defaulted' in data.columns:
                        data['income_bracket'] = pd.cut(
                            data['monthly_income'],
                            bins=5,
                            labels=['Very Low', 'Low', 'Medium', 'High', 'Very High']
                        )
                        
                        default_by_income = data.groupby('income_bracket')['defaulted'].mean().reset_index()
                        
                        fig = px.bar(
                            default_by_income,
                            x='income_bracket',
                            y='defaulted',
                            title='Default Rate by Income Bracket'
                        )
                        st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("💡 Generate data first to see quality analysis")

def model_management():
    """Model management and training interface."""
    st.header("🤖 Model Management")
    st.write("Train, deploy, and manage ML model versions")
    
    tab1, tab2, tab3 = st.tabs(["Model Training", "Version Management", "Deployment"])
    
    with tab1:
        st.subheader("Model Training & Retraining")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Training Data Source:**")
            data_source = st.radio(
                "Select data source",
                ["Use Generated Data", "Upload Training Data", "Use Sample Data"]
            )
            
            force_retrain = st.checkbox(
                "Force Retrain",
                help="Retrain even if thresholds not met"
            )
        
        with col2:
            st.write("**Training Configuration:**")
            
            # Get current ML config
            try:
                model_status = components['ml_engine'].get_model_status()
                st.write(f"Current threshold: {components['ml_engine'].retrain_threshold} records")
                st.write(f"Time threshold: {components['ml_engine'].retrain_days} days")
                
                if model_status['last_retrain_date']:
                    st.write(f"Last retrain: {model_status['last_retrain_date']}")
                else:
                    st.write("Last retrain: Never")
                    
            except Exception as e:
                st.error(f"Error loading ML config: {e}")
        
        # Training data selection
        training_data = None
        
        if data_source == "Use Generated Data":
            if 'generated_data' in st.session_state:
                training_data = st.session_state.generated_data
                st.success(f"✅ Using generated data: {len(training_data)} records")
            else:
                st.warning("⚠️ No generated data available. Generate data first.")
        
        elif data_source == "Upload Training Data":
            uploaded_file = st.file_uploader("Choose CSV file", type=['csv'])
            if uploaded_file is not None:
                try:
                    training_data = pd.read_csv(uploaded_file)
                    st.success(f"✅ Loaded {len(training_data)} records from file")
                except Exception as e:
                    st.error(f"❌ Error loading file: {e}")
        
        elif data_source == "Use Sample Data":
            if st.button("Generate Sample Training Data"):
                sample_data = components['data_generator'].generate_loan_data(500)
                training_data = sample_data
                st.success(f"✅ Generated sample data: {len(training_data)} records")
        
        # Training execution
        if training_data is not None and len(training_data) > 0:
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Training Data Preview:**")
                st.dataframe(training_data.head(), use_container_width=True)
            
            with col2:
                st.write("**Data Statistics:**")
                st.write(f"Records: {len(training_data)}")
                st.write(f"Features: {len(training_data.columns)}")
                if 'defaulted' in training_data.columns:
                    default_rate = training_data['defaulted'].mean()
                    st.write(f"Default rate: {default_rate:.1%}")
            
            if st.button("🚀 Start Model Training", use_container_width=True, type="primary"):
                with st.spinner("Training models... This may take several minutes."):
                    result = components['admin_workflows'].retrain_all_models(
                        training_data, force_retrain=force_retrain
                    )
                    
                    if result['success']:
                        st.success("🎉 Model training completed successfully!")
                        
                        # Training results
                        col1, col2, col3, col4 = st.columns(4)
                        
                        with col1:
                            st.metric("Models Trained", result['models_trained'])
                        
                        with col2:
                            st.metric("Training Time", f"{result['training_time_seconds']:.1f}s")
                        
                        with col3:
                            st.metric("Training Records", result['data_records'])
                        
                        with col4:
                            st.metric("Best Model", result['best_model'])
                        
                        # Model performance details
                        if 'training_results' in result:
                            with st.expander("📊 Detailed Training Results"):
                                training_results = result['training_results']
                                
                                if 'models_performance' in training_results:
                                    perf_data = []
                                    for model_name, metrics in training_results['models_performance'].items():
                                        perf_data.append({
                                            'Model': model_name,
                                            'Accuracy': f"{metrics.get('accuracy', 0):.3f}",
                                            'F1 Score': f"{metrics.get('f1_score', 0):.3f}",
                                            'ROC AUC': f"{metrics.get('roc_auc', 0):.3f}"
                                        })
                                    
                                    perf_df = pd.DataFrame(perf_data)
                                    st.dataframe(perf_df, use_container_width=True)
                    
                    else:
                        st.error(f"❌ Training failed: {result['error']}")
    
    with tab2:
        st.subheader("Model Version Management")
        
        # List all models and versions
        try:
            version_result = components['admin_workflows'].manage_model_versions('list_all')
            
            if version_result['success']:
                models = version_result['models']
                versions_info = version_result['versions_info']
                
                if models:
                    for model_name in models:
                        with st.expander(f"🤖 {model_name}", expanded=False):
                            versions = versions_info.get(model_name, [])
                            
                            if versions:
                                # Create versions table
                                version_data = []
                                for version in versions:
                                    version_data.append({
                                        'Version': version['version'],
                                        'Created': version['created_at'][:19].replace('T', ' '),
                                        'Training Samples': version['training_samples'],
                                        'Accuracy': f"{version['metrics'].get('accuracy', 0):.3f}",
                                        'F1 Score': f"{version['metrics'].get('f1_score', 0):.3f}",
                                        'Latest': '✅' if version['is_latest'] else ''
                                    })
                                
                                versions_df = pd.DataFrame(version_data)
                                st.dataframe(versions_df, use_container_width=True)
                                
                                # Version actions
                                col1, col2, col3 = st.columns(3)
                                
                                with col1:
                                    selected_version = st.selectbox(
                                        f"Select version for {model_name}",
                                        [v['version'] for v in versions],
                                        key=f"version_{model_name}"
                                    )
                                
                                with col2:
                                    if st.button(f"Deploy {model_name}", key=f"deploy_{model_name}"):
                                        deploy_result = components['admin_workflows'].manage_model_versions(
                                            'deploy', model_name=model_name, version=selected_version
                                        )
                                        
                                        if deploy_result['success']:
                                            st.success(f"✅ Deployed {model_name} {selected_version}")
                                            st.rerun()
                                        else:
                                            st.error(f"❌ Deployment failed: {deploy_result['error']}")
                                
                                with col3:
                                    if st.button(f"Delete Version", key=f"delete_{model_name}_{selected_version}"):
                                        delete_result = components['admin_workflows'].manage_model_versions(
                                            'delete', model_name=model_name, version=selected_version
                                        )
                                        
                                        if delete_result['success']:
                                            st.success(f"✅ Deleted {model_name} {selected_version}")
                                            st.rerun()
                                        else:
                                            st.error(f"❌ Deletion failed: {delete_result['error']}")
                            else:
                                st.write("No versions available")
                else:
                    st.info("No models found. Train some models first.")
            
            else:
                st.error(f"❌ Failed to load model versions: {version_result['error']}")
                
        except Exception as e:
            st.error(f"❌ Error in version management: {e}")
    
    with tab3:
        st.subheader("Model Deployment Status")
        
        try:
            model_status = components['ml_engine'].get_model_status()
            
            # Current deployment
            deployed = model_status['deployed_model']
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if deployed['is_loaded']:
                    st.success("🟢 Model Status: Active")
                else:
                    st.error("🔴 Model Status: No Model Deployed")
            
            with col2:
                st.metric("Deployed Model", deployed['name'] or "None")
            
            with col3:
                st.metric("Version", deployed['version'] or "N/A")
            
            # Deployment history and stats
            if deployed['is_loaded']:
                st.subheader("📊 Deployment Information")
                
                # Model capabilities
                with st.expander("🔍 Model Capabilities"):
                    st.write(f"**Model Family:** {deployed['name']}")
                    st.write(f"**Version:** {deployed['version']}")
                    st.write("**Supported Operations:**")
                    st.write("- Credit risk prediction")
                    st.write("- Probability scoring")
                    st.write("- Batch processing")
                    st.write("- Real-time inference")
                
                # Test deployment
                st.subheader("🧪 Test Deployment")
                
                if st.button("🎯 Run Quick Test", use_container_width=True):
                    # Generate test data
                    test_data = components['data_generator'].generate_loan_data(5)
                    
                    with st.spinner("Testing deployed model..."):
                        # Make prediction
                        result = components['ml_engine'].predict(test_data.drop(columns=['defaulted'] if 'defaulted' in test_data.columns else []))
                        
                        if result['error'] is None:
                            st.success("✅ Model deployment test successful!")
                            
                            # Show test results
                            test_results = test_data.copy()
                            test_results['prediction'] = result['predictions']
                            if result['probabilities']:
                                test_results['probability'] = result['probabilities']
                            
                            st.dataframe(test_results, use_container_width=True)
                        else:
                            st.error(f"❌ Deployment test failed: {result['error']}")
            
        except Exception as e:
            st.error(f"❌ Error checking deployment status: {e}")

def stress_testing():
    """Comprehensive stress testing interface."""
    st.header("🧪 Stress Testing")
    st.write("Run comprehensive system stress tests")
    
    tab1, tab2 = st.tabs(["Run Tests", "Test History"])
    
    with tab1:
        st.subheader("Configure Stress Tests")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Test Scenarios:**")
            
            # Test scenario selection
            scenarios = [
                "normal_load",
                "high_default_rate", 
                "edge_case_values",
                "missing_data",
                "performance_load"
            ]
            
            selected_scenarios = []
            for scenario in scenarios:
                if st.checkbox(scenario.replace('_', ' ').title(), value=True):
                    selected_scenarios.append(scenario)
        
        with col2:
            st.write("**Test Configuration:**")
            
            test_name = st.text_input("Test Name", value=f"stress_test_{datetime.now().strftime('%Y%m%d_%H%M')}")
            
            # Test parameters
            with st.expander("🔧 Advanced Test Parameters"):
                performance_threshold = st.number_input(
                    "Performance Threshold (seconds)",
                    min_value=1.0,
                    max_value=60.0,
                    value=10.0,
                    help="Maximum acceptable time for performance tests"
                )
                
                load_test_size = st.number_input(
                    "Load Test Size (records)",
                    min_value=100,
                    max_value=10000,
                    value=500,
                    help="Number of records for load testing"
                )
        
        if selected_scenarios and st.button("🚀 Run Stress Tests", use_container_width=True, type="primary"):
            with st.spinner("Running comprehensive stress tests..."):
                # Run stress tests
                stress_result = components['admin_workflows'].run_comprehensive_stress_test(selected_scenarios)
                
                # Display results
                st.subheader("🧪 Stress Test Results")
                
                # Overall status
                if stress_result['overall_status'] == 'PASS':
                    st.success("🎉 All stress tests PASSED!")
                elif stress_result['overall_status'] == 'FAIL':
                    st.error("❌ Some stress tests FAILED!")
                else:
                    st.error("💥 Stress test execution ERROR!")
                
                # Summary metrics
                if 'summary' in stress_result:
                    summary = stress_result['summary']
                    
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric("Total Tests", summary['total_tests'])
                    
                    with col2:
                        st.metric("Passed Tests", summary['passed_tests'])
                    
                    with col3:
                        st.metric("Failed Tests", summary['failed_tests'])
                    
                    with col4:
                        st.metric("Pass Rate", f"{summary['pass_rate']:.1%}")
                
                # Individual test results
                if 'test_scenarios' in stress_result:
                    st.subheader("📋 Individual Test Results")
                    
                    for scenario, result in stress_result['test_scenarios'].items():
                        with st.expander(f"{'✅' if result.get('passed') else '❌'} {scenario.replace('_', ' ').title()}"):
                            if result.get('passed'):
                                st.success("✅ Test PASSED")
                            else:
                                st.error("❌ Test FAILED")
                                if 'error' in result:
                                    st.error(f"Error: {result['error']}")
                            
                            # Test metrics
                            if 'metrics' in result:
                                st.write("**Test Metrics:**")
                                for key, value in result['metrics'].items():
                                    st.write(f"- {key.replace('_', ' ').title()}: {value}")
                            
                            # Test details
                            if 'details' in result and result['details']:
                                with st.expander("🔍 Detailed Results"):
                                    st.json(result['details'])
                
                # Recommendations
                if 'recommendations' in stress_result and stress_result['recommendations']:
                    st.subheader("💡 Recommendations")
                    for rec in stress_result['recommendations']:
                        st.warning(f"⚠️ {rec}")
                
                # Store results
                st.session_state.last_stress_test = {
                    'name': test_name,
                    'timestamp': datetime.now().isoformat(),
                    'results': stress_result
                }
    
    with tab2:
        st.subheader("Stress Test History")
        
        # Show last test if available
        if 'last_stress_test' in st.session_state:
            last_test = st.session_state.last_stress_test
            
            st.write(f"**Last Test:** {last_test['name']}")
            st.write(f"**Run Time:** {last_test['timestamp']}")
            st.write(f"**Status:** {last_test['results']['overall_status']}")
            
            # Quick summary
            if 'summary' in last_test['results']:
                summary = last_test['results']['summary']
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Pass Rate", f"{summary['pass_rate']:.1%}")
                
                with col2:
                    st.metric("Duration", f"{summary['test_duration_seconds']:.1f}s")
        else:
            st.info("💡 No stress test history available. Run a stress test first.")
        
        # System stress test recommendations
        st.subheader("📋 Recommended Test Schedule")
        
        recommendations = [
            "🔄 **Daily**: Run normal_load and performance_load tests",
            "📅 **Weekly**: Full stress test suite with all scenarios", 
            "🚀 **Before Deployment**: Complete stress testing with edge cases",
            "⚠️ **After Changes**: Targeted tests for affected components"
        ]
        
        for rec in recommendations:
            st.write(rec)

def schema_management():
    """Schema backup and management interface."""
    st.header("💾 Schema Management")
    st.write("Backup, restore, and manage data schemas")
    
    tab1, tab2, tab3 = st.tabs(["Create Backup", "Restore Backup", "Backup History"])
    
    with tab1:
        st.subheader("Create Schema Backup")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Backup Configuration:**")
            
            backup_description = st.text_area(
                "Backup Description",
                value=f"Manual backup created on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                height=100
            )
            
            backup_name = st.text_input(
                "Backup Name",
                value=f"manual_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            )
        
        with col2:
            st.write("**Data Source:**")
            
            data_source = st.radio(
                "Select data to backup",
                ["Use Generated Data", "Upload Data File", "Create Sample Data"]
            )
        
        # Data selection
        backup_data = None
        
        if data_source == "Use Generated Data":
            if 'generated_data' in st.session_state:
                backup_data = st.session_state.generated_data
                st.success(f"✅ Using generated data: {len(backup_data)} records")
            else:
                st.warning("⚠️ No generated data available.")
        
        elif data_source == "Upload Data File":
            uploaded_file = st.file_uploader("Choose CSV file for backup", type=['csv'])
            if uploaded_file is not None:
                try:
                    backup_data = pd.read_csv(uploaded_file)
                    st.success(f"✅ Loaded {len(backup_data)} records from file")
                except Exception as e:
                    st.error(f"❌ Error loading file: {e}")
        
        elif data_source == "Create Sample Data":
            sample_size = st.number_input("Sample Size", min_value=50, max_value=1000, value=100)
            if st.button("Generate Sample Data for Backup"):
                backup_data = components['data_generator'].generate_loan_data(sample_size)
                st.success(f"✅ Generated {len(backup_data)} records for backup")
        
        # Create backup
        if backup_data is not None and st.button("💾 Create Backup", use_container_width=True, type="primary"):
            with st.spinner("Creating schema backup..."):
                result = components['admin_workflows'].backup_current_schema(
                    backup_data, backup_description
                )
                
                if result['success']:
                    st.success(f"✅ Backup created successfully!")
                    st.success(f"**Backup ID:** {result['backup_id']}")
                    st.write(f"**Records backed up:** {result['backup_size']}")
                    
                    # Store backup ID for easy access
                    st.session_state.last_backup_id = result['backup_id']
                else:
                    st.error(f"❌ Backup failed: {result['error']}")
    
    with tab2:
        st.subheader("Restore Schema Backup")
        
        # List available backups
        try:
            backups = components['backup_manager'].list_backups()
            
            if backups:
                # Backup selection
                backup_options = [
                    f"{backup['backup_id']} ({backup['created_at'][:19]}) - {backup['row_count']} records"
                    for backup in backups
                ]
                
                selected_backup_idx = st.selectbox(
                    "Select backup to restore",
                    range(len(backup_options)),
                    format_func=lambda x: backup_options[x]
                )
                
                selected_backup = backups[selected_backup_idx]
                
                # Backup details
                with st.expander("📋 Backup Details"):
                    st.write(f"**Backup ID:** {selected_backup['backup_id']}")
                    st.write(f"**Created:** {selected_backup['created_at']}")
                    st.write(f"**Description:** {selected_backup.get('description', 'No description')}")
                    st.write(f"**Records:** {selected_backup['row_count']}")
                    st.write(f"**Columns:** {selected_backup['column_count']}")
                    st.write(f"**File Size:** {selected_backup.get('file_size_bytes', 0) / 1024:.1f} KB")
                
                # Restore options
                col1, col2 = st.columns(2)
                
                with col1:
                    confirm_restore = st.checkbox("⚠️ I confirm this restore operation")
                
                with col2:
                    preview_only = st.checkbox("Preview only (don't restore)")
                
                if st.button("🔄 Restore Backup", use_container_width=True, disabled=not confirm_restore):
                    with st.spinner("Restoring backup..."):
                        result = components['admin_workflows'].restore_schema_backup(
                            selected_backup['backup_id']
                        )
                        
                        if result['success']:
                            st.success("✅ Backup restored successfully!")
                            st.write(f"**Records restored:** {result['records_restored']}")
                            
                            if not preview_only:
                                # Store restored data
                                st.session_state.restored_data = result['data']
                                st.success("✅ Data is now available for use")
                            
                            # Preview restored data
                            st.subheader("📋 Restored Data Preview")
                            st.dataframe(result['data'].head(10), use_container_width=True)
                        
                        else:
                            st.error(f"❌ Restore failed: {result['error']}")
            else:
                st.info("No backups available. Create a backup first.")
                
        except Exception as e:
            st.error(f"❌ Error loading backups: {e}")
    
    with tab3:
        st.subheader("Backup History & Management")
        
        try:
            # Load all backups
            backups = components['backup_manager'].list_backups()
            
            if backups:
                # Backup statistics
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Backups", len(backups))
                
                with col2:
                    total_records = sum(b['row_count'] for b in backups)
                    st.metric("Total Records", f"{total_records:,}")
                
                with col3:
                    # Storage usage
                    storage_info = components['backup_manager'].get_storage_usage()
                    st.metric("Storage Used", f"{storage_info['total_size_mb']:.1f} MB")
                
                # Backup list
                st.subheader("📋 All Backups")
                
                backup_data = []
                for backup in backups:
                    backup_data.append({
                        'ID': backup['backup_id'],
                        'Created': backup['created_at'][:19].replace('T', ' '),
                        'Records': f"{backup['row_count']:,}",
                        'Columns': backup['column_count'],
                        'Size (KB)': f"{backup.get('file_size_bytes', 0) / 1024:.1f}",
                        'Description': backup.get('description', 'No description')[:50] + '...' if backup.get('description', '') and len(backup.get('description', '')) > 50 else backup.get('description', 'No description')
                    })
                
                backups_df = pd.DataFrame(backup_data)
                st.dataframe(backups_df, use_container_width=True)
                
                # Backup management actions
                st.subheader("🗂️ Backup Management")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    if st.button("🧹 Cleanup Old Backups", use_container_width=True):
                        deleted_count = components['backup_manager'].cleanup_old_backups(keep_count=5)
                        if deleted_count > 0:
                            st.success(f"✅ Cleaned up {deleted_count} old backups")
                            st.rerun()
                        else:
                            st.info("No backups to clean up")
                
                with col2:
                    # Export backup
                    selected_for_export = st.selectbox(
                        "Select backup to export",
                        [b['backup_id'] for b in backups],
                        key="export_backup"
                    )
                    
                    if st.button("📦 Export Backup", use_container_width=True):
                        st.info("Export functionality would create a ZIP file download")
            else:
                st.info("No backup history available")
                
        except Exception as e:
            st.error(f"❌ Error loading backup history: {e}")

def user_impersonation():
    """User impersonation interface for admin testing."""
    st.header("👤 User Impersonation")
    st.write("Impersonate users to test different access levels and workflows")
    
    st.warning("⚠️ **Security Notice**: User impersonation should only be used for testing and support purposes.")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Available Users")
        
        try:
            # Get auth manager instance
            auth_manager = AuthManager()
            all_users = auth_manager.get_all_users()
            
            if all_users:
                # Create user list
                user_data = []
                for user in all_users:
                    user_data.append({
                        'ID': user.id,
                        'Username': user.username,
                        'Email': user.email,
                        'Role': user.role.value.title(),
                        'Active': '✅' if user.is_active else '❌',
                        'Last Login': user.last_login.strftime('%Y-%m-%d %H:%M') if user.last_login else 'Never'
                    })
                
                users_df = pd.DataFrame(user_data)
                st.dataframe(users_df, use_container_width=True)
                
                # User selection for impersonation
                user_options = [(user.id, f"{user.username} ({user.role.value})") for user in all_users if user.is_active]
                
                if user_options:
                    selected_user_id = st.selectbox(
                        "Select user to impersonate",
                        [uid for uid, _ in user_options],
                        format_func=lambda uid: next(uname for ui, uname in user_options if ui == uid)
                    )
                    
                    selected_user = next(user for user in all_users if user.id == selected_user_id)
                    
                    # Show selected user details
                    st.write("**Selected User Details:**")
                    st.write(f"- Username: {selected_user.username}")
                    st.write(f"- Role: {selected_user.role.value.title()}")
                    st.write(f"- Email: {selected_user.email}")
                else:
                    st.warning("No active users available for impersonation")
            else:
                st.info("No users found in the system")
                
        except Exception as e:
            st.error(f"❌ Error loading users: {e}")
    
    with col2:
        st.subheader("Impersonation Actions")
        
        # Impersonation controls
        st.write("**What you can test:**")
        test_scenarios = [
            "🔍 Client dashboard access and functionality",
            "🎯 Prediction workflows and permissions",
            "📊 Data visualization and export features", 
            "⚠️ Error handling for unauthorized actions",
            "🔐 Role-based access control validation"
        ]
        
        for scenario in test_scenarios:
            st.write(scenario)
        
        st.divider()
        
        # Impersonation warning and controls
        st.warning("🚨 **Important**: Impersonation will temporarily change your session. You can return to admin mode at any time.")
        
        if 'all_users' in locals() and user_options:
            confirm_impersonation = st.checkbox("I understand the implications of user impersonation")
            
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("🎭 Start Impersonation", disabled=not confirm_impersonation, use_container_width=True):
                    # Store original admin session
                    st.session_state.original_admin_user = st.session_state.user
                    st.session_state.original_admin_session = st.session_state.session_id
                    
                    # Switch to selected user
                    st.session_state.user = selected_user
                    st.session_state.impersonating = True
                    
                    st.success(f"✅ Now impersonating {selected_user.username}")
                    st.info("🔄 Refresh the page or navigate to test different features")
            
            with col2:
                # Return to admin mode
                if 'impersonating' in st.session_state and st.session_state.impersonating:
                    if st.button("🔙 Return to Admin", use_container_width=True, type="primary"):
                        # Restore admin session
                        st.session_state.user = st.session_state.original_admin_user
                        st.session_state.session_id = st.session_state.original_admin_session
                        st.session_state.impersonating = False
                        
                        # Clean up impersonation data
                        if 'original_admin_user' in st.session_state:
                            del st.session_state.original_admin_user
                        if 'original_admin_session' in st.session_state:
                            del st.session_state.original_admin_session
                        
                        st.success("✅ Returned to admin mode")
                        st.rerun()
        
        # Current impersonation status
        if 'impersonating' in st.session_state and st.session_state.impersonating:
            st.success(f"🎭 Currently impersonating: **{st.session_state.user.username}**")
            st.write(f"Role: {st.session_state.user.role.value.title()}")
        else:
            st.info("👤 Currently in admin mode")

def system_health_monitor():
    """System health monitoring and reporting."""
    st.header("📊 System Health Monitor")
    st.write("Monitor system performance, health metrics, and operational status")
    
    tab1, tab2, tab3 = st.tabs(["Health Overview", "Performance Metrics", "Operational Logs"])
    
    with tab1:
        st.subheader("🏥 System Health Overview")
        
        # Generate health report
        with st.spinner("Generating health report..."):
            health_report = components['admin_workflows'].get_system_health_report()
        
        # Overall status
        if health_report['overall_status'] == 'HEALTHY':
            st.success("🟢 System Status: HEALTHY")
        elif health_report['overall_status'] == 'WARNING':
            st.warning("🟡 System Status: WARNING")
        else:
            st.error("🔴 System Status: CRITICAL")
        
        # Component status
        st.subheader("🧩 Component Status")
        
        if 'components' in health_report:
            components_info = health_report['components']
            
            # ML Engine status
            if 'ml_engine' in components_info:
                ml_info = components_info['ml_engine']
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    status_color = "🟢" if ml_info['status'] == 'ACTIVE' else "🔴"
                    st.metric("ML Engine", f"{status_color} {ml_info['status']}")
                
                with col2:
                    deployed = ml_info['deployed_model']
                    model_name = deployed['name'] if deployed['name'] else "None"
                    st.metric("Deployed Model", model_name)
                
                with col3:
                    st.metric("Available Models", ml_info['available_models'])
            
            # Storage status
            if 'storage' in components_info:
                storage_info = components_info['storage']
                
                st.subheader("💽 Storage Status")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Model Storage", f"{storage_info['models']['total_size_mb']:.1f} MB")
                
                with col2:
                    st.metric("Backup Storage", f"{storage_info['backups']['total_size_mb']:.1f} MB")
                
                with col3:
                    st.metric("Total Storage", f"{storage_info['total_usage_mb']:.1f} MB")
            
            # Recent operations
            if 'operations' in components_info:
                ops_info = components_info['operations']
                
                st.subheader("⚡ Recent Operations")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Recent Operations", ops_info['recent_count'])
                
                with col2:
                    last_op = ops_info['last_operation']
                    last_op_text = f"{last_op['operation_type']}" if last_op else "None"
                    st.metric("Last Operation", last_op_text)
        
        # Health recommendations
        if 'recommendations' in health_report and health_report['recommendations']:
            st.subheader("💡 Health Recommendations")
            
            for recommendation in health_report['recommendations']:
                st.warning(f"⚠️ {recommendation}")
        else:
            st.success("✅ No health issues detected")
        
        # System metrics summary
        st.subheader("📈 System Metrics Summary")
        
        # Create sample metrics (in real system, these would be actual metrics)
        metrics_data = {
            'Metric': [
                'Average Response Time',
                'Memory Usage',
                'CPU Usage', 
                'Prediction Accuracy',
                'Daily Predictions',
                'System Uptime'
            ],
            'Current Value': [
                '245 ms',
                '67%',
                '23%',
                '87.3%',
                '1,247',
                '99.8%'
            ],
            'Status': [
                '🟢 Good',
                '🟡 Moderate',
                '🟢 Good',
                '🟢 Good',
                '🟢 Normal',
                '🟢 Excellent'
            ]
        }
        
        metrics_df = pd.DataFrame(metrics_data)
        st.dataframe(metrics_df, use_container_width=True, hide_index=True)
    
    with tab2:
        st.subheader("📊 Performance Metrics")
        
        # Generate sample performance data
        dates = pd.date_range(start=datetime.now() - timedelta(days=7), end=datetime.now(), freq='H')
        np.random.seed(42)
        
        perf_data = pd.DataFrame({
            'timestamp': dates,
            'response_time_ms': np.random.normal(250, 50, len(dates)),
            'memory_usage_pct': np.random.normal(65, 10, len(dates)),
            'predictions_per_hour': np.random.poisson(50, len(dates)),
            'error_rate_pct': np.random.exponential(0.5, len(dates))
        })
        
        # Response time chart
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.line(
                perf_data,
                x='timestamp',
                y='response_time_ms',
                title='Response Time (7 days)'
            )
            fig.add_hline(y=500, line_dash="dash", line_color="red", annotation_text="SLA Threshold")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            fig = px.line(
                perf_data,
                x='timestamp',
                y='memory_usage_pct',
                title='Memory Usage (7 days)'
            )
            fig.add_hline(y=80, line_dash="dash", line_color="orange", annotation_text="Warning Level")
            st.plotly_chart(fig, use_container_width=True)
        
        # Predictions and errors
        col1, col2 = st.columns(2)
        
        with col1:
            fig = px.line(
                perf_data,
                x='timestamp',
                y='predictions_per_hour',
                title='Predictions per Hour'
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            fig = px.line(
                perf_data,
                x='timestamp',
                y='error_rate_pct',
                title='Error Rate (%)'
            )
            fig.add_hline(y=5, line_dash="dash", line_color="red", annotation_text="Alert Threshold")
            st.plotly_chart(fig, use_container_width=True)
        
        # Performance summary
        st.subheader("📋 Performance Summary (Last 7 Days)")
        
        summary_metrics = {
            'Average Response Time': f"{perf_data['response_time_ms'].mean():.1f} ms",
            'Max Response Time': f"{perf_data['response_time_ms'].max():.1f} ms",
            'Average Memory Usage': f"{perf_data['memory_usage_pct'].mean():.1f}%",
            'Total Predictions': f"{perf_data['predictions_per_hour'].sum():,}",
            'Average Error Rate': f"{perf_data['error_rate_pct'].mean():.2f}%",
            'SLA Compliance': "99.2%"
        }
        
        col1, col2, col3 = st.columns(3)
        metrics_items = list(summary_metrics.items())
        
        for i, (metric, value) in enumerate(metrics_items):
            col = [col1, col2, col3][i % 3]
            with col:
                st.metric(metric, value)
    
    with tab3:
        st.subheader("📜 Operational Logs")
        
        # Get operation history
        operation_history = components['admin_workflows'].get_operation_history(50)
        
        if operation_history:
            # Operations summary
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Recent Operations", len(operation_history))
            
            with col2:
                op_types = [op['operation_type'] for op in operation_history]
                most_common = max(set(op_types), key=op_types.count) if op_types else "None"
                st.metric("Most Common", most_common.replace('_', ' ').title())
            
            with col3:
                if operation_history:
                    last_op_time = operation_history[-1]['timestamp']
                    st.metric("Last Operation", last_op_time[:16].replace('T', ' '))
            
            # Operations log
            st.subheader("📋 Operation History")
            
            # Create operations DataFrame
            ops_data = []
            for op in reversed(operation_history):  # Most recent first
                ops_data.append({
                    'Timestamp': op['timestamp'][:19].replace('T', ' '),
                    'Operation': op['operation_type'].replace('_', ' ').title(),
                    'Details': str(op['details'])[:100] + '...' if len(str(op['details'])) > 100 else str(op['details'])
                })
            
            ops_df = pd.DataFrame(ops_data)
            st.dataframe(ops_df, use_container_width=True, hide_index=True)
            
            # Export logs
            if st.button("📥 Export Operation Logs", use_container_width=True):
                logs_csv = pd.DataFrame(operation_history).to_csv(index=False)
                st.download_button(
                    "Download Logs (CSV)",
                    logs_csv,
                    f"operation_logs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    "text/csv"
                )
        else:
            st.info("💡 No operational logs available yet. Perform some admin operations to see logs here.")
        
        # Log level configuration
        st.subheader("⚙️ Logging Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            log_level = st.selectbox(
                "Log Level",
                ["DEBUG", "INFO", "WARNING", "ERROR"],
                index=1
            )
        
        with col2:
            log_retention = st.number_input(
                "Log Retention (days)",
                min_value=1,
                max_value=365,
                value=30
            )
        
        if st.button("💾 Update Logging Config"):
            st.success("✅ Logging configuration updated")

def system_cleanup():
    """System cleanup and maintenance interface."""
    st.header("🧹 System Cleanup")
    st.write("Perform maintenance tasks and system cleanup operations")
    
    tab1, tab2 = st.tabs(["Automated Cleanup", "Manual Cleanup"])
    
    with tab1:
        st.subheader("🤖 Automated System Cleanup")
        
        # Cleanup configuration
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Cleanup Options:**")
            
            cleanup_models = st.checkbox("🤖 Clean old model versions", value=True)
            cleanup_backups = st.checkbox("💾 Clean old schema backups", value=True)
            cleanup_logs = st.checkbox("📜 Clean old operation logs", value=True)
            cleanup_temp = st.checkbox("🗂️ Clean temporary files", value=True)
        
        with col2:
            st.write("**Retention Settings:**")
            
            model_versions_keep = st.number_input("Model versions to keep", min_value=1, max_value=20, value=3)
            backup_count_keep = st.number_input("Backups to keep", min_value=1, max_value=50, value=10)
            log_days_keep = st.number_input("Log retention (days)", min_value=1, max_value=365, value=30)
        
        # Pre-cleanup analysis
        st.subheader("🔍 Pre-Cleanup Analysis")
        
        if st.button("📊 Analyze System for Cleanup", use_container_width=True):
            with st.spinner("Analyzing system..."):
                # Get current storage usage
                model_storage = components['ml_engine'].model_manager.get_storage_usage()
                backup_storage = components['backup_manager'].get_storage_usage()
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Model Storage", f"{model_storage['total_size_mb']:.1f} MB")
                    st.write(f"- {model_storage['model_families']} model families")
                    st.write(f"- {model_storage['total_versions']} total versions")
                
                with col2:
                    st.metric("Backup Storage", f"{backup_storage['total_size_mb']:.1f} MB")
                    st.write(f"- {backup_storage['backup_count']} backups")
                    st.write(f"- Avg size: {backup_storage['average_size_mb']:.1f} MB")
                
                with col3:
                    total_storage = model_storage['total_size_mb'] + backup_storage['total_size_mb']
                    st.metric("Total Storage", f"{total_storage:.1f} MB")
                
                # Cleanup recommendations
                st.subheader("💡 Cleanup Recommendations")
                
                recommendations = []
                
                if model_storage['total_versions'] > 15:
                    recommendations.append("🤖 Consider cleaning old model versions")
                
                if backup_storage['backup_count'] > 20:
                    recommendations.append("💾 Consider cleaning old backups")
                
                if total_storage > 500:  # > 500MB
                    recommendations.append("💽 High storage usage detected")
                
                if not recommendations:
                    recommendations.append("✅ System storage looks healthy")
                
                for rec in recommendations:
                    st.write(rec)
        
        # Execute cleanup
        st.subheader("🚀 Execute Cleanup")
        
        confirm_cleanup = st.checkbox("⚠️ I confirm that I want to perform system cleanup")
        
        if st.button("🧹 Start Automated Cleanup", disabled=not confirm_cleanup, use_container_width=True, type="primary"):
            with st.spinner("Performing system cleanup..."):
                cleanup_results = components['admin_workflows'].cleanup_system()
                
                if cleanup_results['success']:
                    st.success("✅ System cleanup completed successfully!")
                    
                    # Show cleanup results
                    results = cleanup_results['cleanup_results']
                    
                    if results['operations_performed']:
                        st.subheader("📋 Cleanup Operations Performed")
                        for operation in results['operations_performed']:
                            st.write(f"✅ {operation}")
                    else:
                        st.info("ℹ️ No cleanup operations were needed")
                    
                    if results['errors']:
                        st.subheader("⚠️ Cleanup Errors")
                        for error in results['errors']:
                            st.error(f"❌ {error}")
                    
                    st.metric("Storage Freed", f"{results.get('storage_freed_mb', 0):.1f} MB")
                else:
                    st.error(f"❌ Cleanup failed: {cleanup_results['error']}")
    
    with tab2:
        st.subheader("🔧 Manual Cleanup Operations")
        
        # Individual cleanup operations
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Model Management:**")
            
            if st.button("🗑️ Clean Old Model Versions", use_container_width=True):
                try:
                    models = components['ml_engine'].model_manager.list_all_models()
                    total_deleted = 0
                    
                    for model_name in models:
                        deleted = components['ml_engine'].model_manager.cleanup_old_versions(model_name, keep_count=3)
                        total_deleted += deleted
                    
                    if total_deleted > 0:
                        st.success(f"✅ Deleted {total_deleted} old model versions")
                    else:
                        st.info("ℹ️ No old model versions to clean")
                except Exception as e:
                    st.error(f"❌ Model cleanup failed: {e}")
            
            if st.button("📊 View Model Storage Details", use_container_width=True):
                try:
                    models = components['ml_engine'].model_manager.list_all_models()
                    
                    for model_name in models:
                        versions = components['ml_engine'].model_manager.list_model_versions(model_name)
                        st.write(f"**{model_name}:** {len(versions)} versions")
                except Exception as e:
                    st.error(f"❌ Error: {e}")
        
        with col2:
            st.write("**Backup Management:**")
            
            if st.button("🗑️ Clean Old Backups", use_container_width=True):
                try:
                    deleted = components['backup_manager'].cleanup_old_backups(keep_count=5)
                    if deleted > 0:
                        st.success(f"✅ Deleted {deleted} old backups")
                    else:
                        st.info("ℹ️ No old backups to clean")
                except Exception as e:
                    st.error(f"❌ Backup cleanup failed: {e}")
            
            if st.button("📊 View Backup Storage Details", use_container_width=True):
                try:
                    storage_info = components['backup_manager'].get_storage_usage()
                    st.write(f"**Total backups:** {storage_info['backup_count']}")
                    st.write(f"**Storage used:** {storage_info['total_size_mb']:.1f} MB")
                    st.write(f"**Average size:** {storage_info['average_size_mb']:.1f} MB")
                except Exception as e:
                    st.error(f"❌ Error: {e}")
        
        # System maintenance
        st.subheader("🔧 System Maintenance")
        
        maintenance_options = [
            "🔄 Restart ML Engine",
            "💽 Optimize Database", 
            "🧹 Clear Cache",
            "📊 Rebuild Indexes",
            "🔍 Run System Diagnostics"
        ]
        
        selected_maintenance = st.selectbox("Select maintenance operation", maintenance_options)
        
        if st.button("🚀 Execute Maintenance Operation", use_container_width=True):
            with st.spinner(f"Executing {selected_maintenance}..."):
                # Simulate maintenance operation
                if "Restart ML Engine" in selected_maintenance:
                    st.success("✅ ML Engine restarted successfully")
                elif "Optimize Database" in selected_maintenance:
                    st.success("✅ Database optimization completed")
                elif "Clear Cache" in selected_maintenance:
                    st.success("✅ System cache cleared")
                elif "Rebuild Indexes" in selected_maintenance:
                    st.success("✅ Indexes rebuilt successfully")
                elif "Run System Diagnostics" in selected_maintenance:
                    st.success("✅ System diagnostics completed - no issues found")
        
        # Emergency operations
        st.subheader("🚨 Emergency Operations")
        st.warning("⚠️ **Warning**: Emergency operations may cause system downtime")
        
        emergency_confirm = st.checkbox("I understand this may cause system downtime")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔄 Force System Reset", disabled=not emergency_confirm, use_container_width=True):
                st.error("🚨 System reset would be performed (not implemented in demo)")
        
        with col2:
            if st.button("💾 Emergency Backup", disabled=not emergency_confirm, use_container_width=True):
                st.success("✅ Emergency backup would be created")

if __name__ == "__main__":
    main()
