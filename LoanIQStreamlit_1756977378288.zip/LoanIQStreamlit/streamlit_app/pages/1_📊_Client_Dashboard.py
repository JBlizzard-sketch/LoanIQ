"""Client Dashboard for LoanIQ - Credit score predictions and analysis."""
import streamlit as st
import pandas as pd
import numpy as np
import sys
import os
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

# Add modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from modules.auth import AuthManager
from modules.ml.engine import MLEngine
from modules.pipeline.feature_engineer import FeatureEngineer
from modules.schema.validator import SchemaValidator
from modules.schema.preprocessor import DataPreprocessor
from modules.synth.data_generator import SyntheticDataGenerator

# Page configuration
st.set_page_config(
    page_title="Client Dashboard - LoanIQ",
    page_icon="📊",
    layout="wide"
)

# Authentication check
if 'authenticated' not in st.session_state or not st.session_state.authenticated:
    st.error("🔒 Please login to access this page.")
    st.stop()

# Initialize components
@st.cache_resource
def initialize_components():
    return {
        'ml_engine': MLEngine(),
        'feature_engineer': FeatureEngineer(),
        'validator': SchemaValidator(),
        'preprocessor': DataPreprocessor(),
        'data_generator': SyntheticDataGenerator()
    }

components = initialize_components()

def main():
    """Main dashboard function."""
    st.title("📊 Client Dashboard")
    st.write("Credit scoring predictions and risk analysis")
    
    # Sidebar navigation
    with st.sidebar:
        st.header("🎯 Dashboard Tools")
        
        dashboard_mode = st.selectbox(
            "Select Mode",
            ["🔍 Client Lookup", "🎮 What-If Analysis", "📊 Batch Predictions", "📈 Analytics"]
        )
        
        st.divider()
        
        # Quick metrics
        try:
            model_status = components['ml_engine'].get_model_status()
            deployed_model = model_status['deployed_model']
            
            if deployed_model['is_loaded']:
                st.success(f"🤖 Model: {deployed_model['name']} v{deployed_model['version']}")
            else:
                st.warning("⚠️ No model deployed")
        except:
            st.error("❌ ML Engine unavailable")
    
    # Route to appropriate mode
    if dashboard_mode == "🔍 Client Lookup":
        client_lookup_mode()
    elif dashboard_mode == "🎮 What-If Analysis":
        what_if_analysis_mode()
    elif dashboard_mode == "📊 Batch Predictions":
        batch_predictions_mode()
    elif dashboard_mode == "📈 Analytics":
        analytics_mode()

def client_lookup_mode():
    """Client lookup and individual prediction mode."""
    st.header("🔍 Client Lookup & Prediction")
    
    tab1, tab2 = st.tabs(["Manual Entry", "Sample Data"])
    
    with tab1:
        st.subheader("Enter Client Information")
        
        with st.form("client_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                client_id = st.number_input("Client ID", min_value=1, value=1001)
                loan_amount = st.number_input(
                    "Loan Amount ($)", 
                    min_value=1000, 
                    max_value=100000, 
                    value=25000,
                    step=1000
                )
                interest_rate = st.number_input(
                    "Interest Rate (%)", 
                    min_value=1.0, 
                    max_value=30.0, 
                    value=8.5,
                    step=0.1
                )
                term_months = st.selectbox(
                    "Loan Term (months)",
                    [12, 24, 36, 48, 60, 72],
                    index=2
                )
            
            with col2:
                monthly_income = st.number_input(
                    "Monthly Income ($)", 
                    min_value=1000, 
                    max_value=20000, 
                    value=5000,
                    step=100
                )
                debt_payments = st.number_input(
                    "Monthly Debt Payments ($)", 
                    min_value=0, 
                    max_value=10000, 
                    value=1200,
                    step=50
                )
                employment_years = st.number_input(
                    "Employment Years", 
                    min_value=0.0, 
                    max_value=50.0, 
                    value=3.5,
                    step=0.5
                )
                credit_history_years = st.number_input(
                    "Credit History Years", 
                    min_value=0.0, 
                    max_value=50.0, 
                    value=5.0,
                    step=0.5
                )
                previous_defaults = st.number_input(
                    "Previous Defaults", 
                    min_value=0, 
                    max_value=10, 
                    value=0
                )
            
            submit_prediction = st.form_submit_button("🎯 Get Credit Prediction", use_container_width=True)
            
            if submit_prediction:
                # Create client data
                client_data = pd.DataFrame({
                    'client_id': [client_id],
                    'loan_amount': [loan_amount],
                    'interest_rate': [interest_rate],
                    'term_months': [term_months],
                    'monthly_income': [monthly_income],
                    'debt_payments': [debt_payments],
                    'employment_years': [employment_years],
                    'credit_history_years': [credit_history_years],
                    'previous_defaults': [previous_defaults]
                })
                
                # Process and predict
                process_and_display_prediction(client_data, f"Client {client_id}")
    
    with tab2:
        st.subheader("Use Sample Data")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.write("Generate sample client data for testing:")
        
        with col2:
            if st.button("🎲 Generate Sample", use_container_width=True):
                sample_data = components['data_generator'].generate_loan_data(1)
                st.session_state.sample_client = sample_data
        
        if 'sample_client' in st.session_state:
            sample_df = st.session_state.sample_client
            
            st.subheader("Sample Client Data")
            st.dataframe(sample_df, use_container_width=True)
            
            if st.button("🎯 Predict Sample Client", use_container_width=True):
                process_and_display_prediction(sample_df, "Sample Client")

def what_if_analysis_mode():
    """What-if scenario analysis mode."""
    st.header("🎮 What-If Analysis")
    st.write("Explore how different parameters affect credit predictions")
    
    # Base scenario
    with st.expander("📋 Base Scenario", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            base_loan_amount = st.slider("Base Loan Amount ($)", 5000, 80000, 25000, 1000)
            base_income = st.slider("Base Monthly Income ($)", 2000, 15000, 5000, 100)
        
        with col2:
            base_debt = st.slider("Base Debt Payments ($)", 0, 5000, 1200, 50)
            base_employment = st.slider("Base Employment Years", 0.0, 20.0, 5.0, 0.5)
        
        with col3:
            base_credit_history = st.slider("Base Credit History Years", 0.0, 25.0, 8.0, 0.5)
            base_defaults = st.slider("Base Previous Defaults", 0, 5, 0)
    
    # Scenario comparison
    st.subheader("📊 Scenario Comparison")
    
    scenario_type = st.selectbox(
        "Analyze Impact Of:",
        ["Loan Amount", "Monthly Income", "Debt Payments", "Employment History", "Interest Rate"]
    )
    
    if st.button("🔄 Run What-If Analysis", use_container_width=True):
        run_what_if_analysis(
            scenario_type,
            base_loan_amount,
            base_income,
            base_debt,
            base_employment,
            base_credit_history,
            base_defaults
        )

def batch_predictions_mode():
    """Batch predictions mode."""
    st.header("📊 Batch Predictions")
    st.write("Upload data or generate multiple predictions at once")
    
    tab1, tab2 = st.tabs(["File Upload", "Generate Batch"])
    
    with tab1:
        st.subheader("Upload Client Data")
        
        uploaded_file = st.file_uploader(
            "Choose CSV file",
            type=['csv'],
            help="Upload a CSV file with client data for batch predictions"
        )
        
        if uploaded_file is not None:
            try:
                batch_data = pd.read_csv(uploaded_file)
                st.write(f"📁 Loaded {len(batch_data)} records")
                
                # Show data preview
                with st.expander("👀 Data Preview"):
                    st.dataframe(batch_data.head(10))
                
                # Validate data
                is_valid, errors = components['validator'].validate_dataframe(batch_data)
                
                if is_valid:
                    st.success("✅ Data validation passed")
                else:
                    st.warning("⚠️ Data validation issues found:")
                    for error in errors:
                        st.write(f"- {error}")
                    
                    auto_fix = st.checkbox("🔧 Auto-fix data issues")
                    if auto_fix:
                        batch_data = components['validator'].auto_fix_dataframe(batch_data)
                        st.info("🔧 Data has been automatically fixed")
                
                if st.button("🎯 Run Batch Predictions", use_container_width=True):
                    run_batch_predictions(batch_data)
                    
            except Exception as e:
                st.error(f"❌ Error loading file: {e}")
    
    with tab2:
        st.subheader("Generate Test Batch")
        
        col1, col2 = st.columns(2)
        
        with col1:
            batch_size = st.number_input(
                "Number of Records",
                min_value=10,
                max_value=500,
                value=50,
                step=10
            )
        
        with col2:
            include_history = st.checkbox("Include Client History", value=False)
        
        if st.button("🎲 Generate Test Batch", use_container_width=True):
            with st.spinner("Generating test data..."):
                if include_history:
                    test_data = components['data_generator'].generate_client_history_data(
                        batch_size // 2, 2
                    )
                else:
                    test_data = components['data_generator'].generate_loan_data(batch_size)
                
                st.success(f"✅ Generated {len(test_data)} test records")
                
                # Show preview
                with st.expander("👀 Generated Data Preview"):
                    st.dataframe(test_data.head(10))
                
                if st.button("🎯 Run Predictions on Generated Data", use_container_width=True):
                    run_batch_predictions(test_data)

def analytics_mode():
    """Analytics and reporting mode."""
    st.header("📈 Analytics & Insights")
    st.write("System performance and prediction analytics")
    
    tab1, tab2, tab3 = st.tabs(["Model Performance", "Prediction Trends", "Risk Analysis"])
    
    with tab1:
        display_model_performance()
    
    with tab2:
        display_prediction_trends()
    
    with tab3:
        display_risk_analysis()

def process_and_display_prediction(data: pd.DataFrame, client_name: str):
    """Process client data and display prediction results."""
    try:
        with st.spinner("Processing prediction..."):
            # Preprocess data
            processed_data = components['preprocessor'].preprocess_loan_data(data)
            
            # Engineer features
            featured_data = components['feature_engineer'].engineer_features(processed_data)
            
            # Remove target column if present for prediction
            prediction_data = featured_data.drop(columns=['defaulted'] if 'defaulted' in featured_data.columns else [])
            
            # Make prediction
            result = components['ml_engine'].predict(prediction_data)
            
            if result['error']:
                st.error(f"❌ Prediction failed: {result['error']}")
                return
            
            # Display results
            display_prediction_results(data, result, client_name, featured_data)
            
    except Exception as e:
        st.error(f"❌ Error processing prediction: {e}")

def display_prediction_results(original_data: pd.DataFrame, result: Dict, client_name: str, featured_data: pd.DataFrame):
    """Display comprehensive prediction results."""
    st.subheader(f"🎯 Prediction Results for {client_name}")
    
    prediction = result['predictions'][0]
    probability = result['probabilities'][0] if result['probabilities'] else None
    
    # Main prediction display
    col1, col2, col3 = st.columns(3)
    
    with col1:
        status_color = "🔴" if prediction == 1 else "🟢"
        status_text = "HIGH RISK" if prediction == 1 else "LOW RISK"
        st.metric("Credit Risk", f"{status_color} {status_text}")
    
    with col2:
        if probability is not None:
            prob_percent = probability * 100
            st.metric("Default Probability", f"{prob_percent:.1f}%")
    
    with col3:
        risk_score = "High" if probability and probability > 0.5 else "Medium" if probability and probability > 0.3 else "Low"
        st.metric("Risk Category", risk_score)
    
    # Risk gauge chart
    if probability is not None:
        fig = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = probability * 100,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Default Risk Score"},
            delta = {'reference': 25},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 30], 'color': "lightgreen"},
                    {'range': [30, 70], 'color': "yellow"},
                    {'range': [70, 100], 'color': "red"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 70
                }
            }
        ))
        
        fig.update_layout(height=300)
        st.plotly_chart(fig, use_container_width=True)
    
    # Feature analysis
    with st.expander("🔍 Detailed Risk Analysis"):
        original_row = original_data.iloc[0]
        
        # Calculate key ratios
        loan_to_income = original_row['loan_amount'] / (original_row['monthly_income'] * 12)
        debt_to_income = original_row['debt_payments'] / original_row['monthly_income']
        
        st.subheader("📊 Key Risk Factors")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Loan-to-Income Ratio", f"{loan_to_income:.2f}")
            st.metric("Debt-to-Income Ratio", f"{debt_to_income:.1%}")
            st.metric("Employment Years", f"{original_row['employment_years']:.1f}")
        
        with col2:
            st.metric("Credit History", f"{original_row['credit_history_years']:.1f} years")
            st.metric("Previous Defaults", f"{original_row['previous_defaults']}")
            st.metric("Interest Rate", f"{original_row['interest_rate']:.1f}%")
        
        # Risk factor assessment
        st.subheader("⚠️ Risk Assessment")
        
        risk_factors = []
        
        if loan_to_income > 3:
            risk_factors.append("🔴 High loan-to-income ratio (>3.0)")
        elif loan_to_income > 2:
            risk_factors.append("🟡 Moderate loan-to-income ratio (>2.0)")
        
        if debt_to_income > 0.4:
            risk_factors.append("🔴 High debt-to-income ratio (>40%)")
        elif debt_to_income > 0.3:
            risk_factors.append("🟡 Moderate debt-to-income ratio (>30%)")
        
        if original_row['employment_years'] < 2:
            risk_factors.append("🔴 Short employment history (<2 years)")
        elif original_row['employment_years'] < 5:
            risk_factors.append("🟡 Limited employment history (<5 years)")
        
        if original_row['previous_defaults'] > 0:
            risk_factors.append(f"🔴 Previous defaults: {original_row['previous_defaults']}")
        
        if original_row['credit_history_years'] < 3:
            risk_factors.append("🔴 Limited credit history (<3 years)")
        
        if risk_factors:
            for factor in risk_factors:
                st.write(factor)
        else:
            st.write("🟢 No major risk factors identified")
    
    # Data export
    with st.expander("📥 Export Results"):
        export_data = original_data.copy()
        export_data['prediction'] = prediction
        export_data['default_probability'] = probability
        export_data['risk_category'] = risk_score
        export_data['analysis_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        st.download_button(
            "📄 Download Results (CSV)",
            export_data.to_csv(index=False),
            f"prediction_results_{client_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            "text/csv",
            use_container_width=True
        )

def run_what_if_analysis(scenario_type: str, base_loan: float, base_income: float, 
                        base_debt: float, base_employment: float, base_credit: float, base_defaults: int):
    """Run what-if scenario analysis."""
    with st.spinner("Running what-if analysis..."):
        scenarios = []
        
        # Generate scenarios based on type
        if scenario_type == "Loan Amount":
            amounts = np.linspace(base_loan * 0.5, base_loan * 2, 10)
            for amount in amounts:
                scenarios.append({
                    'scenario': f"${amount:,.0f}",
                    'loan_amount': amount,
                    'monthly_income': base_income,
                    'debt_payments': base_debt,
                    'employment_years': base_employment,
                    'credit_history_years': base_credit,
                    'previous_defaults': base_defaults,
                    'interest_rate': 8.5,
                    'term_months': 36,
                    'client_id': 9999
                })
        
        elif scenario_type == "Monthly Income":
            incomes = np.linspace(base_income * 0.5, base_income * 2, 10)
            for income in incomes:
                scenarios.append({
                    'scenario': f"${income:,.0f}",
                    'loan_amount': base_loan,
                    'monthly_income': income,
                    'debt_payments': base_debt,
                    'employment_years': base_employment,
                    'credit_history_years': base_credit,
                    'previous_defaults': base_defaults,
                    'interest_rate': 8.5,
                    'term_months': 36,
                    'client_id': 9999
                })
        
        # Create DataFrame and run predictions
        scenario_df = pd.DataFrame(scenarios)
        
        try:
            # Process scenarios
            processed_scenarios = components['preprocessor'].preprocess_loan_data(scenario_df)
            featured_scenarios = components['feature_engineer'].engineer_features(processed_scenarios)
            prediction_scenarios = featured_scenarios.drop(columns=['defaulted'] if 'defaulted' in featured_scenarios.columns else [])
            
            # Get predictions
            result = components['ml_engine'].predict(prediction_scenarios)
            
            if result['error']:
                st.error(f"❌ Analysis failed: {result['error']}")
                return
            
            # Create results DataFrame
            results_df = scenario_df.copy()
            results_df['prediction'] = result['predictions']
            results_df['default_probability'] = result['probabilities'] if result['probabilities'] else [0] * len(scenarios)
            
            # Display results
            st.subheader(f"📊 {scenario_type} Impact Analysis")
            
            # Create visualization
            if scenario_type == "Loan Amount":
                x_values = results_df['loan_amount']
                x_title = "Loan Amount ($)"
            else:
                x_values = results_df['monthly_income']
                x_title = "Monthly Income ($)"
            
            fig = px.line(
                x=x_values,
                y=results_df['default_probability'] * 100,
                title=f"Default Probability vs {scenario_type}",
                labels={'x': x_title, 'y': 'Default Probability (%)'}
            )
            
            fig.add_hline(y=50, line_dash="dash", line_color="red", annotation_text="50% Risk Threshold")
            st.plotly_chart(fig, use_container_width=True)
            
            # Results table
            display_results = results_df[['scenario', 'prediction', 'default_probability']].copy()
            display_results['default_probability'] = (display_results['default_probability'] * 100).round(1)
            display_results['risk_level'] = display_results['default_probability'].apply(
                lambda x: 'High' if x > 50 else 'Medium' if x > 30 else 'Low'
            )
            
            st.dataframe(display_results, use_container_width=True)
            
        except Exception as e:
            st.error(f"❌ Error in what-if analysis: {e}")

def run_batch_predictions(data: pd.DataFrame):
    """Run predictions on batch data."""
    try:
        with st.spinner("Processing batch predictions..."):
            # Preprocess data
            processed_data = components['preprocessor'].preprocess_loan_data(data)
            
            # Engineer features
            featured_data = components['feature_engineer'].engineer_features(processed_data)
            
            # Remove target column if present
            prediction_data = featured_data.drop(columns=['defaulted'] if 'defaulted' in featured_data.columns else [])
            
            # Make predictions
            result = components['ml_engine'].predict(prediction_data)
            
            if result['error']:
                st.error(f"❌ Batch prediction failed: {result['error']}")
                return
            
            # Create results DataFrame
            results_df = data.copy()
            results_df['prediction'] = result['predictions']
            results_df['default_probability'] = result['probabilities'] if result['probabilities'] else [0] * len(data)
            results_df['risk_level'] = results_df['default_probability'].apply(
                lambda x: 'High' if x > 0.5 else 'Medium' if x > 0.3 else 'Low'
            )
            
            # Display summary
            st.subheader("📊 Batch Prediction Summary")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Predictions", len(results_df))
            
            with col2:
                high_risk_count = sum(results_df['prediction'])
                st.metric("High Risk", high_risk_count)
            
            with col3:
                avg_probability = results_df['default_probability'].mean()
                st.metric("Avg Risk Score", f"{avg_probability:.1%}")
            
            with col4:
                low_risk_count = len(results_df) - high_risk_count
                st.metric("Low Risk", low_risk_count)
            
            # Risk distribution
            risk_dist = results_df['risk_level'].value_counts()
            fig = px.pie(
                values=risk_dist.values,
                names=risk_dist.index,
                title="Risk Level Distribution"
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Results table
            st.subheader("📋 Detailed Results")
            
            # Add filters
            col1, col2 = st.columns(2)
            
            with col1:
                risk_filter = st.selectbox(
                    "Filter by Risk Level",
                    ["All", "High", "Medium", "Low"]
                )
            
            with col2:
                sort_by = st.selectbox(
                    "Sort by",
                    ["Default Probability", "Loan Amount", "Client ID"]
                )
            
            # Apply filters
            filtered_results = results_df.copy()
            if risk_filter != "All":
                filtered_results = filtered_results[filtered_results['risk_level'] == risk_filter]
            
            # Sort results
            if sort_by == "Default Probability":
                filtered_results = filtered_results.sort_values('default_probability', ascending=False)
            elif sort_by == "Loan Amount":
                filtered_results = filtered_results.sort_values('loan_amount', ascending=False)
            else:
                filtered_results = filtered_results.sort_values('client_id')
            
            # Display table
            display_columns = ['client_id', 'loan_amount', 'monthly_income', 'prediction', 'default_probability', 'risk_level']
            available_columns = [col for col in display_columns if col in filtered_results.columns]
            
            st.dataframe(
                filtered_results[available_columns].round(3),
                use_container_width=True
            )
            
            # Export results
            st.subheader("📥 Export Results")
            
            export_data = results_df.copy()
            export_data['analysis_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            st.download_button(
                "📄 Download Batch Results (CSV)",
                export_data.to_csv(index=False),
                f"batch_predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                "text/csv",
                use_container_width=True
            )
            
    except Exception as e:
        st.error(f"❌ Error in batch predictions: {e}")

def display_model_performance():
    """Display model performance metrics."""
    st.subheader("🤖 Current Model Performance")
    
    try:
        model_status = components['ml_engine'].get_model_status()
        
        if model_status['deployed_model']['is_loaded']:
            st.success(f"✅ Active Model: {model_status['deployed_model']['name']} v{model_status['deployed_model']['version']}")
            
            # Mock performance metrics (in real app, these would come from model validation)
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Accuracy", "87.3%", "↑ 2.1%")
            
            with col2:
                st.metric("Precision", "84.6%", "↑ 1.5%")
            
            with col3:
                st.metric("Recall", "89.2%", "↓ 0.8%")
            
            with col4:
                st.metric("F1 Score", "86.8%", "↑ 0.9%")
            
            # Available models
            st.subheader("📚 Available Models")
            available_models = model_status['available_models']
            
            if available_models:
                models_df = pd.DataFrame([
                    {'Model': model, 'Status': 'Deployed' if model == model_status['deployed_model']['name'] else 'Available'}
                    for model in available_models
                ])
                st.dataframe(models_df, use_container_width=True)
            else:
                st.warning("No models available")
        else:
            st.warning("⚠️ No model currently deployed")
            
    except Exception as e:
        st.error(f"❌ Error loading model performance: {e}")

def display_prediction_trends():
    """Display prediction trends and statistics."""
    st.subheader("📈 Prediction Trends")
    
    # Generate sample trend data
    dates = pd.date_range(start=datetime.now() - timedelta(days=30), end=datetime.now(), freq='D')
    np.random.seed(42)
    
    trend_data = pd.DataFrame({
        'date': dates,
        'predictions': np.random.randint(10, 100, len(dates)),
        'default_rate': np.random.uniform(0.1, 0.4, len(dates)),
        'avg_risk_score': np.random.uniform(0.2, 0.8, len(dates))
    })
    
    # Predictions over time
    col1, col2 = st.columns(2)
    
    with col1:
        fig = px.line(
            trend_data,
            x='date',
            y='predictions',
            title='Daily Predictions'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        fig = px.line(
            trend_data,
            x='date',
            y='default_rate',
            title='Default Rate Trend'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    # Summary statistics
    st.subheader("📊 30-Day Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Predictions", f"{trend_data['predictions'].sum():,}")
    
    with col2:
        st.metric("Avg Daily Predictions", f"{trend_data['predictions'].mean():.0f}")
    
    with col3:
        st.metric("Avg Default Rate", f"{trend_data['default_rate'].mean():.1%}")
    
    with col4:
        st.metric("Avg Risk Score", f"{trend_data['avg_risk_score'].mean():.1%}")

def display_risk_analysis():
    """Display risk analysis and insights."""
    st.subheader("⚠️ Risk Analysis & Insights")
    
    # Generate sample risk analysis data
    np.random.seed(42)
    
    # Risk factor distribution
    risk_factors = {
        'High Debt-to-Income': 35,
        'Short Credit History': 28,
        'Previous Defaults': 22,
        'Low Employment History': 18,
        'High Loan-to-Income': 15
    }
    
    fig = px.bar(
        x=list(risk_factors.values()),
        y=list(risk_factors.keys()),
        orientation='h',
        title='Most Common Risk Factors (%)',
        labels={'x': 'Percentage of High-Risk Cases', 'y': 'Risk Factor'}
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Risk insights
    st.subheader("💡 Key Risk Insights")
    
    insights = [
        "🔴 **Debt-to-Income Ratio**: Clients with DTI > 40% show 3x higher default risk",
        "🟡 **Employment History**: Less than 2 years employment increases risk by 45%",
        "🔴 **Previous Defaults**: Any previous default increases current risk by 200%",
        "🟡 **Credit History**: Short credit history (<3 years) correlates with 60% higher risk",
        "🟢 **Loan Amount**: Higher loan amounts actually show slightly lower default rates"
    ]
    
    for insight in insights:
        st.write(insight)
    
    # Risk distribution by demographics
    col1, col2 = st.columns(2)
    
    with col1:
        # Sample risk by income bracket
        income_risk = pd.DataFrame({
            'Income Bracket': ['<$3K', '$3K-$5K', '$5K-$8K', '$8K+'],
            'Default Rate': [0.45, 0.28, 0.18, 0.12]
        })
        
        fig = px.bar(
            income_risk,
            x='Income Bracket',
            y='Default Rate',
            title='Default Rate by Income Bracket'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Sample risk by loan term
        term_risk = pd.DataFrame({
            'Loan Term': ['12 months', '24 months', '36 months', '48+ months'],
            'Default Rate': [0.15, 0.22, 0.28, 0.35]
        })
        
        fig = px.bar(
            term_risk,
            x='Loan Term',
            y='Default Rate',
            title='Default Rate by Loan Term'
        )
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
