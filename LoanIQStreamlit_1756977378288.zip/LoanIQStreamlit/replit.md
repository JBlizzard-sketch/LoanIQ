# LoanIQ - Credit Scoring System

## Overview

LoanIQ is a comprehensive credit scoring system that uses machine learning to predict loan default risk. The system provides both client-facing dashboards for credit assessments and administrative tools for model management, data generation, and system monitoring. It's built with a modular architecture supporting multiple ML model families, synthetic data generation, and role-based authentication.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Framework
- **Frontend**: Streamlit web application with multi-page architecture
- **Authentication**: Role-based access control (Client/Admin roles) using SQLite database
- **Configuration**: Environment-based configuration management with dataclasses

### Machine Learning Pipeline
- **ML Engine**: Coordinates training, prediction, and model management
- **Model Support**: Multiple algorithms including Logistic Regression, Random Forest, Gradient Boosting, XGBoost, LightGBM, and stacked hybrid models
- **Feature Engineering**: Automated feature creation including ratio features, risk scoring, bucketing, and interaction features
- **Model Management**: Version control, deployment tracking, and automated retraining based on data thresholds

### Data Management
- **Schema Validation**: Enforces data quality and consistency using predefined schemas
- **Data Preprocessing**: Handles missing values, data type conversion, and basic cleaning
- **Synthetic Data Generation**: Uses Faker library to create realistic loan data for testing and training
- **Backup System**: Schema and data backup/restore functionality with metadata tracking

### Modular Architecture
The system is organized into distinct modules:
- `modules/auth/`: Authentication and user management
- `modules/ml/`: Machine learning engine and model training
- `modules/pipeline/`: Feature engineering and data processing
- `modules/schema/`: Data validation, preprocessing, and backup management
- `modules/synth/`: Synthetic data generation
- `modules/admin_tools/`: Administrative workflows and tools
- `streamlit_app/`: Web interface with role-based pages

### Security and Access Control
- Password hashing using secure algorithms
- Session management with configurable timeouts
- Role-based page access (Client vs Admin functionality)
- SQLite database for user management

## External Dependencies

### Core Libraries
- **Streamlit**: Web application framework for interactive dashboards
- **scikit-learn**: Primary machine learning library for model training and evaluation
- **pandas/numpy**: Data manipulation and numerical computing
- **Plotly**: Interactive data visualization and charting

### Optional ML Libraries
- **XGBoost**: Gradient boosting framework (optional import)
- **LightGBM**: Microsoft's gradient boosting framework (optional import)

### Data Generation
- **Faker**: Library for generating realistic synthetic data

### Database
- **SQLite**: User authentication and session management (built into Python)
- **PostgreSQL**: Primary database (configured via environment variables, may be added later)

### Development and Testing
- **pytest**: Testing framework for unit and integration tests
- **joblib**: Model serialization and persistence