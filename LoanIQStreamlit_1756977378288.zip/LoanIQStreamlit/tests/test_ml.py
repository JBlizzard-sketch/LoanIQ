"""Tests for ML module."""
import pytest
import os
import sys
import pandas as pd
import numpy as np
import tempfile
import shutil
from sklearn.datasets import make_classification
from sklearn.metrics import accuracy_score, f1_score

# Add modules to path for testing
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from modules.ml.engine import MLEngine
from modules.ml.model_manager import ModelManager
from modules.ml.trainer import ModelTrainer


class TestModelTrainer:
    """Test ModelTrainer class."""
    
    def setup_method(self):
        """Setup test data."""
        self.trainer = ModelTrainer()
        
        # Create synthetic classification dataset
        X, y = make_classification(
            n_samples=200,
            n_features=10,
            n_informative=8,
            n_redundant=2,
            n_clusters_per_class=1,
            random_state=42
        )
        
        # Convert to DataFrame
        feature_names = [f'feature_{i}' for i in range(X.shape[1])]
        self.X_train = pd.DataFrame(X[:150], columns=feature_names)
        self.y_train = pd.Series(y[:150])
        self.X_test = pd.DataFrame(X[150:], columns=feature_names)
        self.y_test = pd.Series(y[150:])
    
    def test_model_configs(self):
        """Test model configuration setup."""
        # Check that basic models are configured
        required_models = ['logistic_regression', 'random_forest', 'gradient_boosting']
        
        for model_name in required_models:
            assert model_name in self.trainer.model_configs
            config = self.trainer.model_configs[model_name]
            assert 'class' in config
            assert 'params' in config
            assert 'needs_scaling' in config
        
        print("✅ Model configurations test passed")
    
    def test_single_model_training(self):
        """Test training a single model."""
        result = self.trainer.train_single_model(
            'logistic_regression',
            self.X_train,
            self.y_train, 
            self.X_test,
            self.y_test
        )
        
        assert result['success'] == True
        assert result['model'] is not None
        assert result['predictions'] is not None
        assert result['metrics'] is not None
        
        # Check metrics
        metrics = result['metrics']
        assert 'accuracy' in metrics
        assert 'f1_score' in metrics
        assert 'roc_auc' in metrics
        
        # Metrics should be reasonable
        assert 0 <= metrics['accuracy'] <= 1
        assert 0 <= metrics['f1_score'] <= 1
        assert 0 <= metrics['roc_auc'] <= 1
        
        print("✅ Single model training test passed")
    
    def test_all_models_training(self):
        """Test training all available models."""
        results = self.trainer.train_all_models(
            self.X_train,
            self.y_train,
            self.X_test, 
            self.y_test
        )
        
        # Should have results for multiple models
        assert len(results) >= 3  # At least basic models
        
        # Check each result
        successful_models = 0
        for model_name, result in results.items():
            if result['success']:
                successful_models += 1
                assert result['model'] is not None
                assert result['metrics'] is not None
        
        # At least some models should succeed
        assert successful_models >= 2
        
        print(f"✅ All models training test passed ({successful_models}/{len(results)} models successful)")
    
    def test_stacked_model_creation(self):
        """Test stacked ensemble model creation."""
        # First train base models
        base_results = {}
        for model_name in ['logistic_regression', 'random_forest']:
            result = self.trainer.train_single_model(
                model_name,
                self.X_train,
                self.y_train,
                self.X_test,
                self.y_test
            )
            base_results[model_name] = result
        
        # Create stacked model
        stacked_result = self.trainer._create_stacked_model(
            base_results,
            self.X_train,
            self.y_train,
            self.X_test,
            self.y_test
        )
        
        if stacked_result['success']:
            assert stacked_result['model'] is not None
            assert stacked_result['predictions'] is not None
            assert stacked_result['metrics'] is not None
            
            # Test predictions
            test_predictions = stacked_result['model'].predict(self.X_test)
            assert len(test_predictions) == len(self.y_test)
            
            print("✅ Stacked model creation test passed")
        else:
            print("⚠️ Stacked model creation skipped (insufficient base models)")
    
    def test_metrics_calculation(self):
        """Test metrics calculation."""
        # Create some test predictions
        y_true = np.array([0, 1, 1, 0, 1])
        y_pred = np.array([0, 1, 0, 0, 1])
        y_pred_proba = np.array([0.1, 0.9, 0.4, 0.2, 0.8])
        
        metrics = self.trainer._calculate_metrics(y_true, y_pred, y_pred_proba)
        
        # Check required metrics
        required_metrics = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']
        for metric in required_metrics:
            assert metric in metrics
            assert 0 <= metrics[metric] <= 1
        
        # Check accuracy calculation
        expected_accuracy = accuracy_score(y_true, y_pred)
        assert abs(metrics['accuracy'] - expected_accuracy) < 0.001
        
        print("✅ Metrics calculation test passed")
    
    def test_available_models(self):
        """Test getting available models list."""
        available = self.trainer.get_available_models()
        
        assert isinstance(available, list)
        assert len(available) > 0
        assert 'stacked_hybrid' in available
        
        # Basic models should be available
        basic_models = ['logistic_regression', 'random_forest', 'gradient_boosting']
        for model in basic_models:
            assert model in available
        
        print("✅ Available models test passed")
    
    def test_model_info(self):
        """Test getting model information."""
        # Test basic model info
        lr_info = self.trainer.get_model_info('logistic_regression')
        
        assert 'name' in lr_info
        assert 'class' in lr_info
        assert 'needs_scaling' in lr_info
        assert lr_info['name'] == 'logistic_regression'
        assert lr_info['needs_scaling'] == True
        
        # Test stacked model info
        stacked_info = self.trainer.get_model_info('stacked_hybrid')
        assert stacked_info['type'] == 'ensemble'
        
        print("✅ Model info test passed")


class TestModelManager:
    """Test ModelManager class."""
    
    def setup_method(self):
        """Setup test model manager."""
        # Use temporary directory for testing
        self.temp_dir = tempfile.mkdtemp()
        self.model_manager = ModelManager(self.temp_dir)
        
        # Create a simple test model
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        
        X = np.random.random((100, 5))
        y = np.random.randint(0, 2, 100)
        
        self.test_model = LogisticRegression(random_state=42)
        self.test_model.fit(X, y)
        
        self.test_scaler = StandardScaler()
        self.test_scaler.fit(X)
        
        self.model_info = {
            'model': self.test_model,
            'scaler': self.test_scaler,
            'feature_columns': ['feature_1', 'feature_2', 'feature_3', 'feature_4', 'feature_5'],
            'metrics': {'accuracy': 0.85, 'f1_score': 0.82, 'roc_auc': 0.88},
            'training_samples': 100,
            'model_family': 'logistic_regression'
        }
    
    def teardown_method(self):
        """Cleanup test directory."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_save_model(self):
        """Test model saving."""
        version = self.model_manager.save_model(self.model_info, 'test_model')
        
        assert version is not None
        assert version.startswith('v')
        
        # Check that model was saved
        models = self.model_manager.list_all_models()
        assert 'test_model' in models
        
        print("✅ Model saving test passed")
    
    def test_load_model(self):
        """Test model loading."""
        # Save model first
        version = self.model_manager.save_model(self.model_info, 'test_model')
        
        # Load model
        loaded_info = self.model_manager.load_model('test_model', version)
        
        assert loaded_info is not None
        assert loaded_info['model'] is not None
        assert loaded_info['scaler'] is not None
        assert loaded_info['feature_columns'] == self.model_info['feature_columns']
        assert loaded_info['version'] == version
        
        # Test model functionality
        X_test = np.random.random((10, 5))
        original_pred = self.test_model.predict(X_test)
        loaded_pred = loaded_info['model'].predict(X_test)
        
        np.testing.assert_array_equal(original_pred, loaded_pred)
        
        print("✅ Model loading test passed")
    
    def test_version_management(self):
        """Test model version management."""
        # Save multiple versions
        version1 = self.model_manager.save_model(self.model_info, 'versioned_model')
        
        # Modify model info for second version
        modified_info = self.model_info.copy()
        modified_info['metrics'] = {'accuracy': 0.90, 'f1_score': 0.85, 'roc_auc': 0.92}
        version2 = self.model_manager.save_model(modified_info, 'versioned_model')
        
        # Versions should be different
        assert version1 != version2
        
        # List versions
        versions = self.model_manager.list_model_versions('versioned_model')
        assert len(versions) == 2
        
        # Latest version should be correct
        latest = self.model_manager.get_latest_version('versioned_model')
        assert latest == version2
        
        print("✅ Version management test passed")
    
    def test_model_deployment(self):
        """Test model deployment tracking."""
        version = self.model_manager.save_model(self.model_info, 'deploy_test')
        
        # Set as deployed
        self.model_manager.set_deployed_model('deploy_test', version)
        
        # Check deployment
        deployed = self.model_manager.get_deployed_model()
        assert deployed is not None
        assert deployed[0] == 'deploy_test'
        assert deployed[1] == version
        
        print("✅ Model deployment test passed")
    
    def test_model_deletion(self):
        """Test model version deletion."""
        version = self.model_manager.save_model(self.model_info, 'delete_test')
        
        # Verify model exists
        loaded = self.model_manager.load_model('delete_test', version)
        assert loaded is not None
        
        # Delete model
        delete_success = self.model_manager.delete_model_version('delete_test', version)
        assert delete_success == True
        
        # Verify model is gone
        loaded_after = self.model_manager.load_model('delete_test', version)
        assert loaded_after is None
        
        print("✅ Model deletion test passed")
    
    def test_storage_usage(self):
        """Test storage usage reporting."""
        # Save some models
        for i in range(3):
            model_info = self.model_info.copy()
            model_info['model_family'] = f'test_family_{i}'
            self.model_manager.save_model(model_info, f'storage_test_{i}')
        
        usage = self.model_manager.get_storage_usage()
        
        assert 'total_size_mb' in usage
        assert 'model_families' in usage
        assert 'total_versions' in usage
        
        assert usage['model_families'] >= 3
        assert usage['total_versions'] >= 3
        assert usage['total_size_mb'] > 0
        
        print("✅ Storage usage test passed")
    
    def test_cleanup_old_versions(self):
        """Test cleanup of old model versions."""
        # Create multiple versions
        for i in range(5):
            model_info = self.model_info.copy()
            model_info['metrics'] = {'accuracy': 0.8 + i * 0.01}
            self.model_manager.save_model(model_info, 'cleanup_test')
        
        # Check initial count
        versions = self.model_manager.list_model_versions('cleanup_test')
        initial_count = len(versions)
        assert initial_count == 5
        
        # Cleanup keeping only 2 versions
        deleted_count = self.model_manager.cleanup_old_versions('cleanup_test', keep_count=2)
        assert deleted_count == 3
        
        # Check final count
        versions_after = self.model_manager.list_model_versions('cleanup_test')
        assert len(versions_after) == 2
        
        print("✅ Cleanup old versions test passed")


class TestMLEngine:
    """Test MLEngine class."""
    
    def setup_method(self):
        """Setup test ML engine."""
        self.temp_dir = tempfile.mkdtemp()
        self.ml_engine = MLEngine(self.temp_dir)
        
        # Create synthetic training data
        np.random.seed(42)
        self.training_data = pd.DataFrame({
            'client_id': range(1, 101),
            'loan_amount': np.random.uniform(5000, 50000, 100),
            'interest_rate': np.random.uniform(5, 15, 100),
            'monthly_income': np.random.uniform(3000, 10000, 100),
            'debt_payments': np.random.uniform(500, 2000, 100),
            'employment_years': np.random.uniform(0, 15, 100),
            'credit_history_years': np.random.uniform(1, 20, 100),
            'previous_defaults': np.random.choice([0, 1, 2], 100),
            'term_months': np.random.choice([24, 36, 48, 60], 100),
            'defaulted': np.random.choice([0, 0, 0, 1], 100)  # 25% default rate
        })
    
    def teardown_method(self):
        """Cleanup test directory."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def test_data_preparation(self):
        """Test training data preparation."""
        X, y = self.ml_engine._prepare_training_data(self.training_data, 'defaulted')
        
        assert len(X) == len(self.training_data)
        assert len(y) == len(self.training_data)
        assert 'defaulted' not in X.columns
        
        # All columns should be numeric after preparation
        for col in X.columns:
            assert pd.api.types.is_numeric_dtype(X[col])
        
        print("✅ Data preparation test passed")
    
    def test_model_training(self):
        """Test complete model training pipeline."""
        results = self.ml_engine.train_models(self.training_data)
        
        assert results['total_models_trained'] > 0
        assert 'best_model' in results
        assert results['best_model'] is not None
        assert results['training_samples'] > 0
        assert results['feature_count'] > 0
        
        # Check that models were actually trained
        assert 'models_performance' in results
        assert len(results['models_performance']) > 0
        
        print("✅ Model training test passed")
    
    def test_prediction(self):
        """Test model prediction."""
        # Train models first
        self.ml_engine.train_models(self.training_data)
        
        # Create prediction data (without target)
        pred_data = self.training_data.drop(columns=['defaulted']).head(10)
        
        # Make predictions
        result = self.ml_engine.predict(pred_data)
        
        assert result['error'] is None
        assert result['predictions'] is not None
        assert len(result['predictions']) == len(pred_data)
        
        # Predictions should be binary
        predictions = result['predictions']
        unique_preds = set(predictions)
        assert unique_preds.issubset({0, 1})
        
        # Probabilities should be available
        if result['probabilities']:
            probabilities = result['probabilities']
            assert len(probabilities) == len(pred_data)
            assert all(0 <= p <= 1 for p in probabilities)
        
        print("✅ Prediction test passed")
    
    def test_retrain_check(self):
        """Test retrain condition checking."""
        # Should need retrain with large dataset
        needs_retrain_large = self.ml_engine.check_retrain_needed(600)  # Above threshold
        assert needs_retrain_large == True
        
        # Should not need retrain with small dataset
        needs_retrain_small = self.ml_engine.check_retrain_needed(100)  # Below threshold
        assert needs_retrain_small == False
        
        print("✅ Retrain check test passed")
    
    def test_model_status(self):
        """Test model status reporting."""
        status = self.ml_engine.get_model_status()
        
        required_fields = ['deployed_model', 'total_models', 'available_models', 
                          'retrain_threshold', 'retrain_days']
        
        for field in required_fields:
            assert field in status
        
        assert isinstance(status['total_models'], int)
        assert isinstance(status['available_models'], list)
        assert status['retrain_threshold'] > 0
        assert status['retrain_days'] > 0
        
        print("✅ Model status test passed")
    
    def test_stress_testing(self):
        """Test model stress testing."""
        # Train a model first
        self.ml_engine.train_models(self.training_data)
        
        # Create test data for stress testing
        stress_data = self.training_data.head(20)
        
        # Run stress test
        stress_results = self.ml_engine.run_model_stress_test(stress_data)
        
        if 'error' not in stress_results:
            assert 'total_predictions' in stress_results
            assert 'default_rate' in stress_results
            assert 'prediction_distribution' in stress_results
            
            assert stress_results['total_predictions'] > 0
            assert 0 <= stress_results['default_rate'] <= 1
            
            print("✅ Stress testing test passed")
        else:
            print(f"⚠️ Stress testing skipped: {stress_results['error']}")
    
    def test_auto_retrain(self):
        """Test automatic retraining."""
        # Create large dataset that should trigger retrain
        large_data = pd.concat([self.training_data] * 6, ignore_index=True)  # 600 records
        
        # Run auto-retrain
        retrain_result = self.ml_engine.auto_retrain(large_data)
        
        if retrain_result is not None:
            assert 'total_models_trained' in retrain_result
            assert 'best_model' in retrain_result
            assert retrain_result['total_models_trained'] > 0
            
            print("✅ Auto retrain test passed")
        else:
            print("⚠️ Auto retrain not triggered (expected for this test)")


def test_ml_integration():
    """Test ML module integration."""
    # Create temporary directory for integration test
    temp_dir = tempfile.mkdtemp()
    
    try:
        # Create synthetic dataset
        np.random.seed(42)
        data = pd.DataFrame({
            'loan_amount': np.random.uniform(10000, 50000, 150),
            'interest_rate': np.random.uniform(5, 15, 150),
            'monthly_income': np.random.uniform(3000, 10000, 150),
            'debt_to_income': np.random.uniform(0.1, 0.6, 150),
            'employment_years': np.random.uniform(0, 15, 150),
            'credit_history_years': np.random.uniform(1, 20, 150),
            'previous_defaults': np.random.choice([0, 1, 2], 150),
            'defaulted': np.random.choice([0, 0, 0, 1], 150)
        })
        
        # Test complete ML pipeline
        ml_engine = MLEngine(temp_dir)
        
        # Train models
        training_results = ml_engine.train_models(data)
        assert training_results['total_models_trained'] > 0
        
        # Make predictions
        pred_data = data.drop(columns=['defaulted']).head(20)
        prediction_results = ml_engine.predict(pred_data)
        assert prediction_results['error'] is None
        assert len(prediction_results['predictions']) == 20
        
        # Check model status
        status = ml_engine.get_model_status()
        assert status['deployed_model']['is_loaded'] == True
        assert status['total_models'] > 0
        
        # Test model persistence
        ml_engine2 = MLEngine(temp_dir)
        status2 = ml_engine2.get_model_status()
        assert status2['deployed_model']['is_loaded'] == True
        
        # Test predictions with new instance
        prediction_results2 = ml_engine2.predict(pred_data)
        assert prediction_results2['error'] is None
        
        print("✅ ML integration test passed")
        
    finally:
        # Cleanup
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


if __name__ == "__main__":
    """Run all ML tests."""
    print("🧪 Running ML Module Tests...")
    
    # Test ModelTrainer
    trainer_test = TestModelTrainer()
    trainer_test.setup_method()
    trainer_test.test_model_configs()
    
    trainer_test.setup_method()
    trainer_test.test_single_model_training()
    
    trainer_test.setup_method()
    trainer_test.test_all_models_training()
    
    trainer_test.setup_method()
    trainer_test.test_stacked_model_creation()
    
    trainer_test.setup_method()
    trainer_test.test_metrics_calculation()
    
    trainer_test.setup_method()
    trainer_test.test_available_models()
    
    trainer_test.setup_method()
    trainer_test.test_model_info()
    
    # Test ModelManager
    manager_test = TestModelManager()
    manager_test.setup_method()
    manager_test.test_save_model()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_load_model()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_version_management()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_model_deployment()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_model_deletion()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_storage_usage()
    manager_test.teardown_method()
    
    manager_test.setup_method()
    manager_test.test_cleanup_old_versions()
    manager_test.teardown_method()
    
    # Test MLEngine
    engine_test = TestMLEngine()
    engine_test.setup_method()
    engine_test.test_data_preparation()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_model_training()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_prediction()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_retrain_check()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_model_status()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_stress_testing()
    engine_test.teardown_method()
    
    engine_test.setup_method()
    engine_test.test_auto_retrain()
    engine_test.teardown_method()
    
    # Test integration
    test_ml_integration()
    
    print("✅ All ML tests passed!")
