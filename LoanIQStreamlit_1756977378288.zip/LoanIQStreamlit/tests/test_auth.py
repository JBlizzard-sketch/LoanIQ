"""Tests for authentication module."""
import pytest
import os
import sys
import tempfile
import sqlite3
from datetime import datetime, timedelta

# Add modules to path for testing
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from modules.auth.auth_manager import AuthManager, User, UserRole


class TestUserRole:
    """Test UserRole enum."""
    
    def test_user_roles(self):
        """Test user role enum values."""
        assert UserRole.CLIENT.value == "client"
        assert UserRole.ADMIN.value == "admin"
        print("✅ UserRole enum test passed")


class TestUser:
    """Test User dataclass."""
    
    def test_user_creation(self):
        """Test User dataclass creation."""
        user = User(
            id=1,
            username="testuser",
            email="test@example.com", 
            role=UserRole.CLIENT,
            created_at=datetime.now()
        )
        
        assert user.id == 1
        assert user.username == "testuser"
        assert user.email == "test@example.com"
        assert user.role == UserRole.CLIENT
        assert user.is_active == True  # default value
        assert user.last_login is None  # default value
        print("✅ User creation test passed")


class TestAuthManager:
    """Test AuthManager class."""
    
    def setup_method(self):
        """Setup test database."""
        # Use in-memory database for testing
        self.auth_manager = AuthManager(":memory:")
    
    def test_init_database(self):
        """Test database initialization."""
        # Database should be initialized in constructor
        # Test by checking if we can create a user
        user = self.auth_manager.register_user("testuser", "test@example.com", "password123")
        assert user is not None
        print("✅ Database initialization test passed")
    
    def test_password_hashing(self):
        """Test password hashing and verification."""
        password = "test_password_123"
        
        # Test hashing
        hashed = self.auth_manager._hash_password(password)
        assert len(hashed) > 64  # Salt (64) + hash
        assert hashed != password
        
        # Test verification
        assert self.auth_manager._verify_password(hashed, password) == True
        assert self.auth_manager._verify_password(hashed, "wrong_password") == False
        print("✅ Password hashing test passed")
    
    def test_user_registration(self):
        """Test user registration."""
        # Test successful registration
        user = self.auth_manager.register_user(
            "testuser", 
            "test@example.com", 
            "password123", 
            UserRole.CLIENT
        )
        
        assert user is not None
        assert user.username == "testuser"
        assert user.email == "test@example.com"
        assert user.role == UserRole.CLIENT
        assert user.id > 0
        
        # Test duplicate registration (should fail)
        duplicate_user = self.auth_manager.register_user(
            "testuser", 
            "test2@example.com", 
            "password456"
        )
        assert duplicate_user is None
        print("✅ User registration test passed")
    
    def test_authentication(self):
        """Test user authentication."""
        # Register test user
        user = self.auth_manager.register_user("authtest", "authtest@example.com", "mypassword")
        assert user is not None
        
        # Test successful authentication
        session_id = self.auth_manager.authenticate("authtest", "mypassword")
        assert session_id is not None
        assert len(session_id) > 10  # Should be a substantial token
        
        # Test failed authentication - wrong password
        failed_session = self.auth_manager.authenticate("authtest", "wrongpassword")
        assert failed_session is None
        
        # Test failed authentication - wrong username
        failed_session = self.auth_manager.authenticate("wronguser", "mypassword")
        assert failed_session is None
        print("✅ Authentication test passed")
    
    def test_session_management(self):
        """Test session creation and validation."""
        # Register and authenticate user
        user = self.auth_manager.register_user("sessiontest", "session@example.com", "sessionpass")
        session_id = self.auth_manager.authenticate("sessiontest", "sessionpass")
        
        assert session_id is not None
        
        # Test session validation
        retrieved_user = self.auth_manager.get_user_by_session(session_id)
        assert retrieved_user is not None
        assert retrieved_user.username == "sessiontest"
        assert retrieved_user.email == "session@example.com"
        
        # Test invalid session
        invalid_user = self.auth_manager.get_user_by_session("invalid_session_id")
        assert invalid_user is None
        print("✅ Session management test passed")
    
    def test_logout(self):
        """Test user logout."""
        # Register, authenticate, then logout
        user = self.auth_manager.register_user("logouttest", "logout@example.com", "logoutpass")
        session_id = self.auth_manager.authenticate("logouttest", "logoutpass")
        
        # Verify session works
        user_from_session = self.auth_manager.get_user_by_session(session_id)
        assert user_from_session is not None
        
        # Logout
        logout_success = self.auth_manager.logout(session_id)
        assert logout_success == True
        
        # Verify session no longer works
        user_after_logout = self.auth_manager.get_user_by_session(session_id)
        assert user_after_logout is None
        print("✅ Logout test passed")
    
    def test_admin_check(self):
        """Test admin role verification."""
        # Register regular user and admin
        client_user = self.auth_manager.register_user("client", "client@example.com", "pass", UserRole.CLIENT)
        admin_user = self.auth_manager.register_user("admin", "admin@example.com", "pass", UserRole.ADMIN)
        
        # Authenticate both
        client_session = self.auth_manager.authenticate("client", "pass")
        admin_session = self.auth_manager.authenticate("admin", "pass")
        
        # Test admin check
        assert self.auth_manager.is_admin(client_session) == False
        assert self.auth_manager.is_admin(admin_session) == True
        assert self.auth_manager.is_admin("invalid_session") == False
        print("✅ Admin check test passed")
    
    def test_get_all_users(self):
        """Test retrieving all users."""
        # Register multiple users
        users_data = [
            ("user1", "user1@example.com", "pass1", UserRole.CLIENT),
            ("user2", "user2@example.com", "pass2", UserRole.ADMIN),
            ("user3", "user3@example.com", "pass3", UserRole.CLIENT)
        ]
        
        for username, email, password, role in users_data:
            self.auth_manager.register_user(username, email, password, role)
        
        # Get all users
        all_users = self.auth_manager.get_all_users()
        
        assert len(all_users) >= 3  # At least the ones we created
        
        # Check if our users are there
        usernames = [user.username for user in all_users]
        assert "user1" in usernames
        assert "user2" in usernames
        assert "user3" in usernames
        
        # Check roles
        admin_users = [user for user in all_users if user.role == UserRole.ADMIN]
        client_users = [user for user in all_users if user.role == UserRole.CLIENT]
        
        assert len(admin_users) >= 1
        assert len(client_users) >= 2
        print("✅ Get all users test passed")
    
    def test_cleanup_expired_sessions(self):
        """Test cleanup of expired sessions."""
        # This test would require mocking datetime to simulate expired sessions
        # For now, we'll just test that the method runs without error
        self.auth_manager.cleanup_expired_sessions()
        print("✅ Cleanup expired sessions test passed")
    
    def test_edge_cases(self):
        """Test edge cases and error handling."""
        # Test empty credentials
        empty_user = self.auth_manager.register_user("", "", "")
        # Should handle gracefully (implementation dependent)
        
        # Test authentication with empty credentials
        empty_auth = self.auth_manager.authenticate("", "")
        assert empty_auth is None
        
        # Test very long credentials
        long_username = "a" * 1000
        long_user = self.auth_manager.register_user(long_username, "long@example.com", "password")
        # Should handle gracefully
        
        print("✅ Edge cases test passed")


def test_auth_integration():
    """Test authentication system integration."""
    # Create temporary database file for integration test
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_file:
        db_path = tmp_file.name
    
    try:
        # Test with actual file database
        auth_manager = AuthManager(db_path)
        
        # Register admin user
        admin = auth_manager.register_user("admin", "admin@loaniq.com", "admin123", UserRole.ADMIN)
        assert admin is not None
        
        # Register client user
        client = auth_manager.register_user("client", "client@loaniq.com", "client123", UserRole.CLIENT)
        assert client is not None
        
        # Test admin authentication
        admin_session = auth_manager.authenticate("admin", "admin123")
        assert admin_session is not None
        assert auth_manager.is_admin(admin_session) == True
        
        # Test client authentication
        client_session = auth_manager.authenticate("client", "client123")
        assert client_session is not None
        assert auth_manager.is_admin(client_session) == False
        
        # Test session persistence (create new manager instance)
        auth_manager2 = AuthManager(db_path)
        
        # Previous sessions should still be valid
        admin_user = auth_manager2.get_user_by_session(admin_session)
        client_user = auth_manager2.get_user_by_session(client_session)
        
        assert admin_user is not None
        assert admin_user.role == UserRole.ADMIN
        assert client_user is not None
        assert client_user.role == UserRole.CLIENT
        
        print("✅ Authentication integration test passed")
        
    finally:
        # Cleanup
        if os.path.exists(db_path):
            os.unlink(db_path)


if __name__ == "__main__":
    """Run all authentication tests."""
    print("🧪 Running Authentication Module Tests...")
    
    # Test UserRole
    role_test = TestUserRole()
    role_test.test_user_roles()
    
    # Test User dataclass
    user_test = TestUser()
    user_test.test_user_creation()
    
    # Test AuthManager
    auth_test = TestAuthManager()
    auth_test.setup_method()
    auth_test.test_init_database()
    
    auth_test.setup_method()
    auth_test.test_password_hashing()
    
    auth_test.setup_method()
    auth_test.test_user_registration()
    
    auth_test.setup_method()
    auth_test.test_authentication()
    
    auth_test.setup_method()
    auth_test.test_session_management()
    
    auth_test.setup_method()
    auth_test.test_logout()
    
    auth_test.setup_method()
    auth_test.test_admin_check()
    
    auth_test.setup_method()
    auth_test.test_get_all_users()
    
    auth_test.setup_method()
    auth_test.test_cleanup_expired_sessions()
    
    auth_test.setup_method()
    auth_test.test_edge_cases()
    
    # Test integration
    test_auth_integration()
    
    print("✅ All authentication tests passed!")
