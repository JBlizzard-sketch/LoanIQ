"""Tests for pipeline module."""
import pytest
import os
import sys
import pandas as pd
import numpy as np

# Add modules to path for testing
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from modules.pipeline.feature_engineer import FeatureEngineer
from modules.schema.validator import SchemaValidator
from modules.schema.preprocessor import DataPreprocessor
from modules.schema.backup_manager import SchemaBackupManager


class TestFeatureEngineer:
    """Test FeatureEngineer class."""
    
    def setup_method(self):
        """Setup test data."""
        self.engineer = FeatureEngineer()
        
        # Create sample loan data
        np.random.seed(42)
        self.sample_data = pd.DataFrame({
            'client_id': [1, 2, 3, 1, 2],
            'loan_amount': [10000, 25000, 15000, 8000, 30000],
            'interest_rate': [7.5, 9.2, 6.8, 8.1, 10.5],
            'term_months': [36, 60, 24, 48, 72],
            'monthly_income': [4500, 6200, 3800, 4500, 7000],
            'debt_payments': [900, 1500, 800, 1200, 1800],
            'employment_years': [3.5, 8.0, 1.5, 5.0, 12.0],
            'credit_history_years': [5.0, 12.0, 2.0, 8.0, 15.0],
            'previous_defaults': [0, 1, 2, 0, 0],
            'defaulted': [0, 1, 1, 0, 0]
        })
    
    def test_ratio_features(self):
        """Test creation of ratio features."""
        result = self.engineer._create_ratio_features(self.sample_data.copy())
        
        # Check if ratio features are created
        assert 'loan_to_income' in result.columns
        assert 'debt_to_income' in result.columns
        
        # Verify calculations
        expected_loan_to_income = result['loan_amount'] / (result['monthly_income'] * 12)
        assert np.allclose(result['loan_to_income'], expected_loan_to_income, equal_nan=True)
        
        expected_debt_to_income = result['debt_payments'] / result['monthly_income']
        assert np.allclose(result['debt_to_income'], expected_debt_to_income, equal_nan=True)
        
        print("✅ Ratio features test passed")
    
    def test_risk_features(self):
        """Test creation of risk features."""
        result = self.engineer._create_risk_features(self.sample_data.copy())
        
        # Check if risk features are created
        assert 'risk_score' in result.columns
        assert 'risk_score_normalized' in result.columns
        
        # Risk scores should be non-negative
        assert (result['risk_score'] >= 0).all()
        assert (result['risk_score_normalized'] >= 0).all()
        assert (result['risk_score_normalized'] <= 100).all()
        
        print("✅ Risk features test passed")
    
    def test_bucket_features(self):
        """Test creation of bucket features."""
        result = self.engineer._create_bucket_features(self.sample_data.copy())
        
        # Check if bucket features are created
        expected_buckets = ['income_bucket', 'loan_amount_bucket', 'interest_rate_bucket', 
                          'term_bucket', 'employment_bucket']
        
        for bucket in expected_buckets:
            assert bucket in result.columns
        
        # Check bucket values are categorical
        assert pd.api.types.is_categorical_dtype(result['income_bucket'])
        
        print("✅ Bucket features test passed")
    
    def test_aggregate_features(self):
        """Test creation of aggregate features."""
        result = self.engineer._create_aggregate_features(self.sample_data.copy())
        
        # Check if aggregate features are created for clients with multiple loans
        expected_aggregates = ['client_loan_count', 'client_avg_loan_amount', 'client_total_loan_amount']
        
        for agg_feature in expected_aggregates:
            assert agg_feature in result.columns
        
        # Verify aggregate calculations for client_id = 1 (has 2 loans)
        client_1_data = result[result['client_id'] == 1]
        assert (client_1_data['client_loan_count'] == 2).all()
        
        print("✅ Aggregate features test passed")
    
    def test_interaction_features(self):
        """Test creation of interaction features."""
        # First add some basic features that interactions depend on
        data_with_features = self.engineer._create_ratio_features(self.sample_data.copy())
        data_with_features = self.engineer._create_risk_features(data_with_features)
        
        result = self.engineer._create_interaction_features(data_with_features)
        
        # Check if interaction features are created
        expected_interactions = ['income_employment_interaction', 'risk_loan_interaction', 
                               'rate_term_interaction']
        
        for interaction in expected_interactions:
            assert interaction in result.columns
        
        # Interaction features should not have NaN values (after proper handling)
        for interaction in expected_interactions:
            assert not result[interaction].isnull().all()
        
        print("✅ Interaction features test passed")
    
    def test_feature_engineering_pipeline(self):
        """Test complete feature engineering pipeline."""
        original_columns = set(self.sample_data.columns)
        result = self.engineer.engineer_features(self.sample_data.copy())
        
        # Should have more columns than original
        assert len(result.columns) > len(original_columns)
        
        # Original columns should still be present
        for col in original_columns:
            assert col in result.columns
        
        # Check computed features tracking
        assert len(self.engineer.computed_features) > 0
        
        # All computed features should be in result
        for feature in self.engineer.computed_features:
            assert feature in result.columns
        
        print("✅ Feature engineering pipeline test passed")
    
    def test_feature_importance_ranking(self):
        """Test feature importance ranking."""
        data_with_features = self.engineer.engineer_features(self.sample_data.copy())
        importance = self.engineer.get_feature_importance_ranking(data_with_features)
        
        # Should return a dictionary
        assert isinstance(importance, dict)
        
        # Should not include the target variable
        assert 'defaulted' not in importance
        
        # All importance values should be between 0 and 1
        for feature, imp in importance.items():
            assert 0 <= imp <= 1
        
        print("✅ Feature importance ranking test passed")
    
    def test_feature_summary(self):
        """Test feature summary creation."""
        data_with_features = self.engineer.engineer_features(self.sample_data.copy())
        summary = self.engineer.create_feature_summary(data_with_features)
        
        # Check required summary fields
        required_fields = ['total_features', 'original_features', 'engineered_features', 
                         'feature_categories', 'data_quality']
        
        for field in required_fields:
            assert field in summary
        
        # Check calculations
        expected_original = len(self.sample_data.columns)
        expected_total = len(data_with_features.columns)
        expected_engineered = expected_total - expected_original
        
        assert summary['original_features'] == expected_original
        assert summary['total_features'] == expected_total
        assert summary['engineered_features'] == expected_engineered
        
        print("✅ Feature summary test passed")


class TestSchemaValidator:
    """Test SchemaValidator class."""
    
    def setup_method(self):
        """Setup test data."""
        self.validator = SchemaValidator()
        
        # Valid sample data
        self.valid_data = pd.DataFrame({
            'client_id': [1, 2, 3],
            'loan_amount': [10000.0, 25000.0, 15000.0],
            'interest_rate': [7.5, 9.2, 6.8],
            'term_months': [36, 60, 24],
            'monthly_income': [4500.0, 6200.0, 3800.0],
            'debt_payments': [900.0, 1500.0, 800.0],
            'employment_years': [3.5, 8.0, 1.5],
            'credit_history_years': [5.0, 12.0, 2.0],
            'previous_defaults': [0, 1, 0]
        })
    
    def test_valid_data_validation(self):
        """Test validation of valid data."""
        is_valid, errors = self.validator.validate_dataframe(self.valid_data)
        
        assert is_valid == True
        assert len(errors) == 0
        
        print("✅ Valid data validation test passed")
    
    def test_invalid_data_validation(self):
        """Test validation of invalid data."""
        invalid_data = self.valid_data.copy()
        
        # Introduce violations
        invalid_data.loc[0, 'loan_amount'] = -1000  # Below minimum
        invalid_data.loc[1, 'interest_rate'] = 50   # Above maximum
        invalid_data.loc[2, 'term_months'] = 400    # Above maximum
        
        is_valid, errors = self.validator.validate_dataframe(invalid_data)
        
        assert is_valid == False
        assert len(errors) > 0
        
        # Check specific error types
        error_text = ' '.join(errors)
        assert 'loan_amount' in error_text
        assert 'interest_rate' in error_text
        assert 'term_months' in error_text
        
        print("✅ Invalid data validation test passed")
    
    def test_missing_columns(self):
        """Test validation with missing required columns."""
        incomplete_data = self.valid_data.drop(columns=['loan_amount', 'interest_rate'])
        
        is_valid, errors = self.validator.validate_dataframe(incomplete_data)
        
        assert is_valid == False
        assert len(errors) > 0
        
        # Should detect missing columns
        error_text = ' '.join(errors)
        assert 'Missing required columns' in error_text
        
        print("✅ Missing columns test passed")
    
    def test_auto_fix_data(self):
        """Test automatic data fixing."""
        invalid_data = self.valid_data.copy()
        
        # Introduce issues
        invalid_data.loc[0, 'loan_amount'] = -1000  # Below minimum
        invalid_data.loc[1, 'interest_rate'] = 50   # Above maximum
        invalid_data.loc[2, 'loan_amount'] = None   # Missing value
        
        fixed_data = self.validator.auto_fix_dataframe(invalid_data)
        
        # Check fixes
        assert fixed_data.loc[0, 'loan_amount'] >= self.validator.loan_schema['constraints']['loan_amount']['min']
        assert fixed_data.loc[1, 'interest_rate'] <= self.validator.loan_schema['constraints']['interest_rate']['max']
        assert not pd.isna(fixed_data.loc[2, 'loan_amount'])
        
        print("✅ Auto-fix data test passed")
    
    def test_schema_info(self):
        """Test schema information retrieval."""
        schema_info = self.validator.get_schema_info()
        
        # Check required fields
        assert 'type' in schema_info
        assert 'required_columns' in schema_info
        assert 'data_types' in schema_info
        assert 'constraints' in schema_info
        assert 'total_columns' in schema_info
        
        assert schema_info['type'] == 'loan'
        assert len(schema_info['required_columns']) > 0
        
        print("✅ Schema info test passed")
    
    def test_sample_data_generation(self):
        """Test sample data generation."""
        sample_data = self.validator.generate_sample_data(10)
        
        # Check structure
        assert len(sample_data) == 10
        assert len(sample_data.columns) > 0
        
        # Validate generated sample
        is_valid, errors = self.validator.validate_dataframe(sample_data)
        assert is_valid == True
        
        print("✅ Sample data generation test passed")


class TestDataPreprocessor:
    """Test DataPreprocessor class."""
    
    def setup_method(self):
        """Setup test data."""
        self.preprocessor = DataPreprocessor()
        
        # Sample data with issues
        self.messy_data = pd.DataFrame({
            'client_id': [1, 2, 3, 1, 2],  # Duplicates
            'loan_amount': [10000, None, 15000, 8000, 30000],  # Missing value
            'interest_rate': [7.5, 9.2, 6.8, 8.1, 10.5],
            'term_months': [36, 60, 24, 48, 72],
            'monthly_income': [4500, 6200, 3800, 4500, 7000],
            'debt_payments': [900, 1500, 800, 1200, 1800],
            'employment_years': [3.5, 8.0, 1.5, 5.0, 12.0],
            'credit_history_years': [5.0, 12.0, 2.0, 8.0, 15.0],
            'previous_defaults': [0, 1, 2, 0, 0]
        })
    
    def test_basic_data_cleaning(self):
        """Test basic data cleaning operations."""
        original_length = len(self.messy_data)
        cleaned_data = self.preprocessor._clean_basic_data(self.messy_data.copy())
        
        # Check data types
        assert cleaned_data['loan_amount'].dtype == 'float64'
        assert cleaned_data['term_months'].dtype == 'int64'
        assert cleaned_data['client_id'].dtype == 'int64'
        
        print("✅ Basic data cleaning test passed")
    
    def test_target_variable_derivation(self):
        """Test target variable derivation."""
        data_without_target = self.messy_data.copy()
        
        # Remove target if exists
        if 'defaulted' in data_without_target.columns:
            data_without_target = data_without_target.drop(columns=['defaulted'])
        
        data_with_target = self.preprocessor._derive_target_variable(data_without_target)
        
        # Should have target variable now
        assert 'defaulted' in data_with_target.columns
        
        # Target should be binary
        unique_values = set(data_with_target['defaulted'].unique())
        assert unique_values.issubset({0, 1})
        
        print("✅ Target variable derivation test passed")
    
    def test_missing_value_handling(self):
        """Test missing value handling."""
        data_with_missing = self.messy_data.copy()
        
        # Introduce more missing values
        data_with_missing.loc[0, 'employment_years'] = None
        data_with_missing.loc[1, 'debt_payments'] = None
        
        original_missing_count = data_with_missing.isnull().sum().sum()
        handled_data = self.preprocessor._handle_missing_values(data_with_missing)
        final_missing_count = handled_data.isnull().sum().sum()
        
        # Should have fewer or no missing values
        assert final_missing_count <= original_missing_count
        
        print("✅ Missing value handling test passed")
    
    def test_preprocessing_pipeline(self):
        """Test complete preprocessing pipeline."""
        processed_data = self.preprocessor.preprocess_loan_data(self.messy_data.copy())
        
        # Should have target variable
        assert 'defaulted' in processed_data.columns
        
        # Should have no missing values in critical columns
        critical_columns = ['loan_amount', 'monthly_income', 'debt_payments']
        for col in critical_columns:
            if col in processed_data.columns:
                assert processed_data[col].isnull().sum() == 0
        
        print("✅ Preprocessing pipeline test passed")
    
    def test_data_summary(self):
        """Test data summary creation."""
        summary = self.preprocessor.create_data_summary(self.messy_data)
        
        # Check required sections
        required_sections = ['basic_info', 'missing_data', 'data_types', 
                           'numeric_summary', 'categorical_summary']
        
        for section in required_sections:
            assert section in summary
        
        # Check basic info
        assert summary['basic_info']['total_rows'] == len(self.messy_data)
        assert summary['basic_info']['total_columns'] == len(self.messy_data.columns)
        
        print("✅ Data summary test passed")
    
    def test_outlier_detection(self):
        """Test outlier detection."""
        outliers = self.preprocessor.detect_outliers(self.messy_data, method='iqr')
        
        # Should return dictionary with column names as keys
        assert isinstance(outliers, dict)
        
        # Each value should be a list of indices
        for col, indices in outliers.items():
            assert isinstance(indices, list)
            # Indices should be within valid range
            for idx in indices:
                assert 0 <= idx < len(self.messy_data)
        
        print("✅ Outlier detection test passed")
    
    def test_data_quality_validation(self):
        """Test data quality validation."""
        quality_report = self.preprocessor.validate_data_quality(self.messy_data)
        
        # Check required fields
        required_fields = ['overall_score', 'issues', 'recommendations', 'metrics']
        
        for field in required_fields:
            assert field in quality_report
        
        # Score should be between 0 and 100
        assert 0 <= quality_report['overall_score'] <= 100
        
        # Should have some metrics
        assert len(quality_report['metrics']) > 0
        
        print("✅ Data quality validation test passed")


class TestSchemaBackupManager:
    """Test SchemaBackupManager class."""
    
    def setup_method(self):
        """Setup test data."""
        self.backup_manager = SchemaBackupManager("test_schema_backups")
        
        self.sample_data = pd.DataFrame({
            'client_id': [1, 2, 3],
            'loan_amount': [10000, 25000, 15000],
            'interest_rate': [7.5, 9.2, 6.8],
            'monthly_income': [4500, 6200, 3800],
            'defaulted': [0, 1, 0]
        })
    
    def test_backup_creation(self):
        """Test backup creation."""
        backup_id = self.backup_manager.create_backup(
            self.sample_data, 
            "test_schema", 
            "Test backup"
        )
        
        assert backup_id is not None
        assert isinstance(backup_id, str)
        assert len(backup_id) > 10  # Should be a substantial ID
        
        print("✅ Backup creation test passed")
    
    def test_backup_listing(self):
        """Test backup listing."""
        # Create a backup first
        backup_id = self.backup_manager.create_backup(
            self.sample_data, 
            "test_schema", 
            "Test backup"
        )
        
        backups = self.backup_manager.list_backups()
        
        assert len(backups) >= 1
        
        # Find our backup
        our_backup = next((b for b in backups if b['backup_id'] == backup_id), None)
        assert our_backup is not None
        assert our_backup['schema_name'] == "test_schema"
        assert our_backup['row_count'] == len(self.sample_data)
        
        print("✅ Backup listing test passed")
    
    def test_backup_restoration(self):
        """Test backup restoration."""
        # Create backup
        backup_id = self.backup_manager.create_backup(
            self.sample_data, 
            "test_schema", 
            "Test backup"
        )
        
        # Restore backup
        restored_data = self.backup_manager.restore_backup(backup_id)
        
        assert restored_data is not None
        assert len(restored_data) == len(self.sample_data)
        assert list(restored_data.columns) == list(self.sample_data.columns)
        
        # Data should match
        pd.testing.assert_frame_equal(restored_data, self.sample_data)
        
        print("✅ Backup restoration test passed")
    
    def test_metadata_retrieval(self):
        """Test metadata retrieval."""
        backup_id = self.backup_manager.create_backup(
            self.sample_data, 
            "test_schema", 
            "Test backup"
        )
        
        metadata = self.backup_manager.get_backup_metadata(backup_id)
        
        assert metadata is not None
        assert metadata['backup_id'] == backup_id
        assert metadata['schema_name'] == "test_schema"
        assert metadata['row_count'] == len(self.sample_data)
        assert metadata['column_count'] == len(self.sample_data.columns)
        
        print("✅ Metadata retrieval test passed")
    
    def test_backup_deletion(self):
        """Test backup deletion."""
        backup_id = self.backup_manager.create_backup(
            self.sample_data, 
            "test_schema", 
            "Test backup"
        )
        
        # Verify backup exists
        assert self.backup_manager.get_backup_metadata(backup_id) is not None
        
        # Delete backup
        delete_success = self.backup_manager.delete_backup(backup_id)
        assert delete_success == True
        
        # Verify backup is gone
        assert self.backup_manager.get_backup_metadata(backup_id) is None
        
        print("✅ Backup deletion test passed")
    
    def test_storage_usage(self):
        """Test storage usage reporting."""
        # Create some backups
        for i in range(3):
            self.backup_manager.create_backup(
                self.sample_data, 
                f"test_schema_{i}", 
                f"Test backup {i}"
            )
        
        usage = self.backup_manager.get_storage_usage()
        
        assert 'total_size_mb' in usage
        assert 'backup_count' in usage
        assert 'average_size_mb' in usage
        
        assert usage['backup_count'] >= 3
        assert usage['total_size_mb'] > 0
        
        print("✅ Storage usage test passed")


def test_pipeline_integration():
    """Test integration between pipeline components."""
    # Create test data
    np.random.seed(42)
    test_data = pd.DataFrame({
        'client_id': range(1, 21),
        'loan_amount': np.random.uniform(5000, 50000, 20),
        'interest_rate': np.random.uniform(5, 15, 20),
        'monthly_income': np.random.uniform(3000, 10000, 20),
        'debt_payments': np.random.uniform(500, 2000, 20),
        'employment_years': np.random.uniform(0, 15, 20),
        'credit_history_years': np.random.uniform(1, 20, 20),
        'previous_defaults': np.random.choice([0, 1, 2], 20),
        'term_months': np.random.choice([24, 36, 48, 60], 20)
    })
    
    # Test full pipeline
    validator = SchemaValidator()
    preprocessor = DataPreprocessor()
    engineer = FeatureEngineer()
    backup_manager = SchemaBackupManager("test_integration_backups")
    
    # Step 1: Validate
    is_valid, errors = validator.validate_dataframe(test_data)
    if not is_valid:
        test_data = validator.auto_fix_dataframe(test_data)
    
    # Step 2: Preprocess
    processed_data = preprocessor.preprocess_loan_data(test_data)
    
    # Step 3: Feature engineering
    featured_data = engineer.engineer_features(processed_data)
    
    # Step 4: Backup
    backup_id = backup_manager.create_backup(featured_data, "integration_test", "Integration test")
    
    # Step 5: Restore and verify
    restored_data = backup_manager.restore_backup(backup_id)
    
    # Verify pipeline worked
    assert len(featured_data) == len(test_data)  # Same number of rows
    assert len(featured_data.columns) > len(test_data.columns)  # More features
    assert 'defaulted' in featured_data.columns  # Target derived
    assert featured_data.isnull().sum().sum() == 0  # No missing values
    
    # Verify backup/restore
    pd.testing.assert_frame_equal(restored_data, featured_data)
    
    # Cleanup
    backup_manager.delete_backup(backup_id)
    
    print("✅ Pipeline integration test passed")


if __name__ == "__main__":
    """Run all pipeline tests."""
    print("🧪 Running Pipeline Module Tests...")
    
    # Test FeatureEngineer
    fe_test = TestFeatureEngineer()
    fe_test.setup_method()
    fe_test.test_ratio_features()
    
    fe_test.setup_method()
    fe_test.test_risk_features()
    
    fe_test.setup_method()
    fe_test.test_bucket_features()
    
    fe_test.setup_method()
    fe_test.test_aggregate_features()
    
    fe_test.setup_method()
    fe_test.test_interaction_features()
    
    fe_test.setup_method()
    fe_test.test_feature_engineering_pipeline()
    
    fe_test.setup_method()
    fe_test.test_feature_importance_ranking()
    
    fe_test.setup_method()
    fe_test.test_feature_summary()
    
    # Test SchemaValidator
    sv_test = TestSchemaValidator()
    sv_test.setup_method()
    sv_test.test_valid_data_validation()
    
    sv_test.setup_method()
    sv_test.test_invalid_data_validation()
    
    sv_test.setup_method()
    sv_test.test_missing_columns()
    
    sv_test.setup_method()
    sv_test.test_auto_fix_data()
    
    sv_test.setup_method()
    sv_test.test_schema_info()
    
    sv_test.setup_method()
    sv_test.test_sample_data_generation()
    
    # Test DataPreprocessor
    dp_test = TestDataPreprocessor()
    dp_test.setup_method()
    dp_test.test_basic_data_cleaning()
    
    dp_test.setup_method()
    dp_test.test_target_variable_derivation()
    
    dp_test.setup_method()
    dp_test.test_missing_value_handling()
    
    dp_test.setup_method()
    dp_test.test_preprocessing_pipeline()
    
    dp_test.setup_method()
    dp_test.test_data_summary()
    
    dp_test.setup_method()
    dp_test.test_outlier_detection()
    
    dp_test.setup_method()
    dp_test.test_data_quality_validation()
    
    # Test SchemaBackupManager
    sbm_test = TestSchemaBackupManager()
    sbm_test.setup_method()
    sbm_test.test_backup_creation()
    
    sbm_test.setup_method()
    sbm_test.test_backup_listing()
    
    sbm_test.setup_method()
    sbm_test.test_backup_restoration()
    
    sbm_test.setup_method()
    sbm_test.test_metadata_retrieval()
    
    sbm_test.setup_method()
    sbm_test.test_backup_deletion()
    
    sbm_test.setup_method()
    sbm_test.test_storage_usage()
    
    # Test integration
    test_pipeline_integration()
    
    print("✅ All pipeline tests passed!")
