"""Tests for configuration module."""
import pytest
import os
import sys
from unittest.mock import patch, MagicMock

# Add modules to path for testing
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from modules.config import AppConfig, MLConfig, DatabaseConfig, get_config, update_config


class TestDatabaseConfig:
    """Test DatabaseConfig class."""
    
    def test_default_values(self):
        """Test default configuration values."""
        db_config = DatabaseConfig()
        
        assert db_config.host == "localhost"
        assert db_config.port == 5432
        assert db_config.name == "loaniq"
        assert db_config.user == "postgres"
        assert db_config.password == ""
        print("✅ DatabaseConfig default values test passed")
    
    @patch.dict(os.environ, {
        'DB_HOST': 'testhost',
        'DB_PORT': '3306', 
        'DB_NAME': 'testdb',
        'DB_USER': 'testuser',
        'DB_PASSWORD': 'testpass'
    })
    def test_from_env(self):
        """Test configuration from environment variables."""
        db_config = DatabaseConfig.from_env()
        
        assert db_config.host == "testhost"
        assert db_config.port == 3306
        assert db_config.name == "testdb"
        assert db_config.user == "testuser"
        assert db_config.password == "testpass"
        print("✅ DatabaseConfig from_env test passed")


class TestMLConfig:
    """Test MLConfig class."""
    
    def test_default_values(self):
        """Test default ML configuration values."""
        ml_config = MLConfig()
        
        assert ml_config.model_dir == "models"
        assert ml_config.retrain_threshold == 500
        assert ml_config.retrain_days == 7
        assert ml_config.validation_split == 0.2
        assert ml_config.test_split == 0.2
        assert ml_config.random_state == 42
        
        # Test model families
        expected_families = [
            'logistic_regression',
            'random_forest', 
            'gradient_boosting',
            'xgboost',
            'lightgbm',
            'stacked_hybrid'
        ]
        assert ml_config.model_families == expected_families
        print("✅ MLConfig default values test passed")
    
    def test_post_init(self):
        """Test __post_init__ method."""
        ml_config = MLConfig()
        ml_config.model_families = None
        ml_config.__post_init__()
        
        assert ml_config.model_families is not None
        assert len(ml_config.model_families) == 6
        print("✅ MLConfig post_init test passed")


class TestAppConfig:
    """Test AppConfig class."""
    
    def test_default_values(self):
        """Test default application configuration values."""
        app_config = AppConfig()
        
        assert app_config.app_name == "LoanIQ"
        assert app_config.version == "1.0.0"
        assert app_config.debug == False
        assert app_config.data_dir == "data"
        assert app_config.upload_dir == "data/uploads"
        assert app_config.schema_backup_dir == "schema_backups"
        
        # Test nested configs
        assert app_config.ml is not None
        assert app_config.db is not None
        assert isinstance(app_config.ml, MLConfig)
        assert isinstance(app_config.db, DatabaseConfig)
        print("✅ AppConfig default values test passed")
    
    @patch.dict(os.environ, {
        'SECRET_KEY': 'test-secret-key',
        'DEBUG': 'true'
    })
    def test_env_variables(self):
        """Test configuration from environment variables."""
        app_config = AppConfig()
        
        assert app_config.secret_key == "test-secret-key"
        assert app_config.debug == True
        print("✅ AppConfig environment variables test passed")
    
    def test_to_dict(self):
        """Test configuration serialization to dictionary."""
        app_config = AppConfig()
        config_dict = app_config.to_dict()
        
        # Test required keys
        required_keys = [
            'app_name', 'version', 'debug', 'data_dir', 
            'upload_dir', 'schema_backup_dir', 'ml', 'db'
        ]
        
        for key in required_keys:
            assert key in config_dict
        
        # Test nested structures
        assert 'model_dir' in config_dict['ml']
        assert 'retrain_threshold' in config_dict['ml']
        assert 'host' in config_dict['db']
        assert 'port' in config_dict['db']
        
        # Test no sensitive data
        assert 'password' not in config_dict['db']
        print("✅ AppConfig to_dict test passed")


class TestGlobalConfig:
    """Test global configuration functions."""
    
    def test_get_config(self):
        """Test get_config function."""
        config = get_config()
        
        assert isinstance(config, AppConfig)
        assert config.app_name == "LoanIQ"
        print("✅ get_config test passed")
    
    def test_update_config(self):
        """Test update_config function."""
        original_debug = get_config().debug
        
        # Update configuration
        update_config(debug=True, app_name="TestLoanIQ")
        
        updated_config = get_config()
        assert updated_config.debug == True
        assert updated_config.app_name == "TestLoanIQ"
        
        # Reset to original
        update_config(debug=original_debug, app_name="LoanIQ")
        print("✅ update_config test passed")
    
    def test_invalid_update(self):
        """Test update with invalid attributes."""
        # This should not raise an error, just ignore invalid attributes
        update_config(invalid_attribute="test", debug=False)
        
        config = get_config()
        assert not hasattr(config, 'invalid_attribute')
        print("✅ Invalid config update test passed")


def test_config_integration():
    """Test configuration integration."""
    # Test that all components work together
    config = get_config()
    
    # Test ML config integration
    assert len(config.ml.model_families) > 0
    assert config.ml.retrain_threshold > 0
    assert 0 < config.ml.validation_split < 1
    
    # Test database config integration
    assert config.db.host is not None
    assert config.db.port > 0
    assert config.db.name is not None
    
    # Test serialization
    config_dict = config.to_dict()
    assert isinstance(config_dict, dict)
    assert len(config_dict) > 0
    
    print("✅ Configuration integration test passed")


if __name__ == "__main__":
    """Run all configuration tests."""
    print("🧪 Running Configuration Module Tests...")
    
    # Run all test classes and methods
    test_classes = [
        TestDatabaseConfig(),
        TestMLConfig(), 
        TestAppConfig(),
        TestGlobalConfig()
    ]
    
    # Test database config
    db_test = TestDatabaseConfig()
    db_test.test_default_values()
    db_test.test_from_env()
    
    # Test ML config
    ml_test = TestMLConfig()
    ml_test.test_default_values()
    ml_test.test_post_init()
    
    # Test app config
    app_test = TestAppConfig()
    app_test.test_default_values()
    app_test.test_env_variables()
    app_test.test_to_dict()
    
    # Test global config
    global_test = TestGlobalConfig()
    global_test.test_get_config()
    global_test.test_update_config()
    global_test.test_invalid_update()
    
    # Test integration
    test_config_integration()
    
    print("✅ All configuration tests passed!")
